"""连续多代、版本树、编辑预算。被测对象是假的：按版本里有没有某项内容决定哪些任务做得对。"""
import json

from evo.adapters import ScriptedTextModel
from evo.evolve.budget import budget_at, diff, task_terms, violations
from evo.evolve.gate import admit
from evo.evolve.loop import evolve_generations
from evo.report import render_tree

from conftest import V0, go

GOOD = "你是编程助手。改完必须运行测试验证。\n当前项目目录：{cwd}\n"
DIAG = json.dumps({"symptom": "跑到上限", "cause": "轮次不够", "component": "loop", "weakness": "轮次用尽"},
                  ensure_ascii=False)
HALF = {"csv-quoted-comma", "slugify-dashes", "stock-reserve", "coupon-cap", "semver-compare", "truncate-ellipsis",
        "cart-merge-quantity"}
NEEDS_VERIFY = {"paginate-last-page", "rate-limit-window", "lru-read-refresh", "date-range-inclusive",
                "toc-heading-levels"}


def staged(version, task):
    """起点能过一部分；提示词补上验证再多过几条；轮次上限放宽后全过。"""
    if task.split == "regress" or task.id in HALF:
        return True
    if task.id in NEEDS_VERIFY:
        return "验证" in version.system_prompt
    return version.config_dict.get("loop.max_turns", 6) >= 12


def prompt_reply(diagnosis, prompt):
    return f"<diagnosis>{diagnosis}</diagnosis>\n<prompt>\n{prompt}</prompt>"


def test_generations_build_on_each_other_and_stop_when_nothing_is_left(make_bench):
    bench, agent, events = make_bench(staged)
    start = V0.derive("起点", config={"loop.max_turns": 6})
    bench.store.save_version(start, "merged", "起点版本")
    model = ScriptedTextModel([
        prompt_reply("没有验证就收尾", GOOD),                                     # 第 1 代：提示词，合入
        prompt_reply("剩下的失败是轮次不够，和提示词无关", ""),
        prompt_reply("剩下的失败是轮次不够，和提示词无关", ""),                     # 第 2 代：还是提示词，这回没得改
        prompt_reply("剩下的失败是轮次不够，和提示词无关", ""),
        DIAG, DIAG, '{"changes": {"loop.max_turns": 12}, "rationale": "轮次不够"}',     # 第 3 代：换成配置，合入
        '[{"op": "add", "section": "验证", "content": "改完后重新运行最初失败的测试。"}]',   # 第 5 代：手册，没有涨分
    ])
    head, history = go(evolve_generations(bench, model, start, generations=8))
    # 一级改成了就接着改这一级，没改成才换下一级
    assert [(g.no, g.level, g.outcome) for g in history] == [
        (1, "prompt", "admitted"), (2, "prompt", "no_change"), (3, "config", "admitted"), (4, "config", "no_change"),
        (5, "playbook", "rejected"), (6, "code", "no_change"), (7, "prompt", "no_change")]
    assert [round(g.score, 2) for g in history] == [0.78, 0.78, 1.0, 1.0, 1.0, 1.0, 1.0]
    assert history[4].rule == "no_gain" and history[0].base == start.id and history[2].base == history[0].candidate
    assert head.id == history[2].candidate == bench.store.head().id
    assert head.system_prompt == GOOD and head.config_dict == {"loop.max_turns": 12}
    assert [g.budget for g in history[:5]] == [20, 14, 9, 6, 4] and history[0].edit == 1
    starts = [d for k, d in events if k == "generations_start"]
    assert len(starts) == 1 and starts[0]["version"] == start.id and round(starts[0]["score"], 2) == 0.44
    # 起点的验收集只跑一遍：第 1 代的闸门直接用缓存
    assert sum(1 for v, t in agent.calls if v == start.id and bench.task(t).split == "accept") == 9
    assert any("连续 4 代没有合入" in d["text"] for k, d in events if k == "note")
    assert [g["no"] for g in bench.store.generations()] == [1, 2, 3, 4, 5, 6, 7]

    tree = render_tree(bench.store.versions(), bench.store.accept_scores(), head.id).splitlines()
    assert tree[0].startswith(f"✓ {start.id}  起点  验收 44%")
    assert tree[1].startswith(f"└─ ✓ {history[0].candidate}") and "验收 78%" in tree[1]
    assert f"✓ {head.id}" in tree[2] and tree[2].endswith("◀ 当前")
    assert f"✗ {history[4].candidate}" in tree[3] and "｜验收集没有变好" in tree[3]

    # 接着再跑，代数从上次的往后排
    _, more = go(evolve_generations(bench, ScriptedTextModel([]), head, generations=1, levels=("code",)))
    assert [g.no for g in more] == [8]


def test_single_level_gives_up_after_two_misses(make_bench):
    bench, _, events = make_bench(lambda v, t: t.split == "regress")
    model = ScriptedTextModel([DIAG] * 7 + ['{"changes": {}}'] + [DIAG] * 7 + ['{"changes": {}}'])
    head, history = go(evolve_generations(bench, model, V0, generations=5, levels=("config",)))
    assert head is V0 and [g.outcome for g in history] == ["no_change", "no_change"]


def test_budget_shrinks_and_counts_a_rewritten_line_once():
    assert [budget_at(n, 20) for n in range(1, 8)] == [20, 14, 9, 6, 4, 4, 4]
    longer = V0.derive("x", system_prompt=V0.system_prompt.replace("你是编程助手。", "你是严谨的编程助手。") + "多一行\n",
                       config={"loop.max_turns": 12})
    size, added = diff(V0, longer)
    assert size == 3 and added == ["你是严谨的编程助手。", "多一行", "loop.max_turns = 12"]


def test_edits_over_budget_or_naming_a_task_are_rejected_before_any_eval(make_bench, tasks):
    bench, agent, events = make_bench(lambda v, t: True, budget=2)
    wordy = V0.derive("写了一大段", system_prompt=V0.system_prompt + "".join(f"第 {i} 条。\n" for i in range(5)))
    decision = go(admit(bench, wordy, V0))
    assert not decision.admitted and decision.rule == "budget" and "改动 5 行，超出这一代的上限 2 行" in decision.reason
    tight = V0.derive("轮次上限 6", config={"loop.max_turns": 6})
    jump = tight.derive("一步调到 30", config={"loop.max_turns": 30})
    decision = go(admit(bench, jump, tight))
    assert decision.rule == "step" and "从 6 调到 30，一代最多调到原来的 2 倍（3～12）" in decision.reason
    assert go(admit(bench, tight.derive("调到两倍", config={"loop.max_turns": 12}), tight)).rule == "no_gain"
    assert not any(v in (wordy.id, jump.id) for v, _ in agent.calls)          # 被预算拦下的候选一次都没跑
    assert any("超出这一代的上限" in n for n in bench.store.rejected_notes())

    terms = task_terms(bench.split("evolve"))
    assert "csv-quoted-comma" in terms and "line.py" in terms and "tabular" in terms and "__init__.py" not in terms
    assert not any(t.id in terms for t in tasks if t.split != "evolve")
    free, _, _ = make_bench(lambda v, t: True)       # 不设预算时，写死题目名字照样拦
    cheat = V0.derive("背答案", system_prompt=V0.system_prompt + "遇到 line.py 就把引号里的逗号跳过。\n")
    decision = go(admit(free, cheat, V0))
    assert decision.rule == "specific" and "line.py" in decision.reason
    assert violations(V0, V0.derive("泛泛而谈", system_prompt=V0.system_prompt + "解析文本时注意引号。\n"), None, terms) == ("", "")


def test_proposers_are_told_the_limits_up_front(make_bench):
    bench, _, _ = make_bench(lambda v, t: t.split == "regress", budget=9)
    model = ScriptedTextModel([prompt_reply("不该改", V0.system_prompt)])
    from evo.evolve.prompt import evolve_prompt
    go(evolve_prompt(bench, model, V0, rounds=1))
    assert "改动不能超过 9 行" in model.seen[0][1]
    assert bench.limits() and make_bench(lambda v, t: True)[0].limits() == ""


def test_extract_block_drops_repeated_opening_tag():
    from evo.evolve.common import extract_block
    assert extract_block("<prompt>\n<prompt>\n正文\n</prompt>", "prompt") == "正文"
    assert extract_block("<prompt>正文</prompt>", "prompt") == "正文"
