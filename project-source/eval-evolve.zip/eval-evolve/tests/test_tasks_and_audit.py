import dataclasses

import pytest

from evo.audit import audit
from evo.graders import CommandGrader, snapshot
from evo.tasks import assign_splits, by_split, check_splits
from evo.types import Grade

from conftest import go


def test_three_disjoint_splits(tasks):
    assert {s: len(by_split(tasks, s)) for s in ("evolve", "accept", "regress")} == \
        {"evolve": 4, "accept": 2, "regress": 2}


def test_similar_group_must_not_cross_splits(tasks):
    leaked = [dataclasses.replace(tasks[0], id="copy", split="accept" if tasks[0].split != "accept" else "evolve")]
    with pytest.raises(ValueError, match="相似组"):
        check_splits(tasks + leaked)


def test_assign_splits_keeps_groups_together_and_regress_only_from_stable(tasks):
    twin = dataclasses.replace(tasks[0], id="twin")
    stable = {tasks[1].id, tasks[2].id}
    out = assign_splits(tasks + [twin], seed=1, stable_ids=stable)
    where = {t.id: s for s, ts in out.items() for t in ts}
    assert len(where) == len(tasks) + 1
    assert where["twin"] == where[tasks[0].id]
    assert {t.id for t in out["regress"]} <= stable
    assert assign_splits(tasks + [twin], seed=1, stable_ids=stable) == out      # 同一个种子结果不变


def test_grader_passes_reference_and_rejects_every_cheat(tasks):
    """对全部任务审计：参考解必须判通过，五种作弊必须判不通过。任务本身有问题也会在这里暴露。"""
    report = go(audit(CommandGrader(), tasks))
    assert len(report.rows) == len(tasks) * 6
    assert report.defects == [], report.summary()


class ExitCodeOnly(CommandGrader):
    """只看退出码的评分器：故意留的反例。"""
    name = "naive"

    async def grade(self, task, workdir, output, before):
        return await super().grade(task, workdir, output, snapshot(workdir, task.forbid_changes))


def test_audit_catches_a_grader_that_only_checks_exit_code(tasks):
    report = go(audit(ExitCodeOnly(), tasks[:2]))
    assert {r.case for r in report.defects} == {"weaken_assert", "skip_tests"}
    assert "缺陷" in report.summary()
