"""在线试用的场景：用假的被测对象和写好的模型回复跑完整一轮，检查推给页面的事件。"""
import importlib.util
import json
import sys

from evo.adapters import ScriptedTextModel
from evo.seeds import STALE_RULE, seed

from conftest import ROOT, FakeAgent, go


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


plugin = load("evo_trial_plugin", ROOT / "trial" / "plugin.py")


def run(scenario, tasks, solves, replies):
    events = []
    summary = go(plugin.run_evolution(plugin.SCENARIOS[scenario], events.append, agent=FakeAgent(tasks, solves),
                                      model=ScriptedTextModel(replies)))
    return events, summary


def texts(events):
    return "".join(e["text"] for e in events if e["type"] == "text")


def test_prompt_scenario_streams_a_full_round(tasks):
    fixed = seed("stale-rule").system_prompt.replace(STALE_RULE, "")
    events, summary = run("evolve-prompt", tasks, lambda v, t: STALE_RULE not in v.system_prompt,
                          [f"<diagnosis>提示词要求另存为新文件，原文件没改，测试自然不过</diagnosis><prompt>{fixed}</prompt>"])
    assert summary["stopped"] == "admitted" and summary["turns"] == 28      # 4 + 4 + 2×4 + 2×6 次任务运行（只用文件短的 14 条题）
    change = summary["changed_files"][0]
    assert change["path"] == "系统提示词" and STALE_RULE in change["before"] and STALE_RULE not in change["after"]

    starts = [e for e in events if e["type"] == "tool_start"]
    ends = {e["id"]: e for e in events if e["type"] == "tool_end"}
    assert {s["id"] for s in starts} == set(ends)                           # 每一步都有始有终
    assert sum(s["name"] == "run_task" for s in starts) == 28
    ask = next(s for s in starts if s["name"] == "ask_model")
    assert "反思" in ask["arguments"]["query"] and "另存为新文件" in ends[ask["id"]]["result"]
    first = ends[starts[0]["id"]]["result"]
    assert first.startswith("未通过") and "评分理由：检查命令退出码" in first
    said = texts(events)
    for piece in ("基线·进化集：通过 0/4", "第 1 轮反思的诊断：提示词要求另存为新文件", "候选·验收集：通过 6/6",
                  "准入闸门：合入。验收集 0% → 100%"):
        assert piece in said
    assert all(len(json.dumps(e, ensure_ascii=False)) < 8000 for e in events)


def test_config_scenario_diagnoses_then_fixes(tasks):
    diag = json.dumps({"symptom": "只读不改", "cause": "没有写文件的工具", "component": "tool",
                       "weakness": "缺少写文件工具"}, ensure_ascii=False)
    tools = ["read_file", "write_file", "edit_file", "find_files", "search_text", "run_command"]
    proposal = json.dumps({"changes": {"tools.enabled": tools}, "rationale": "不能写文件就修不了",
                           "risk": "无"}, ensure_ascii=False)
    events, summary = run("evolve-config", tasks,
                          lambda v, t: "edit_file" in v.config_dict.get("tools.enabled", tools),
                          [diag] * 4 + [proposal])
    assert summary["stopped"] == "admitted"
    change = summary["changed_files"][0]
    assert change["path"] == "外壳配置" and "edit_file" not in change["before"] and "edit_file" in change["after"]
    said = texts(events)
    assert "tool：缺少写文件工具（4 条任务）" in said and "先只在这类弱点涉及的任务上验证" in said


def test_rejected_and_no_change_outcomes(tasks):
    events, summary = run("evolve-prompt", tasks, lambda v, t: False,
                          ["<diagnosis>猜一个</diagnosis><prompt>换个说法。\n当前项目目录：{cwd}</prompt>"])
    assert summary["stopped"] == "no_change" and summary["changed_files"] == []
    events, summary = run("evolve-config", tasks, lambda v, t: t.split == "evolve" and "loop.max_turns" in dict(v.config)
                          and dict(v.config)["loop.max_turns"] == 20,
                          ["说不清"] * 4 + ['{"changes": {"loop.max_turns": 20}}'])
    assert summary["stopped"] == "rejected" and "准入闸门：拒绝。验收集没有变好" in texts(events)


def test_mismatch_scenario_never_merges_a_config_change(tasks):
    """毛病在提示词里、只许改配置：要么判断不该改，要么改了没用被拦下，都不能合入。"""
    diag = json.dumps({"symptom": "改动存成了新文件", "cause": "提示词要求另存", "component": "prompt",
                       "weakness": "提示词里的规定和评分冲突"}, ensure_ascii=False)
    solves = lambda v, t: STALE_RULE not in v.system_prompt      # noqa: E731  配置怎么改都过不了
    events, summary = run("evolve-mismatch", tasks, solves, [diag] * 4 + ['{"changes": {}, "rationale": "这是提示词的问题"}'])
    assert summary["stopped"] == "no_change" and summary["changed_files"] == []
    assert "判断这类弱点不是改配置能解决的" in texts(events)
    events, summary = run("evolve-mismatch", tasks, solves, [diag] * 4 + ['{"changes": {"loop.max_turns": 20}}'])
    assert summary["stopped"] == "rejected" and summary["changed_files"] == []
    assert "准入闸门：拒绝。弱点涉及的任务没有变好" in texts(events)


def test_check_command_goes_through_the_sandbox_executor(tmp_path):
    class Exec:
        def __init__(self, status):
            self.status, self.seen = status, []

        async def run(self, ws, command, timeout):
            self.seen.append((str(ws.root), command))
            return self.status, "输出"

    ok = Exec("退出码 0")
    assert go(plugin.sandbox_check(ok)(tmp_path, "python -m pytest tests -q", 60)) == (0, "输出")
    assert ok.seen == [(str(tmp_path.resolve()), "python -m pytest tests -q")]
    assert go(plugin.sandbox_check(Exec("退出码 1"))(tmp_path, "x", 60))[0] == 1
    assert go(plugin.sandbox_check(Exec("超过 60 秒未结束，已终止，下面是终止前的输出"))(tmp_path, "x", 60))[0] is None
    code, out = go(plugin.sandbox_check(Exec("沙箱不可用，命令没有执行"))(tmp_path, "x", 60))
    assert code == -1 and "沙箱不可用" in out


def test_trial_entry_picks_up_these_scenarios():
    brain = load("brain_for_evo", ROOT.parent / "general-agent" / "trial" / "brain_server.py")
    sc = brain.SCENARIOS["evolve-prompt"]
    assert sc["fixed_task"] and callable(sc["run"]) and "shop" in brain.SCENARIOS


def test_generations_summary_has_one_structured_record_per_generation(tasks):
    """连续多代：返回里带每一代的结构化记录（发现了什么、改了什么、考了几分、合入还是拦下）。"""
    grown = seed("tight").system_prompt.replace("可以用工具读写文件和运行命令。", "可以用工具读写文件和运行命令。改完必须运行测试验证。")
    turns = lambda v: v.config_dict.get("loop.max_turns", 30)      # noqa: E731
    solves = lambda v, t: (t.split == "regress" or t.id in ("csv-quoted-comma", "coupon-cap", "semver-compare")       # noqa: E731
                           or ("验证" in v.system_prompt and t.id != "invoice-tax-rounding") or turns(v) >= 12)
    events = []                 # 第 2、3 代进化集已经全过，不会问模型；第 4 代的手册修改没有涨分
    summary = go(plugin.run_generations(events.append, generations=4, agent=FakeAgent(tasks, solves), model=ScriptedTextModel([
        f"<diagnosis>没有验证就收尾</diagnosis><prompt>{grown}</prompt>",
        '[{"op": "add", "section": "验证", "content": "改完后重新运行最初失败的测试。"}]'])))
    assert summary["stopped"] == "finished" and summary["start_score"] == 2 / 9
    gens = summary["generations"]
    assert [(g["no"], g["level"], g["outcome"]) for g in gens] == [
        (1, "prompt", "admitted"), (2, "prompt", "no_change"), (3, "config", "no_change"), (4, "playbook", "rejected")]
    assert gens[0]["found"] == "没有验证就收尾" and gens[0]["budget"] == 20 and gens[0]["edit"] == 1
    assert gens[0]["changes"][0]["path"] == "系统提示词" and "验证" in gens[0]["changes"][0]["after"]
    assert round(gens[0]["score"], 2) == 0.89 and gens[3]["rule"] == "no_gain"
    assert gens[3]["changes"][0]["path"] == "经验手册" and "verify-001" in gens[3]["changes"][0]["after"]
    assert summary["changed_files"][0]["path"] == "系统提示词"
    said = texts(events)
    for piece in ("起点版本在验收集上的通过率：22%", "━━ 第 1 代 ━━　这一代改系统提示词，最多改 20 行",
                  "第 1 代结束：合入。当前版本在验收集上的通过率 89%", "第 4 代结束：被拦下"):
        assert piece in said
    assert "run_generations" not in str(plugin.SCENARIOS) and len(plugin.SCENARIOS) == 3     # 不登记成试用场景
