import json

from evo import report
from evo.adapters import ScriptedTextModel
from evo.graders import AllOf, CommandGrader, JudgeGrader, SpotCheckQueue, parse_verdict
from evo.runner import evaluate
from evo.store import Store
from evo.types import AgentVersion, Grade, PlaybookItem, RunOutput, RunRecord, Usage

from conftest import V0, FakeAgent, go


def rec(task, passed, version="v", **kw):
    return RunRecord(version, task, "accept", kw.pop("attempt", 0), passed, "", "command@2", kw.pop("tokens", 100),
                     10, 1.0, kw.pop("stopped", "finished"), 3)


def test_parse_verdict_reads_only_the_last_line():
    assert parse_verdict("依据：说清了原因\n通过") is True
    assert parse_verdict("虽然提到了通过测试\n不通过") is False
    assert parse_verdict("信息不够\n无法判断") is None
    assert parse_verdict("我觉得还行") is None


def test_judge_undecided_is_not_a_pass(tasks, tmp_path):
    task = next(t for t in tasks if t.rubric)
    out = RunOutput("改好了", [], Usage(), "finished")
    undecided = go(JudgeGrader(ScriptedTextModel(["看不出来\n无法判断"])).grade(task, tmp_path, out, {}))
    assert not undecided.passed and undecided.evidence["undecided"]
    model = ScriptedTextModel(["提到了浮点误差\n通过"])
    assert go(JudgeGrader(model).grade(task, tmp_path, out, {})).passed
    assert task.rubric in model.seen[0][1]
    no_rubric = next(t for t in tasks if not t.rubric)
    assert go(JudgeGrader(ScriptedTextModel([])).grade(no_rubric, tmp_path, out, {})).passed


def test_all_of_stops_at_first_failure(tasks):
    task = next(t for t in tasks if t.rubric)
    judge = ScriptedTextModel(["通过"])
    agent = FakeAgent(tasks, lambda v, t: False)
    records = go(evaluate(agent, AllOf(CommandGrader(), JudgeGrader(judge)), V0, [task]))
    assert not records[0].passed and "退出码" in records[0].reason
    assert judge.seen == []                       # 代码判定没过，就不必花钱问裁判
    assert records[0].grader == "command+judge@command@2+judge@1"


def test_spot_check_queue_and_agreement(tmp_path):
    q = SpotCheckQueue(tmp_path / "q" / "spot.jsonl", every=2)
    assert [q.offer(f"t{i}", "回复", Grade(True, "ok")) for i in range(4)] == [False, True, False, True]
    rows = [json.loads(x) for x in q.path.read_text(encoding="utf-8").splitlines()]
    rows[0]["human_passed"], rows[1]["human_passed"] = True, False
    q.path.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in rows), encoding="utf-8")
    assert q.agreement() == (1, 2)


def test_reliability_separates_any_from_all():
    runs = report.by_task([rec("a", True), rec("a", True), rec("b", True), rec("b", False), rec("c", False),
                           rec("c", False)])
    r = report.reliability(runs)
    assert (round(r["pass_any"], 3), round(r["pass_all"], 3), r["mean"]) == (0.667, 0.333, 0.5)
    assert report.flaky(runs) == ["b"]


def test_compare_and_bootstrap():
    base = [rec(t, False) for t in "abcd"] + [rec("e", True)]
    cand = [rec(t, True) for t in "abcd"] + [rec("e", False)]
    cmp = report.compare(base, cand)
    assert cmp["better"] == list("abcd") and cmp["worse"] == ["e"]
    assert 0.8 < cmp["prob_better"] <= 1.0
    assert report.paired_bootstrap(report.by_task(base), report.by_task(base)) == 0.0
    text = report.render("对比", cand, base)
    assert "变好的任务 4 条" in text and "变差的任务 1 条" in text


def test_render_single_version_lists_stops_and_cost():
    text = report.render("v", [rec("a", True, tokens=200), rec("b", False, stopped="max_turns", tokens=400)])
    assert "平均通过率    50.0%" in text and "max_turns 1" in text and "输入 300" in text


def test_version_id_follows_content_only():
    a = AgentVersion("p", note="一")
    assert a.id == AgentVersion("p", note="二", parent="x").id
    b = a.derive("加一条", playbook=[PlaybookItem("verify-001", "验证", "改完跑测试")])
    c = a.derive("调配置", config={"loop.max_turns": 20})
    assert len({a.id, b.id, c.id}) == 3 and b.parent == a.id
    assert AgentVersion.from_json(json.loads(json.dumps(b.to_json(), ensure_ascii=False))) == b
    assert AgentVersion.from_json(c.to_json()).config_dict == {"loop.max_turns": 20}


def test_store_head_rollback_and_runs(tmp_path):
    store = Store(tmp_path)
    v0 = AgentVersion("p0", note="v0")
    v1, v2 = v0.derive("好的修改", system_prompt="p1"), v0.derive("坏的修改", system_prompt="p2")
    assert store.head() is None
    store.save_version(v0, "merged")
    store.save_version(v1, "candidate")
    assert store.head().id == v0.id               # 候选不算当前版本
    store.save_version(v1, "merged", "验收集变好")
    store.save_version(v2, "rejected", "回归集退步")
    assert store.head().id == v1.id
    assert store.rejected_notes() == ["坏的修改 → 被拒绝：回归集退步"]
    store.promote(v0.id, "手动回退")
    assert store.head().id == v0.id and len(store.versions()) == 3

    record = rec("a", True, version=v1.id)
    record.trajectory = [{"role": "assistant", "content": "好"}]
    store.add_run(record)
    store.add_run(rec("b", False, version=v1.id))
    got = store.runs(v1.id, "accept")
    assert [(r.task_id, r.passed) for r in got] == [("a", True), ("b", False)]
    assert got[0].trajectory == record.trajectory and store.runs(v1.id, "regress") == []
    store.close()


def test_runner_records_agent_crash_and_timeout_as_results(tasks):
    class Crash:
        async def run(self, *a):
            raise RuntimeError("接口 500")

    class Slow:
        async def run(self, *a):
            import asyncio
            await asyncio.sleep(5)

    crash = go(evaluate(Crash(), CommandGrader(), V0, tasks[:2]))
    assert [(r.stopped, r.passed) for r in crash] == [("model_error", False)] * 2
    assert "接口 500" in crash[0].final_reply
    slow = go(evaluate(Slow(), CommandGrader(), V0, tasks[:1], timeout=0.1))
    assert slow[0].stopped == "timeout" and not slow[0].passed


def test_runner_gives_every_attempt_a_fresh_repo(tasks, tmp_path):
    seen = []

    class Dirty:
        async def run(self, prompt, workdir, version, allow):
            seen.append((workdir, sorted(p.name for p in workdir.iterdir())))
            (workdir / "leftover.txt").write_text("x")
            return RunOutput("", [], Usage(), "finished")

    store = Store(tmp_path)
    records = go(evaluate(Dirty(), CommandGrader(), V0, tasks[:1], attempts=3, concurrency=1, store=store))
    assert len(records) == 3 and len({w for w, _ in seen}) == 3
    assert all("leftover.txt" not in names for _, names in seen)
    assert not any(w.exists() for w, _ in seen)   # 用完即删
    assert len(store.runs(V0.id)) == 3
