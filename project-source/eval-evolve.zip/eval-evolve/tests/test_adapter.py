"""把第一个项目的 Agent 真的接进来跑一遍（模型是脚本化的，不联网）。"""
from agent.model import ScriptedModel
from agent.types import Message, ToolCall

from evo.adapters import ChatTextModel, GeneralAgentAdapter, render_playbook
from evo.graders import CommandGrader
from evo.runner import evaluate
from evo.seeds import seed
from evo.types import PlaybookItem

from conftest import go


def call(name, _id, **args):
    return Message("assistant", "", tool_calls=[ToolCall(id=_id, name=name, arguments=args)])


def test_general_agent_fixes_a_task_under_a_version(tasks):
    task = next(t for t in tasks if t.id == "invoice-tax-rounding")
    fixed = (task.solution / "billing" / "tax.py").read_text(encoding="utf-8")
    model = ScriptedModel([
        call("read_file", "c1", path="billing/tax.py"),
        call("write_file", "c2", path="billing/tax.py", content=fixed),
        call("run_command", "c3", command="python -m pytest tests -q"),
        Message("assistant", "原因是二进制浮点数的舍入，改用 Decimal 后测试通过。")])
    version = seed("minimal").derive("带手册和配置", config={"reminders.after_edit": "改完跑一次测试"}, playbook=[
        PlaybookItem("verify-001", "验证", "改完后运行失败的测试再回复。")])
    record = go(evaluate(GeneralAgentAdapter(model), CommandGrader(), version, [task]))[0]
    assert record.passed and record.stopped == "finished" and record.turns == 4

    system = record.trajectory[0]["content"]
    assert "你是一个编程助手" in system and "[verify-001] 改完后运行失败的测试再回复。" in system
    assert "{cwd}" not in system
    results = [m["content"] for m in record.trajectory if m["role"] == "tool"]
    assert results[1].endswith("（提示：改完跑一次测试）") and "passed" in results[2]


def test_disabled_tool_is_not_offered_and_command_outside_allow_is_denied(tasks):
    task = tasks[0]
    model = ScriptedModel([call("search_text", "c1", pattern="def"),
                           call("run_command", "c2", command="curl http://example.com"),
                           Message("assistant", "做不了。")])
    version = seed("minimal").derive("去掉搜索", config={"tools.enabled": ["read_file", "edit_file", "run_command"]})
    record = go(evaluate(GeneralAgentAdapter(model), CommandGrader(), version, [task]))[0]
    results = [m["content"] for m in record.trajectory if m["role"] == "tool"]
    assert not record.passed and "search_text" in results[0] and "pytest" not in results[1]
    assert "passed" not in results[1]


def test_render_playbook_groups_by_section():
    v = seed("minimal").derive("x", playbook=[PlaybookItem("verify-001", "验证", "甲"),
                                               PlaybookItem("locate-001", "定位", "乙"),
                                               PlaybookItem("verify-002", "验证", "丙")])
    assert render_playbook(v).splitlines()[1:] == ["## 验证", "- [verify-001] 甲", "- [verify-002] 丙", "## 定位",
                                                   "- [locate-001] 乙"]
    assert render_playbook(seed("minimal")) == ""


def test_chat_text_model_wraps_project_one_client():
    model = ChatTextModel(ScriptedModel([Message("assistant", "通过")]))
    assert go(model.ask("你是评分员", "内容")) == "通过"
