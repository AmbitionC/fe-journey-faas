import pytest

from evo.harness import (DEFAULT_CODE, check_code, clip, load_hook, result_hook, smoke_code, validate_config)


def test_config_changes_must_stay_in_bounds():
    assert validate_config({"loop.max_turns": 20, "reminders.after_edit": "改完跑一次测试"}) == []
    errors = validate_config({"loop.max_turns": 500, "tools.enabled": ["read_file"], "model.name": "x",
                              "tools.result_limit": True})
    assert len(errors) == 4 and any("不是可调的配置项" in e for e in errors)


def test_clip_keeps_head_and_tail():
    text = "头" * 100 + "中" * 1000 + "尾" * 100
    out = clip(text, 300)
    assert out.startswith("头" * 100) and out.endswith("尾" * 100) and "省略 900 字" in out
    assert clip("短", 300) == "短"


@pytest.mark.parametrize("source,word", [
    ("import os\ndef transform_result(name, args, result):\n    return result\n", "import os"),
    ("from subprocess import run\ndef transform_result(name, args, result):\n    return result\n", "subprocess"),
    ("def transform_result(name, args, result):\n    return open('/etc/passwd').read()\n", "open"),
    ("def transform_result(name, args, result):\n    return ().__class__.__name__\n", "__class__"),
    ("def transform_result(name, args, result):\n    return eval(result)\n", "eval"),
    ("def other(x):\n    return x\n", "必须定义"),
    ("def transform_result(:\n", "语法错误"),
])
def test_static_check_rejects(source, word):
    errors = check_code(source)
    assert errors and any(word in e for e in errors)
    with pytest.raises(ValueError):
        load_hook(source)


def test_smoke_rejects_code_that_swallows_or_breaks_results():
    assert smoke_code(DEFAULT_CODE) == []
    assert "清空" in smoke_code("def transform_result(name, args, result):\n    return ''\n")[0]
    assert "不是字符串" in smoke_code("def transform_result(name, args, result):\n    return None\n")[0]
    assert "试跑出错" in smoke_code("def transform_result(name, args, result):\n    return result[0] + 1\n")[0]


def test_hook_failure_falls_back_to_original_result():
    hook = load_hook("def transform_result(name, args, result):\n    return args['nope']\n")
    assert hook("read_file", {}, "原样") == "原样"


def test_result_hook_chains_code_clip_and_reminder():
    code = ("import re\n"
            "def transform_result(name, args, result):\n"
            "    if name != 'run_command':\n        return result\n"
            "    hits = [l for l in result.splitlines() if re.match(r'E\\s', l)]\n"
            "    return ('断言失败：\\n' + '\\n'.join(hits) + '\\n\\n' + result) if hits else result\n")
    hook = result_hook({"tools.result_limit": 500, "reminders.after_edit": "改完跑测试"}, code)
    out = hook("run_command", {"command": "pytest"}, "x" * 2000 + "\nE   assert 1 == 2\n")
    assert out.startswith("断言失败：\nE   assert 1 == 2") and "中间省略" in out
    assert hook("edit_file", {"path": "a.py"}, "已修改") == "已修改\n（提示：改完跑测试）"
    assert result_hook({}, "")("read_file", {}, "abc") == "abc"
