import asyncio
from pathlib import Path

import pytest

from evo.graders import CommandGrader
from evo.evolve.gate import Bench
from evo.runner import apply_solution
from evo.store import Store
from evo.tasks import load_tasks
from evo.types import AgentVersion, RunOutput, Usage

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="session")
def tasks():
    return load_tasks(ROOT / "tasks")


class FakeAgent:
    """不调模型的被测对象：solves(version, task) 为真就把参考解覆盖上去，否则什么都不改。"""

    def __init__(self, tasks, solves, tokens=lambda version, task: 1000):
        self.by_prompt = {t.prompt: t for t in tasks}
        self.solves, self.tokens, self.calls = solves, tokens, []

    async def run(self, task_prompt, workdir, version, allow):
        task = self.by_prompt[task_prompt]
        self.calls.append((version.id, task.id))
        ok = self.solves(version, task)
        if ok:
            apply_solution(task, workdir)
        return RunOutput("已修复，测试通过。" if ok else "看起来没问题。", [], Usage(self.tokens(version, task), 100),
                         "finished", turns=3)


@pytest.fixture
def make_bench(tasks, tmp_path):
    def make(solves, **kw):
        events = []
        tokens = kw.pop("tokens", lambda v, t: 1000)
        agent = FakeAgent(tasks, solves, tokens)
        bench = Bench(agent, CommandGrader(), tasks, Store(tmp_path / "runs"),
                      notify=lambda kind, data: events.append((kind, data)), **kw)
        return bench, agent, events
    return make


def go(coro):
    return asyncio.run(coro)


V0 = AgentVersion(system_prompt="你是编程助手。\n当前项目目录：{cwd}\n", note="v0")
