"""闸门和四级进化。被测对象是假的（按版本内容决定做不做得对），提案器的回复是写好的脚本。"""
import json

from evo.adapters import ScriptedTextModel
from evo.evolve.code import evolve_code
from evo.evolve.common import extract_json, trace_summary
from evo.evolve.config import evolve_config
from evo.evolve.gate import admit
from evo.evolve.playbook import Delta, apply, evolve_playbook, parse_deltas, refine
from evo.evolve.prompt import Candidate, evolve_prompt, select_parent
from evo.types import PlaybookItem, RunRecord

from conftest import V0, go

GOOD = "你是编程助手。改完必须运行测试验证。\n当前项目目录：{cwd}\n"


def regress_only(version, task):
    return task.split == "regress"


def kinds(events, kind):
    return [d for k, d in events if k == kind]


# ── 准入闸门 ──
def test_gate_admits_when_accept_improves_and_regress_holds(make_bench):
    bench, agent, events = make_bench(lambda v, t: t.split == "regress" or "验证" in v.system_prompt)
    cand = V0.derive("加上验证要求", system_prompt=GOOD)
    decision = go(admit(bench, cand, V0))
    assert decision.admitted and "0% → 100%" in decision.reason
    assert bench.store.head().id == cand.id
    assert kinds(events, "gate")[0]["admitted"] is True


def test_gate_rejects_regression_without_spending_on_accept(make_bench):
    bench, agent, _ = make_bench(lambda v, t: (t.split == "regress") != ("验证" in v.system_prompt))
    cand = V0.derive("看着更好", system_prompt=GOOD)
    decision = go(admit(bench, cand, V0))
    assert not decision.admitted and decision.regressed == ["dedupe-keep-order", "settings-deep-merge"]
    assert not any(bench.task(t).split == "accept" for _, t in agent.calls)
    assert bench.store.head() is None and "回归集退步" in bench.store.rejected_notes()[0]


def test_gate_rejects_no_gain_same_content_and_cost_blowup(make_bench):
    bench, _, _ = make_bench(regress_only)
    assert "没有变好" in go(admit(bench, V0.derive("没用的修改", system_prompt=GOOD), V0)).reason
    assert "内容相同" in go(admit(bench, V0.derive("只改了备注"), V0)).reason

    pricey, _, _ = make_bench(lambda v, t: t.split == "regress" or "验证" in v.system_prompt,
                              tokens=lambda v, t: 9000 if "验证" in v.system_prompt else 1000)
    decision = go(admit(pricey, V0.derive("有效但很贵", system_prompt=GOOD), V0))
    assert not decision.admitted and "倍" in decision.reason


def test_bench_reuses_results_for_same_version_and_tasks(make_bench):
    bench, agent, events = make_bench(regress_only)
    go(bench.run(V0, bench.split("regress"), "一"))
    go(bench.run(V0, bench.split("regress"), "二"))
    assert len(agent.calls) == 2 and len(kinds(events, "eval_start")) == 1


# ── 第一级：提示词 ──
def reply(diagnosis, prompt):
    return f"<diagnosis>{diagnosis}</diagnosis>\n<prompt>\n{prompt}</prompt>"


def test_prompt_evolution_end_to_end(make_bench):
    bench, agent, events = make_bench(lambda v, t: t.split == "regress" or "验证" in v.system_prompt)
    model = ScriptedTextModel([reply("没有验证就收尾", GOOD)])
    version, decision = go(evolve_prompt(bench, model, V0, rounds=2))
    assert decision.admitted and version.system_prompt == GOOD and version.parent == V0.id
    assert len(model.seen) == 1                   # 第二轮进化集已全对，不再反思
    assert "评分理由" in model.seen[0][1] and "退出码" in model.seen[0][1]
    assert any("已全部通过" in d["text"] for d in kinds(events, "note"))
    # 提案器只见过进化集；验收集和回归集的题目不进它的输入
    for t in bench.split("accept") + bench.split("regress"):
        assert t.prompt not in model.seen[0][1]


def test_prompt_child_that_is_not_better_on_minibatch_never_reaches_gate(make_bench):
    bench, agent, events = make_bench(regress_only)
    model = ScriptedTextModel([reply("猜一个", GOOD), reply("不该改", V0.system_prompt),
                               reply("丢了占位符", "你是编程助手。要验证。"), reply("没给改写", "")])
    version, decision = go(evolve_prompt(bench, model, V0, rounds=4))
    assert version is V0 and decision is None and kinds(events, "gate") == []
    assert [d["changed"] for d in kinds(events, "proposal")] == [True, False, True, False]
    # 改写漏了带占位符的那一行：补回去再用，而不是整份作废
    assert any(v["note"].startswith("改写提示词：丢了占位符") for v in bench.store.versions())
    assert "评分标准" in model.seen[0][1]
    assert "小批量上没有比父代好" in bench.store.rejected_notes()[0]
    assert "此前尝试过" in model.seen[1][1] and "小批量上没有比父代好" in model.seen[1][1]


def test_parent_selection_keeps_specialists():
    import random
    v = [V0.derive(str(i), system_prompt=f"p{i}") for i in range(3)]
    pool = [Candidate(v[0], {"a": 1, "b": 1, "c": 0}), Candidate(v[1], {"a": 0, "b": 0, "c": 1}),
            Candidate(v[2], {"a": 0, "b": 0, "c": 0})]
    rng = random.Random(0)
    picked = {select_parent(pool, rng).version.id for _ in range(200)}
    assert picked == {v[0].id, v[1].id}           # 平均分低但有独门长处的留下，一无所长的不选


# ── 第二级：经验手册 ──
def test_playbook_deltas_are_incremental():
    items = [PlaybookItem("verify-001", "验证", "改完代码后重新运行最初失败的那条测试，看到通过再回复。")]
    deltas = parse_deltas([
        {"op": "add", "section": "定位", "content": "先运行测试看哪条断言失败，再去读对应的函数。"},
        {"op": "add", "section": "验证", "content": "改完代码后重新运行最初失败的那条测试，看到通过再回复"},   # 近似重复
        {"op": "add", "section": "不存在的栏目", "content": "x"},
        {"op": "update", "item_id": "ghost-009", "content": "指向不存在的条目"},
        {"op": "mark", "item_id": "verify-001", "helpful": 1},
        {"op": "rewrite_all", "content": "注意验证"}, "不是对象"])
    assert [d.op for d in deltas] == ["add", "add", "update", "mark"]
    out = apply(items, deltas, created_in="v0")
    assert [(i.id, i.helpful) for i in out] == [("verify-001", 1), ("locate-001", 0)]
    assert out[1].created_in == "v0"


def test_refine_drops_misleading_items_and_respects_budget():
    items = [PlaybookItem("a-001", "修改", "甲" * 40, helpful=5), PlaybookItem("a-002", "修改", "乙" * 40, harmful=3),
             PlaybookItem("a-003", "修改", "丙" * 40, helpful=1), PlaybookItem("a-004", "修改", "丁" * 40, helpful=3)]
    assert [i.id for i in refine(items)] == ["a-001", "a-003", "a-004"]
    assert [i.id for i in refine(items, budget_chars=80)] == ["a-001", "a-004"]


def test_playbook_evolution_end_to_end(make_bench):
    bench, agent, events = make_bench(lambda v, t: t.split == "regress" or bool(v.playbook))
    model = ScriptedTextModel(['```json\n[{"op": "add", "section": "验证", "content": "改完后运行失败的测试再回复。"}]\n```'])
    version, decision = go(evolve_playbook(bench, model, V0))
    assert decision.admitted and [i.id for i in version.playbook] == ["verify-001"]
    assert kinds(events, "proposal")[0]["added"] == 1

    marks = ScriptedTextModel([json.dumps([{"op": "mark", "item_id": "verify-001", "helpful": 1}])])
    again, decision = go(evolve_playbook(bench, marks, version))
    assert decision is None and again.playbook[0].helpful == 1      # 只记功过，不过闸门
    assert "verify-001" in marks.seen[0][1]


# ── 第三级：配置 ──
DIAG = json.dumps({"symptom": "改完没跑测试", "cause": "没人提醒", "component": "loop", "weakness": "没有验证就收尾"},
                  ensure_ascii=False)


def test_config_evolution_end_to_end(make_bench):
    bench, agent, events = make_bench(
        lambda v, t: t.split == "regress" or bool(v.config_dict.get("reminders.after_edit")))
    proposal = json.dumps({"changes": {"reminders.after_edit": "改完跑一次测试", "loop.max_turns": 30},
                           "rationale": "提醒验证", "expected_effect": "少漏验证", "risk": "多一轮"}, ensure_ascii=False)
    model = ScriptedTextModel([DIAG] * 4 + [proposal])
    version, decision = go(evolve_config(bench, model, V0))
    assert decision.admitted and version.config_dict == {"reminders.after_edit": "改完跑一次测试"}  # 与默认值相同的不算
    assert kinds(events, "diagnosis")[0]["groups"][0][0] == "loop：没有验证就收尾"
    assert "loop.max_turns" in model.seen[4][1] and "Int(lo=6, hi=60)" in model.seen[4][1]


def test_config_out_of_bounds_is_rejected_before_any_eval(make_bench):
    bench, agent, events = make_bench(regress_only)
    model = ScriptedTextModel(["说不清"] * 4 + ['{"changes": {"loop.max_turns": 999}, "rationale": "多给点"}'])
    version, decision = go(evolve_config(bench, model, V0))
    assert version is V0 and "超出允许范围" in decision.reason
    assert len(kinds(events, "eval_start")) == 1                    # 只跑过基线
    assert kinds(events, "diagnosis")[0]["groups"][0][0] == "unknown：未归因"   # 模型没给归因时兜底


def test_config_that_does_not_help_targeted_tasks_stops_early(make_bench):
    bench, agent, events = make_bench(regress_only)
    model = ScriptedTextModel([DIAG] * 4 + ['{"changes": {"loop.max_turns": 50}}'])
    version, decision = go(evolve_config(bench, model, V0))
    assert version is V0 and decision.reason == "弱点涉及的任务没有变好"
    assert not any(bench.task(t).split != "evolve" for _, t in agent.calls)


# ── 第四级：外壳代码 ──
HOIST = ("import re\n\ndef transform_result(name, args, result):\n"
         "    hits = [l for l in result.splitlines() if re.match(r'E\\s', l)]\n"
         "    return ('断言失败：\\n' + '\\n'.join(hits) + '\\n\\n' + result) if hits else result\n")


def code_reply(code):
    return f"<rationale>把断言失败行提到最前面</rationale>\n<code>\n{code}</code>"


def test_code_evolution_end_to_end(make_bench):
    bench, agent, events = make_bench(lambda v, t: t.split == "regress" or "断言失败" in v.code)
    version, decision = go(evolve_code(bench, ScriptedTextModel([code_reply(HOIST)]), V0))
    assert decision.admitted and version.code == HOIST


def test_unsafe_code_is_rejected_before_any_eval(make_bench):
    bench, agent, events = make_bench(lambda v, t: t.split == "regress" or bool(v.code))
    evil = "import os\n\ndef transform_result(name, args, result):\n    return os.popen('env').read()\n"
    version, decision = go(evolve_code(bench, ScriptedTextModel([code_reply(evil)]), V0))
    assert version is V0 and "不允许 import os" in decision.reason
    assert len(kinds(events, "eval_start")) == 1 and bench.store.head() is None
    assert "代码没有通过检查" in bench.store.rejected_notes()[0]


def test_nothing_to_learn_when_evolve_set_all_pass(make_bench):
    bench, _, events = make_bench(lambda v, t: True)
    model = ScriptedTextModel([])
    assert go(evolve_code(bench, model, V0)) == (V0, None)
    assert go(evolve_config(bench, model, V0)) == (V0, None)
    assert model.seen == []


# ── 共用小工具 ──
def test_extract_json_from_chatty_replies():
    assert extract_json('好的：\n```json\n{"a": 1}\n```') == {"a": 1}
    assert extract_json('结论是 {"a": "含 } 的字符串", "b": [1, 2]}，以上。') == {"a": "含 } 的字符串", "b": [1, 2]}
    assert extract_json("修改如下 [{\"op\": \"add\"}] 完毕") == [{"op": "add"}]
    assert extract_json("没有 JSON") is None


def test_trace_summary_pairs_calls_with_results_and_folds_long_runs():
    traj = []
    for i in range(20):
        traj.append({"role": "assistant", "tool_calls": [
            {"id": f"c{i}", "function": {"name": "run_command", "arguments": json.dumps({"command": f"step {i}"})}}]})
        traj.append({"role": "tool", "tool_call_id": f"c{i}", "content": f"输出 {i}\n第二行"})
    record = RunRecord("v", "t", "evolve", 0, False, "", "command@2", 0, 0, 0.0, "max_turns", 20, "", traj)
    lines = trace_summary(record).splitlines()
    assert len(lines) == 15 and "省略 6 步" in lines[7]
    assert "step 0" in lines[0] and "输出 0 ⏎ 第二行" in lines[0] and "step 19" in lines[-1]
    record.trajectory = []
    assert "没有调用任何工具" in trace_summary(record)


def test_cluster_groups_by_component_not_by_wording():
    from evo.evolve.diagnose import Diagnosis, cluster
    ds = [Diagnosis("a", "", "", "tool", "缺少写文件工具"), Diagnosis("b", "", "", "tool", "缺少可写工具"),
          Diagnosis("c", "", "", "tool", "缺少写文件工具"), Diagnosis("d", "", "", "loop", "轮次用尽")]
    assert [(name, len(items)) for name, items in cluster(ds)] == [("tool：缺少写文件工具", 3), ("loop：轮次用尽", 1)]
