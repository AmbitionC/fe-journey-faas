# 任务清单

一次只做一个里程碑。验收命令全部通过、你自己读过代码之后，再开始下一个。
「容易出错的地方」先不要告诉工具，等它做完再对照，看它有没有踩到。

验收命令用 `-k` 挑出了和这个里程碑相关的用例。个别被挑中的用例可能还依赖后面才实现的部件：遇到这种情况不要让工具提前去做后面的事，把这条用例记下来，到对应的里程碑再回头验收。最后一个里程碑要求全部测试通过，前面漏掉的都会在那里暴露。

## 里程碑 0：骨架

- 范围：按项目说明文件里的目录建好所有模块。每个文件只写开头的职责说明，以及测试文件里 import 到的名字（类和函数先留空，函数体直接抛 `NotImplementedError`）。
- 有一处不能留空，因为 `tests/conftest.py` 在导入时就用到了它：`evo/types.py` 里的数据结构（尤其是 `AgentVersion`）要把字段和构造方式写全。
- 验收：`python -m pytest --collect-only -q`，所有测试文件都能被导入，不要求通过。
- 为什么要有这一步：测试文件在开头就把要用的模块全部导入了。没有骨架，后面每个里程碑的验收命令都会卡在导入错误上，看不出这个里程碑做得对不对。
- [ ] 验收通过

## 里程碑 1：任务集和评分器

- 范围：`evo/types.py`、`tasks.py`、`graders.py`
- 验收：`python -m pytest -q tests/test_tasks_and_audit.py -k "disjoint or similar_group or assign_splits" && python -m pytest -q tests/test_graders_report_store.py -k "verdict or judge or all_of or spot_check"`
- 容易出错的地方：相似任务跨集合时加载就要报错，不要等到跑完才发现。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 2：运行器、结果库和报告

- 范围：`evo/runner.py`、`store.py`、`report.py`
- 验收：`python -m pytest -q tests/test_graders_report_store.py`
- 容易出错的地方：「至少成功一次」和「每次都成功」是两个数，不要只报平均通过率。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 3：评分器审计

- 范围：`evo/audit.py`，以及 `evo/cli.py` 里的 `audit` 子命令（命令行的其余部分留到最后）
- 验收：`python -m pytest -q tests/test_tasks_and_audit.py && python -m evo.cli audit`
- 容易出错的地方：不该动手的任务，「什么都不做」应当判通过。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 4：接入被测 Agent

- 范围：`evo/adapters.py`、`harness.py`、`seeds.py`
- 验收：`python -m pytest -q tests/test_adapter.py tests/test_harness.py`
- 容易出错的地方：版本的四个字段怎样变成构造 Agent 时的参数。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 5：准入闸门

- 范围：`evo/evolve/gate.py`
- 验收：`python -m pytest -q tests/test_evolve.py -k "test_gate or bench_reuses"`
- 容易出错的地方：回归只看基线稳定通过的任务；先跑回归集，退步了就不用跑验收集。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 6：四级提案器

- 范围：`evo/evolve/` 里其余文件
- 验收：`python -m pytest -q tests/test_evolve.py`
- 容易出错的地方：提案器的输入里不能出现验收集和回归集的任务编号。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 7：命令行

- 范围：`evo/cli.py`
- 验收：`python -m pytest -q && python -m evo.cli audit`
- 容易出错的地方：跑一轮真正的进化需要模型密钥：`python -m evo.cli --store runs-stale evolve --level prompt --seed stale-rule -n 1`。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过
