# Agent 评测与自进化平台

配套教程：Agent Journey「项目实战」第二个项目。被测对象是第一个项目（`../general-agent`）的编程 Agent：
先把“它到底行不行”量准，再让它在量得准的前提下自己变好。平台本身不依赖任何第三方库。

## 运行

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ../general-agent -e ".[dev]"

python -m evo.cli audit          # 先审计评分器：不调模型，几秒钟跑完
```

审计会对每条任务构造六种已知结果的运行（按参考解修改、什么都不做、只声称修好、删测试、把断言改成恒真、
把测试标记为跳过），看评分器的判定和预期是否一致。评分器放过了作弊，后面的进化就会朝作弊的方向走，
所以这一步排在所有事情前面。

接下来的命令要调模型，配置和第一个项目相同：

```bash
export OPENAI_BASE_URL=https://api.deepseek.com   # 任何 OpenAI 兼容接口
export OPENAI_API_KEY=你的密钥
export LLM_MODEL=deepseek-chat

python -m evo.cli eval --split accept -n 3         # 评测当前版本：每条任务跑 3 次，出可靠性报告
python -m evo.cli evolve --level prompt            # 跑一轮进化
python -m evo.cli versions                         # 版本历史：谁合入了、谁被拒绝、为什么
python -m evo.cli report 新版本号 --base 旧版本号   # 两个版本在同一批任务上的对比
python -m evo.cli rollback 旧版本号                # 回退
```

想直接看到完整的一轮（基线失败、分析原因、提出修改、过闸门合入），用自带的两个有毛病的起点，
网站上的在线试用跑的就是它们：

```bash
# 提示词里混进了一条不合适的规定 → 第一级进化把它找出来改掉
python -m evo.cli --store runs-stale evolve --level prompt --seed stale-rule -n 1
# 配置里没开写文件的工具 → 第三级进化把它诊断出来
python -m evo.cli --store runs-nowrite evolve --level config --seed no-write -n 1
```

## 四级进化

四级改的是版本里四个不同的字段，过的是同一道准入闸门：验收集上更好、回归集上不退步、用量没有超出上限，才合入。

| `--level` | 改什么 | 思路来源 | 比上一级多出来的约束 |
|---|---|---|---|
| `prompt` | 系统提示词 | GEPA | 候选先在小批量上胜过父代，才花钱跑完整进化集 |
| `playbook` | 经验手册 | ACE | 只许增量修改（加、改、记功过），不许整本重写 |
| `config` | 外壳配置与工具集 | Self-Harness | 修改必须落在 `evo/harness.py` 的 `BOUNDS` 范围内 |
| `code` | 外壳代码（工具结果的加工钩子） | Meta-Harness | 先过静态检查和试跑，才允许加载 |

提案器只看得到进化集。验收集和回归集只有闸门会碰，这是“分数涨了”可信的前提。

## 任务集

`tasks/` 下每条任务一个目录：

```
tasks/invoice-tax-rounding/
  task.json     提示词、检查命令、不许改的路径、允许执行的命令、所属集合
  repo/         初始仓库（有一处真实的缺陷）
  solution/     参考解，审计评分器时用
```

自带 8 条任务：进化集 4 条、验收集 2 条、回归集 2 条。加自己的任务时照着建目录，然后跑一次 `audit`。
`similar_group` 相同的任务必须在同一个集合里，加载时会检查。

## 接别的 Agent

平台对被测对象只有一个要求（`evo/types.py` 的 `AgentUnderTest`）：

```python
async def run(self, task_prompt, workdir, version, allow) -> RunOutput: ...
```

`evo/adapters.py` 里的 `GeneralAgentAdapter` 是接第一个项目的写法，三十行。

## 测试

```bash
pytest
```

测试不联网、不花钱：被测对象和提案模型都是脚本化的，评分器和任务仓库是真的。

## 目录

| 位置 | 内容 | 对应章节 |
|---|---|---|
| `evo/types.py`、`evo/store.py` | 版本、任务、运行记录；结果库与版本库 | 整体架构 |
| `evo/tasks.py`、`tasks/` | 任务集与三套集合的划分 | 任务集 |
| `evo/graders.py` | 代码判定、模型裁判、人工抽检 | 评分器 |
| `evo/runner.py`、`evo/report.py` | 运行器；可靠性、配对比较、成本 | 可靠性与成本 |
| `evo/audit.py` | 评分器审计 | 审计评分器 |
| `evo/evolve/gate.py` | 准入闸门 | 整体架构 |
| `evo/evolve/prompt.py` | 第一级：提示词 | 提示词进化 |
| `evo/evolve/playbook.py` | 第二级：经验手册 | 经验手册 |
| `evo/evolve/diagnose.py`、`evo/evolve/config.py`、`evo/harness.py` | 失败分析；第三级：配置 | 外壳配置 |
| `evo/evolve/code.py`、`evo/harness.py` | 第四级：外壳代码 | 外壳代码 |
| `evo/adapters.py`、`evo/seeds.py` | 被测对象的适配器；起点版本 | 整体架构 |
| `trial/plugin.py` | 网站「在线试用」的场景，挂在第一个项目的试用入口上 | |
