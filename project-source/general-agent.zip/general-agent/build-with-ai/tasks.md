# 任务清单

一次只做一个里程碑。验收命令全部通过、你自己读过代码之后，再开始下一个。
「容易出错的地方」先不要告诉工具，等它做完再对照，看它有没有踩到。

验收命令用 `-k` 挑出了和这个里程碑相关的用例。个别被挑中的用例可能还依赖后面才实现的部件：遇到这种情况不要让工具提前去做后面的事，把这条用例记下来，到对应的里程碑再回头验收。最后一个里程碑要求全部测试通过，前面漏掉的都会在那里暴露。

## 里程碑 0：骨架

- 范围：按项目说明文件里的目录建好所有模块。每个文件只写开头的职责说明，以及测试文件里 import 到的名字（类和函数先留空，函数体直接抛 `NotImplementedError`）。
- 有一处不能留空，因为测试文件在导入时就用到了它：`agent/kernel/permission.py` 里的 `Rule` 要把三个字段（工具名、匹配模式、决定）写全，`tests/test_hooks_commands_plan.py` 一导入就会构造一条规则。
- 验收：`python -m pytest --collect-only -q`，所有测试文件都能被导入，不要求通过。
- 为什么要有这一步：测试文件在开头就把要用的模块全部导入了。没有骨架，后面每个里程碑的验收命令都会卡在导入错误上，看不出这个里程碑做得对不对。
- [ ] 验收通过

## 里程碑 1：消息类型、模型接口和最小循环

- 范围：`agent/types.py`、`agent/model.py`、`agent/kernel/loop.py` 的主循环，还没有权限。测试都通过 `agent/build.py` 的 `build_coding_agent` 拿到 Agent，所以这一步也要写它的最小版本（只装模型和循环，其余参数先收下不用），之后每个里程碑把新部件接进去
- 验收：`python -m pytest -q tests/test_kernel.py -k "finishes or stream_parser or retries or max_turns"`
- 容易出错的地方：流式响应里工具参数是分片到达的，要按下标拼接；参数不是合法 JSON 时不能抛异常。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 2：工具注册表和六个工具

- 范围：`agent/tools/`
- 验收：`python -m pytest -q tests/test_kernel.py -k "read or write or edit or failing_command or timeout or parallel"`
- 容易出错的地方：改文件用唯一片段替换：片段出现零次和多次都要报错并说明原因。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 3：权限闸门

- 范围：`agent/kernel/permission.py`，并接进循环
- 验收：`python -m pytest -q tests/test_kernel.py`
- 容易出错的地方：`rm -rf` 和 `rm -fr` 是同一件事，按参数集合判断而不是字符串；重定向等于写文件。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 4：上下文管理

- 范围：`agent/kernel/context.py`
- 验收：`python -m pytest -q tests/test_context_memory_subagent.py -k "split or clears or threshold or compaction"`
- 容易出错的地方：切分点不能落在一次工具调用和它的结果之间。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 5：记忆和会话记录

- 范围：`agent/state/`
- 验收：`python -m pytest -q tests/test_context_memory_subagent.py -k "dedup or instructions"`
- 容易出错的地方：查重按用词重合度，中文按相邻两个字切。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 6：子任务

- 范围：`agent/kernel/subagent.py`
- 验收：`python -m pytest -q tests/test_context_memory_subagent.py -k "isolated or nest"`
- 容易出错的地方：子任务的工具表要重新构造，不能把主任务的写工具带进去。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 7：扩展：MCP 和技能

- 范围：`agent/extensions/mcp_client.py`、`skills.py`
- 验收：`python -m pytest -q tests/test_extensions.py`
- 容易出错的地方：技能缺 name 或 description 时直接跳过。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 8：计划模式、斜杠命令、钩子、记忆整理

- 范围：`agent/extensions/hooks.py`、`commands.py`、`agent/state/dream.py`，闸门加开关
- 验收：`python -m pytest -q tests/test_hooks_commands_plan.py`
- 容易出错的地方：计划模式的复位要放在 finally 里。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 9：研究模式

- 范围：`agent/research/`、`agent/tools/research/`
- 验收：`python -m pytest -q tests/test_research.py`
- 容易出错的地方：报告里的每个引用编号都要能在来源库里找到。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 10：终端入口和评测运行器

- 范围：`agent/cli.py`、`agent/evals/`
- 验收：`python -m pytest -q && python -m agent.cli -p "列出当前目录有哪些文件" -C fixtures/shop`
- 容易出错的地方：这一步的第二条命令需要模型密钥，是整个项目第一次真正调用模型。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过
