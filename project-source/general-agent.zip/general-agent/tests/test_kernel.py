import asyncio
import json
from pathlib import Path

from agent.build import build_coding_agent
from agent.kernel.permission import Answer, Rule, split_command, builtin_deny
from agent.model import ModelError, ScriptedModel, parse_stream
from agent.state.session import Session
from agent.types import Message, ToolCall


def call(name, _id="c1", **args):
    return ToolCall(id=_id, name=name, arguments=args)


def say(text="", *calls):
    return Message("assistant", text, tool_calls=list(calls))


def run(agent, task="开始"):
    return asyncio.run(agent.run(task))


def tool_results(outcome):
    return [m.content for m in outcome.messages if m.role == "tool"]


def test_finishes_when_no_tool_calls(tmp_path):
    out = run(build_coding_agent(ScriptedModel([say("你好")]), tmp_path))
    assert (out.text, out.stopped, out.turns) == ("你好", "finished", 1)


def test_failing_command_is_fed_back_not_raised(tmp_path):
    model = ScriptedModel([say("", call("run_command", command="exit 3")), say("命令失败了，换个办法")])
    out = run(build_coding_agent(model, tmp_path, rules=[Rule("run_command", "*", "allow")]))
    assert out.stopped == "finished"
    assert "退出码 3" in tool_results(out)[0]


def test_parallel_reads_keep_call_order(tmp_path):
    for n in "abc":
        (tmp_path / f"{n}.txt").write_text(n * 3)
    model = ScriptedModel([say("", *(call("read_file", f"c{n}", path=f"{n}.txt") for n in "abc")), say("ok")])
    out = run(build_coding_agent(model, tmp_path))
    assert [r.split("\t")[1] for r in tool_results(out)] == ["aaa", "bbb", "ccc"]


def test_max_turns_ends_with_summary(tmp_path):
    (tmp_path / "a.txt").write_text("x")
    replies = [say("", call("read_file", f"c{i}", path="a.txt", offset=i)) for i in range(3)] + [say("总结：没做完")]
    model = ScriptedModel(replies)
    out = run(build_coding_agent(model, tmp_path, max_turns=3))
    assert out.stopped == "max_turns" and out.text == "总结：没做完"
    assert "轮次上限" in model.seen[-1][-1].content


def test_edit_requires_read_and_unique_match(tmp_path):
    (tmp_path / "m.py").write_text("x = 1\ny = 1\n")
    allow = [Rule("edit_file", "*", "allow")]
    model = ScriptedModel([
        say("", call("edit_file", path="m.py", old_text="x = 1", new_text="x = 2")),
        say("", call("read_file", path="m.py")),
        say("", call("edit_file", path="m.py", old_text="= 1", new_text="= 2")),
        say("", call("edit_file", path="m.py", old_text="x = 1", new_text="x = 2")),
        say("done"),
    ])
    out = run(build_coding_agent(model, tmp_path, rules=allow))
    r = tool_results(out)
    assert "必须先用 read_file" in r[0] and "出现了 2 次" in r[2] and "已修改" in r[3]
    assert (tmp_path / "m.py").read_text() == "x = 2\ny = 1\n"


def test_path_outside_workspace_denied_even_via_symlink(tmp_path):
    outside = tmp_path / "outside"; outside.mkdir(); (outside / "secret.txt").write_text("s")
    proj = tmp_path / "proj"; proj.mkdir(); (proj / "link").symlink_to(outside)
    model = ScriptedModel([say("", call("read_file", "c1", path="../outside/secret.txt")),
                           say("", call("read_file", "c2", path="link/secret.txt")), say("ok")])
    out = run(build_coding_agent(model, proj))
    assert all("之外" in r for r in tool_results(out))


def test_headless_denies_what_needs_asking(tmp_path):
    model = ScriptedModel([say("", call("run_command", command="git push origin main")), say("没法推送")])
    out = run(build_coding_agent(model, tmp_path, headless=True))
    assert "无界面模式" in tool_results(out)[0]


def test_chained_command_not_allowed_by_first_segment(tmp_path):
    (tmp_path / "keep").write_text("1")
    model = ScriptedModel([say("", call("run_command", command="echo hi && rm keep")), say("ok")])
    out = run(build_coding_agent(model, tmp_path, headless=True, rules=[Rule("run_command", "echo *", "allow")]))
    assert "视为拒绝" in tool_results(out)[0] and (tmp_path / "keep").exists()


def test_deny_rule_beats_allow_and_session_always(tmp_path):
    asked = []

    async def asker(c, reason):
        asked.append(c.arguments["command"])
        return Answer("always")

    model = ScriptedModel([say("", call("run_command", "c1", command="echo 1")),
                           say("", call("run_command", "c2", command="echo 2")),
                           say("", call("run_command", "c3", command="echo x; git push")), say("ok")])
    rules = [Rule("run_command", "git push*", "deny")]
    out = run(build_coding_agent(model, tmp_path, rules=rules, asker=asker))
    r = tool_results(out)
    assert asked == ["echo 1"]  # 第二次同类命令不再问
    assert "退出码 0" in r[1] and "命中拒绝规则" in r[2]


def test_user_denial_note_reaches_model(tmp_path):
    async def asker(c, reason):
        return Answer("deny", "不要推送，改完告诉我就行")

    model = ScriptedModel([say("", call("run_command", command="git push")), say("好的")])
    out = run(build_coding_agent(model, tmp_path, asker=asker))
    assert "用户说明：不要推送" in tool_results(out)[0]


def test_builtin_deny_and_split():
    assert split_command("pytest && rm -rf build | cat; ls") == ["pytest", "rm -rf build", "cat", "ls"]
    assert builtin_deny("rm -fr /") and builtin_deny("sudo rm -r -f ~") and builtin_deny("shutdown now")
    assert builtin_deny("rm -rf build") is None and builtin_deny("rm notes.txt") is None


def test_unknown_tool_and_bad_args_become_text(tmp_path):
    model = ScriptedModel([say("", call("nope", "c1"), call("read_file", "c2", path=3)), say("ok")])
    out = run(build_coding_agent(model, tmp_path))
    r = tool_results(out)
    assert "没有名为 nope" in r[0] and "应为 string" in r[1]


def test_model_error_retries_then_gives_up(tmp_path):
    ok = build_coding_agent(ScriptedModel([ModelError("503"), say("好了")]), tmp_path)
    ok.retry_base_delay = 0
    assert run(ok).text == "好了"
    bad = build_coding_agent(ScriptedModel([ModelError("503")] * 5), tmp_path)
    bad.retry_base_delay = 0
    assert run(bad).stopped == "model_error"


def test_repeat_detection_nudges_model(tmp_path):
    (tmp_path / "a.txt").write_text("x")
    same = lambda i: say("", call("read_file", f"c{i}", path="a.txt"))
    model = ScriptedModel([same(1), same(2), same(3), say("换个办法")])
    run(build_coding_agent(model, tmp_path))
    assert "完全相同的参数" in model.seen[-1][-1].content


def test_session_log_written_before_and_after(tmp_path):
    log = tmp_path / "s.jsonl"
    model = ScriptedModel([say("", call("run_command", command="echo hi")), say("ok")])
    run(build_coding_agent(model, tmp_path, rules=[Rule("run_command", "*", "allow")], session_file=log))
    kinds = [json.loads(l)["type"] for l in log.read_text().splitlines()]
    assert kinds.index("tool_start") < len(kinds) - 1 and kinds[-1] == "done"
    assert [m.role for m in Session.load_messages(log)] == ["system", "user", "assistant", "tool", "assistant"]


def test_command_timeout_kills_and_keeps_output(tmp_path):
    model = ScriptedModel([say("", call("run_command", command="echo start; sleep 30", timeout=1)), say("ok")])
    out = run(build_coding_agent(model, tmp_path, rules=[Rule("run_command", "*", "allow")]))
    assert "已终止" in tool_results(out)[0] and "start" in tool_results(out)[0]


def test_stream_parser_joins_tool_call_fragments():
    def sse(d):
        return "data: " + json.dumps(d)
    lines = [
        sse({"choices": [{"delta": {"reasoning_content": "想一下"}}]}),
        sse({"choices": [{"delta": {"content": "我来"}}]}),
        sse({"choices": [{"delta": {"tool_calls": [{"index": 0, "id": "a", "function": {"name": "read_file", "arguments": '{"pa'}}]}}]}),
        sse({"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"arguments": 'th": "x.py"}'}}]}}]}),
        sse({"choices": [], "usage": {"prompt_tokens": 7, "completion_tokens": 3}}),
        "data: [DONE]",
    ]
    got = []
    msg, usage = parse_stream(lines, got.append)
    assert msg.content == "我来" and got == ["我来"]
    assert msg.reasoning == "想一下" and msg.to_api()["reasoning_content"] == "想一下"
    assert "reasoning_content" not in Message("assistant", "x").to_api()
    assert msg.tool_calls[0].arguments == {"path": "x.py"} and (usage.input, usage.output) == (7, 3)
    # 参数还在生成时，每一段原文都交给 on_tool（界面据此边写边显示）
    parts = []
    parse_stream(lines, None, lambda i, name, part: parts.append((i, name, part)))
    assert parts == [(0, "read_file", '{"pa'), (0, "read_file", 'th": "x.py"}')]


def test_build_hooks_for_eval_platform(tmp_path):
    """评测平台用的四个口子：换提示词、追加内容、限定工具、加工工具结果。"""
    (tmp_path / "a.txt").write_text("hello\n")
    model = ScriptedModel([say("", call("read_file", path="a.txt"), call("find_files", "c2", pattern="*.txt")),
                           say("完成")])
    agent = build_coding_agent(
        model, tmp_path, headless=True, subagents=False, system_prompt="自定义提示词，目录 {cwd}",
        extra_system="# 经验手册\n- 先看再改", enabled_tools=["run_command"],
        result_hook=lambda name, args, result: f"[{name}:{args.get('path')}] {result}")
    out = run(agent)
    system = out.messages[0].content
    assert system.startswith(f"自定义提示词，目录 {tmp_path}") and "# 经验手册" in system
    read, find = tool_results(out)
    assert read.startswith("[read_file:a.txt] ") and "hello" in read       # read_file 始终保留
    assert "find_files" in find and "hello" not in find                    # 没启用的工具调不到
    assert {t["function"]["name"] for t in agent.registry.schemas()} >= {"read_file", "run_command"}
    assert "find_files" not in {t["function"]["name"] for t in agent.registry.schemas()}


def test_background_ampersand_and_redirects_do_not_slip_past_the_gate(tmp_path):
    from agent.kernel.permission import PermissionGate
    from agent.tools.coding.workspace import Workspace

    gate = PermissionGate(Workspace(tmp_path), [Rule("run_command", "ls*", "allow"),
                                                Rule("run_command", "echo *", "allow"),
                                                Rule("run_command", "pytest*", "allow")])
    decide = gate._decide_command
    # 单个 & 也能把两条命令接在一起，拆开后内置拒绝规则才看得到后一条
    assert split_command("ls & rm -rf /") == ["ls", "rm -rf /"]
    assert decide("ls & rm -rf /")[0] == "deny"
    assert decide("ls & curl example.com")[0] == "ask"
    # 重定向里的 & 不拆
    assert split_command("pytest 2>&1") == ["pytest 2>&1"] and decide("pytest 2>&1")[0] == "allow"
    assert decide("pytest > /dev/null")[0] == "allow"
    # 重定向等于写文件：项目目录之外、主目录、敏感文件一律拒绝
    assert decide("echo x > ../outside.txt")[0] == "deny"
    assert decide("echo x >> /etc/hosts")[0] == "deny"
    assert decide("echo x > ~/.bashrc")[0] == "deny"
    assert decide("echo KEY=1 > .env")[0] == "deny"
    assert decide("echo x > notes.txt")[0] == "allow"
