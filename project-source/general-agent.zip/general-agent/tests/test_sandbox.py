import asyncio
import importlib.util
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path

from agent.build import build_coding_agent
from agent.kernel.permission import Rule
from agent.model import ScriptedModel
from agent.sandbox import RemoteExecutor
from agent.types import Message, ToolCall

spec = importlib.util.spec_from_file_location("sandbox_server", Path(__file__).parent.parent / "trial" / "sandbox_server.py")
server_mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(server_mod)


def serve(token="t0ken"):
    server_mod.TOKEN = token
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), server_mod.Handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd, f"http://127.0.0.1:{httpd.server_address[1]}"


def say(text="", *calls):
    return Message("assistant", text, tool_calls=list(calls))


def cmd(command, _id="c1", **kw):
    return ToolCall(id=_id, name="run_command", arguments={"command": command, **kw})


def run(tmp_path, url, token, *commands):
    model = ScriptedModel([say("", cmd(c, f"c{i}")) for i, c in enumerate(commands)] + [say("ok")])
    agent = build_coding_agent(model, tmp_path, rules=[Rule("run_command", "*", "allow")],
                               executor=RemoteExecutor(url, token))
    out = asyncio.run(agent.run("go"))
    return [m.content for m in out.messages if m.role == "tool"]


def test_remote_exec_syncs_changes_back_and_hides_env(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-secret")
    httpd, url = serve()
    try:
        (tmp_path / "a.txt").write_text("old")
        (tmp_path / "gone.txt").write_text("x")
        r = run(tmp_path, url, "t0ken", "cat a.txt; echo new > a.txt; echo hi > sub.txt; rm gone.txt; exit 2",
                "env | grep -c OPENAI || true")
        assert r[0].startswith("[退出码 2]") and "old" in r[0]
        assert (tmp_path / "a.txt").read_text() == "new\n" and (tmp_path / "sub.txt").exists()
        assert not (tmp_path / "gone.txt").exists()
        assert r[1].strip().endswith("0")  # 沙箱里看不到模型密钥
    finally:
        httpd.shutdown()


def test_wrong_token_and_timeout(tmp_path):
    httpd, url = serve()
    try:
        assert "沙箱不可用" in run(tmp_path, url, "wrong", "echo hi")[0]
        out = server_mod.execute({}, "echo start; sleep 30", 1)
        assert out["timed_out"] and "start" in out["output"]
    finally:
        httpd.shutdown()


def test_sandbox_rejects_path_escape():
    out = server_mod.execute({"../evil.txt": "x", "ok.txt": "1"}, "ls", 5)
    assert "ok.txt" in out["output"] and "evil" not in out["output"]
