import asyncio

from agent.build import build_coding_agent
from agent.kernel.context import ContextManager, safe_split_point
from agent.kernel.permission import Rule
from agent.model import ScriptedModel
from agent.state.memory import MemoryStore
from agent.types import Message, ToolCall


def call(name, _id="c1", **args):
    return ToolCall(id=_id, name=name, arguments=args)


def say(text="", *calls):
    return Message("assistant", text, tool_calls=list(calls))


def history(n_rounds, size=4000):
    msgs = [Message("system", "sys"), Message("user", "修好测试，不要动测试文件")]
    for i in range(n_rounds):
        msgs.append(say("", call("read_file", f"c{i}", path=f"f{i}.py")))
        msgs.append(Message("tool", "x" * size, tool_call_id=f"c{i}"))
    return msgs


def test_safe_split_never_separates_call_and_result():
    msgs = history(4)
    for target in range(len(msgs)):
        i = safe_split_point(msgs, target)
        assert msgs[i].role != "tool" and not msgs[i - 1].tool_calls if i else True


def test_clears_old_tool_results_but_keeps_call_record_and_recent():
    msgs = history(10)
    cm = ContextManager(window_tokens=10_000, keep_recent=4)
    asyncio.run(cm.prepare(msgs))
    tools = [m for m in msgs if m.role == "tool"]
    assert tools[0].content.startswith('[此处是 read_file(path="f0.py")') and tools[-1].content == "x" * 4000
    assert sum(1 for m in msgs if m.tool_calls) == 10  # 调用记录都在


def test_under_threshold_untouched():
    msgs = history(2)
    asyncio.run(ContextManager(window_tokens=100_000).prepare(msgs))
    assert all(m.content == "x" * 4000 for m in msgs if m.role == "tool")


def test_compaction_keeps_system_recent_and_valid_pairs():
    msgs = history(10)
    summarizer = ScriptedModel([say("摘要：用户要求不要动测试文件")])
    cm = ContextManager(window_tokens=4_000, keep_recent=4, summarizer=summarizer)
    asyncio.run(cm.prepare(msgs))
    assert msgs[0].role == "system" and "不要动测试文件" in msgs[1].content and cm.stats["compactions"] == 1
    ids = {c.id for m in msgs for c in m.tool_calls}
    assert all(m.tool_call_id in ids for m in msgs if m.role == "tool")  # 没有落单的工具结果
    assert msgs[-1].content == "x" * 4000


def test_memory_dedup_scope_and_index(tmp_path):
    a = MemoryStore(tmp_path / "m.db", scope="/proj/a")
    assert "已记住" in a.save("preference", "缩进用空格", "本项目 Python 代码缩进用四个空格")
    assert "已更新" in a.save("preference", "缩进用制表符", "本项目 Python 代码缩进改用制表符")
    assert a.index().count("#") == 1 and "制表符" in a.index()
    a.save("fact", "部署在杭州", "生产环境在杭州地域", is_global=True)
    b = MemoryStore(tmp_path / "m.db", scope="/proj/b")
    assert "杭州" in b.index() and "缩进" not in b.index()
    assert "制表符" in a.read(1) and a.stale() == [(2, "部署在杭州")]


def test_memory_index_and_instructions_reach_system_prompt(tmp_path):
    proj = tmp_path / "proj"; proj.mkdir(); (proj / "AGENT.md").write_text("- 运行测试：pytest -x -q")
    MemoryStore(tmp_path / "m.db", scope=str(proj.resolve())).save("lesson", "先跑单测再跑全量", "全量很慢")
    agent = build_coding_agent(ScriptedModel([say("ok")]), proj, memory_db=tmp_path / "m.db", home=tmp_path)
    system = agent.messages[0].content
    assert "pytest -x -q" in system and "先跑单测再跑全量" in system and "全量很慢" not in system


def test_subagent_isolated_readonly_and_returns_only_conclusion(tmp_path):
    (tmp_path / "a.py").write_text("def calculate_discount(): pass\n")
    model = ScriptedModel([
        say("", call("spawn_subagent", "m1", task="在项目里找出 calculate_discount 的定义位置，返回路径和行号")),
        say("", call("search_text", "s1", pattern="calculate_discount")),  # 子任务的第一轮
        say("定义在 a.py 第 1 行"),  # 子任务的结论
        say("找到了，在 a.py"),  # 主任务收尾
    ])
    agent = build_coding_agent(model, tmp_path)
    out = asyncio.run(agent.run("这个函数在哪"))
    assert out.text == "找到了，在 a.py"
    assert [m.content for m in out.messages if m.role == "tool"] == ["定义在 a.py 第 1 行"]
    sub_first = model.seen[1]
    assert len(sub_first) == 2 and "看不到派发者" in sub_first[0].content  # 子任务上下文里只有任务说明


def test_subagent_cannot_write_or_nest(tmp_path):
    model = ScriptedModel([
        say("", call("spawn_subagent", "m1", task="改一下 a.py")),
        say("", call("write_file", "s1", path="a.py", content="x"), call("spawn_subagent", "s2", task="再派一个")),
        say("我没有写文件的工具"),
        say("好"),
    ])
    agent = build_coding_agent(model, tmp_path, rules=[Rule("*", "*", "allow")])
    asyncio.run(agent.run("go"))
    sub_results = [m.content for m in model.seen[2] if m.role == "tool"]
    assert all("没有名为" in r for r in sub_results) and not (tmp_path / "a.py").exists()
