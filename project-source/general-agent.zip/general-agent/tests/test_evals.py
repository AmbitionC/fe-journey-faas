import asyncio
from pathlib import Path

from agent.evals.runner import Task, run_suite, summarize
from agent.model import ScriptedModel
from agent.types import Message, ToolCall

TASK = Path(__file__).parent.parent / "evals" / "tasks" / "cart-rounding.json"

FIXED = '''from decimal import ROUND_HALF_UP, Decimal


def _money(value: Decimal) -> float:
    return float(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def line_total(price: float, quantity: int) -> float:
    return _money(Decimal(str(price)) * quantity)


def cart_total(items: list[dict], discount: float = 0.0) -> float:
    subtotal = sum(Decimal(str(line_total(i["price"], i["quantity"]))) for i in items)
    return _money(subtotal * (Decimal("1") - Decimal(str(discount))))
'''


def call(name, _id, **args):
    return ToolCall(id=_id, name=name, arguments=args)


def say(text="", *calls):
    return Message("assistant", text, tool_calls=list(calls))


def run_with(replies, tmp_path):
    task = Task.load(TASK)
    return asyncio.run(run_suite([task], ScriptedModel(replies), tmp_path / "s"))[0]


def test_real_fix_passes(tmp_path):
    r = run_with([say("", call("read_file", "1", path="shop/cart.py")),
                  say("", call("write_file", "2", path="shop/cart.py", content=FIXED)),
                  say("", call("run_command", "3", command="python -m pytest tests/test_cart.py -q")),
                  say("修好了")], tmp_path)
    assert r.passed and r.stopped == "finished" and r.turns == 4, r.reason
    assert Path(r.session_file).is_file()


def test_deleting_tests_does_not_pass(tmp_path):
    r = run_with([say("", call("read_file", "1", path="tests/test_cart.py")),
                  say("", call("write_file", "2", path="tests/test_cart.py", content="def test_ok():\n    assert True\n")),
                  say("修好了")], tmp_path)
    assert not r.passed and "不允许修改" in r.reason


def test_doing_nothing_fails_and_fixture_untouched(tmp_path):
    r = run_with([say("我看了一下，应该没问题")], tmp_path)
    assert not r.passed and "退出码" in r.reason
    assert "round(price * quantity, 2)" in (Path(Task.load(TASK).repo) / "shop" / "cart.py").read_text()


def test_summary_counts_flaky(tmp_path):
    from agent.evals.runner import Result
    rs = [Result("a", True, "", 3, 100, 10, 1.0, "finished", ""), Result("a", False, "", 5, 300, 30, 3.0, "max_turns", ""),
          Result("b", True, "", 2, 100, 10, 1.0, "finished", ""), Result("b", True, "", 2, 100, 10, 1.0, "finished", "")]
    s = summarize(rs)
    assert (s["pass_rate"], s["pass_any"], s["pass_all"], s["flaky"]) == (0.75, 1.0, 0.5, ["a"])
    assert s["stopped"] == {"finished": 3, "max_turns": 1} and s["per_task"] == {"a": "1/2", "b": "2/2"}
