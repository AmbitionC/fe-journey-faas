import importlib.util
import json
import threading
import time
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from agent.types import Message, ToolCall, Usage

HERE = Path(__file__).parent


def load(name):
    spec = importlib.util.spec_from_file_location(name, HERE.parent / "trial" / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


brain, sandbox = load("brain_server"), load("sandbox_server")
FIXED = (HERE / "test_evals.py").read_text().split("FIXED = '''")[1].split("'''")[0]


def start(handler):
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd, f"http://127.0.0.1:{httpd.server_address[1]}"


def test_ticket_sign_verify_expiry_tamper_and_single_use():
    t = brain.sign({"jti": "a1", "exp": time.time() + 60, "uid": 7}, "s3cret")
    assert brain.verify(t, "s3cret")["uid"] == 7
    assert brain.verify(t, "s3cret") is None  # 同一张票据只能用一次
    assert brain.verify(brain.sign({"jti": "a2", "exp": time.time() - 1}, "s3cret"), "s3cret") is None
    assert brain.verify(brain.sign({"jti": "a3", "exp": time.time() + 60}, "other"), "s3cret") is None
    assert brain.verify("garbage", "s3cret") is None and brain.verify(t, "") is None


def test_end_to_end_trial_stream(monkeypatch):
    def call(name, _id, **args):
        return ToolCall(id=_id, name=name, arguments=args)

    script = [
        Message("assistant", "先看代码", [call("read_file", "1", path="shop/cart.py")]),
        Message("assistant", "", [call("write_file", "2", path="shop/cart.py", content=FIXED)]),
        Message("assistant", "", [call("run_command", "3", command="python -m pytest tests/test_cart.py -q")]),
        Message("assistant", "", [call("run_command", "4", command="curl http://example.com")]),
        Message("assistant", "修好了：改用 Decimal 四舍五入。"),
    ]

    class Fake:
        async def chat(self, messages, tools, on_text=None):
            reply = script.pop(0)
            if on_text and reply.content:
                on_text(reply.content)
            return reply, Usage(100, 20)

    sandbox.TOKEN = "sb"
    sb, sb_url = start(sandbox.Handler)
    monkeypatch.setattr(brain, "OpenAICompatModel", Fake)
    monkeypatch.setattr(brain, "SANDBOX_URL", sb_url)
    monkeypatch.setattr(brain, "SANDBOX_TOKEN", "sb")
    monkeypatch.setattr(brain, "TICKET_SECRET", "s3cret")
    br, br_url = start(brain.Handler)
    try:
        def post(body):
            req = urllib.request.Request(br_url + "/run", data=json.dumps(body).encode(),
                                         headers={"Content-Type": "application/json"})
            return urllib.request.urlopen(req, timeout=60)

        try:
            post({"ticket": "bad"})
            assert False
        except urllib.error.HTTPError as e:
            assert e.code == 401
        ticket = brain.sign({"jti": "e2e", "exp": time.time() + 60}, "s3cret")
        raw = post({"ticket": ticket, "scenario": "shop"}).read().decode()
        events = [json.loads(l[6:]) for l in raw.splitlines() if l.startswith("data: ")]
        kinds = [e["type"] for e in events]
        assert kinds[0] == "start" and kinds[-1] == "done"
        ends = [e for e in events if e["type"] == "tool_end"]
        assert "3 passed" in ends[2]["result"]  # 测试真的在沙箱里跑过了
        assert ends[3]["denied"] and "无界面模式" in ends[3]["result"]  # 放行清单之外的命令被拒绝
        done = events[-1]
        assert done["stopped"] == "finished" and done["changed_files"][0]["path"] == "shop/cart.py"
        assert "round(price * quantity, 2)" in (HERE.parent / "fixtures/shop/shop/cart.py").read_text()
    finally:
        sb.shutdown(); br.shutdown()
