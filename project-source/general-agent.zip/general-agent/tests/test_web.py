"""本地网页工作台：用脚本化的假模型驱动，起真的 HTTP 服务，走完一次任务。"""
import json
import threading
import urllib.error
import urllib.request
from pathlib import Path

from agent.types import Message, ToolCall, Usage
from agent.web.server import ALLOW, serve

STORE = Path(__file__).parent.parent / "fixtures" / "store"


def call(name, _id, **args):
    return ToolCall(id=_id, name=name, arguments=args)


def fake_model(script):
    class Fake:
        async def chat(self, messages, tools, on_text=None):
            reply = script.pop(0)
            if on_text and reply.content:
                on_text(reply.content)
            return reply, Usage(100, 20)

    return Fake


def start(script):
    httpd, bench = serve(STORE, port=0, model_factory=fake_model(script), max_turns=10)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd, bench, f"http://127.0.0.1:{httpd.server_address[1]}"


def post(url, body=None, headers=None):
    req = urllib.request.Request(url, data=json.dumps(body or {}).encode(),
                                 headers={"content-type": "application/json", **(headers or {})})
    with urllib.request.urlopen(req, timeout=30) as res:
        return res.read().decode()


def events(raw):
    return [json.loads(line[6:]) for line in raw.split("\n") if line.startswith("data: ")]


def test_page_state_run_and_reset():
    script = [
        Message("assistant", "先看库存模块", [call("read_file", "1", path="store/inventory.py")]),
        Message("assistant", "", [call("edit_file", "2", path="store/inventory.py",
                                       old_text="if self.stock.get(sku, 0) < quantity:",
                                       new_text="if self.available(sku) < quantity:")]),
        Message("assistant", "", [call("run_command", "3", command="python -m pytest -q tests/test_orders.py")]),
        Message("assistant", "", [call("run_command", "4", command="curl http://example.com")]),
        Message("assistant", "改好了：预占时按可售数量判断。"),
    ]
    httpd, bench, url = start(script)
    try:
        page = urllib.request.urlopen(url, timeout=10).read().decode()
        assert "本地工作台" in page and "/api/run" in page
        state = json.loads(urllib.request.urlopen(f"{url}/api/state", timeout=10).read())
        assert state["repo"] == "store" and "store/inventory.py" in state["files"]
        assert state["files"] == state["pristine"] and len(state["samples"]) == 4

        evs = events(post(f"{url}/api/run", {"task": "排查超卖"}))
        assert evs[0]["type"] == "start" and evs[-1]["type"] == "done"
        ends = {e["id"]: e for e in evs if e["type"] == "tool_end"}
        assert "passed" in ends["3"]["result"]          # 测试真的在工作副本里跑了
        assert ends["4"]["denied"] is True              # 没放行的命令被闸门拦下，页面能看到
        assert ends["4"]["arguments"] == {"command": "curl http://example.com"}
        assert not any(e["type"] == "tool_start" and e["id"] == "4" for e in evs)
        done = evs[-1]
        assert done["stopped"] == "finished"
        assert [f["path"] for f in done["changed_files"]] == ["store/inventory.py"]
        assert "self.available(sku) < quantity" in done["files"]["store/inventory.py"]
        # 原目录没被动过，改动只在工作副本里
        assert "self.available(sku) < quantity" not in (STORE / "store" / "inventory.py").read_text(encoding="utf-8")
        assert bench.history == [("user", "排查超卖"), ("assistant", "改好了：预占时按可售数量判断。")]

        fresh = json.loads(post(f"{url}/api/reset"))
        assert fresh["files"] == fresh["pristine"] and bench.history == []
    finally:
        httpd.shutdown()
        bench.close()


def test_rejects_empty_task_and_requests_from_other_sites():
    httpd, bench, url = start([])
    try:
        for body, headers, code in [({"task": "  "}, {}, 400),
                                    ({"task": "x"}, {"Origin": "https://evil.example"}, 403)]:
            try:
                post(f"{url}/api/run", body, headers)
                raise AssertionError("应该被拒绝")
            except urllib.error.HTTPError as e:
                assert e.code == code
    finally:
        httpd.shutdown()
        bench.close()


def test_allow_list_has_no_network_or_install_commands():
    assert not any(p.startswith(("curl", "pip", "rm", "wget", "bash", "sh ")) for p in ALLOW)
