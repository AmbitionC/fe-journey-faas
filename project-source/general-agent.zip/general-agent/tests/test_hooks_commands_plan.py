"""钩子、斜杠命令、计划模式、记忆的离线整理。"""
import asyncio
import json
import sys

from agent.build import build_coding_agent
from agent.cli import plan_then_run
from agent.extensions.commands import discover_commands, parse
from agent.kernel.permission import Rule
from agent.model import ScriptedModel
from agent.state.dream import consolidate
from agent.state.memory import MemoryStore
from agent.types import Message, ToolCall

ALLOW_ALL = [Rule("*", "*", "allow")]


def call(name, _id="c1", **args):
    return ToolCall(id=_id, name=name, arguments=args)


def say(text="", *calls):
    return Message("assistant", text, tool_calls=list(calls))


def tool_results(outcome):
    return [m.content for m in outcome.messages if m.role == "tool"]


def write_hooks(root, **hooks):
    (root / ".agent").mkdir(exist_ok=True)
    (root / ".agent" / "hooks.json").write_text(json.dumps(hooks))


# --- 钩子 -----------------------------------------------------------------
def test_pre_hook_exit_2_blocks_and_reason_reaches_model(tmp_path):
    guard = tmp_path / "guard.py"
    guard.write_text("import json,sys\nd=json.load(sys.stdin)\n"
                     "if d['arguments']['path'].startswith('migrations/'):\n"
                     "    print('migrations 目录只能由人改', file=sys.stderr); sys.exit(2)\n")
    write_hooks(tmp_path, pre_tool=[{"tool": "write_file", "command": f"{sys.executable} {guard}"}])
    model = ScriptedModel([say("", call("write_file", "a", path="migrations/001.sql", content="x")),
                           say("", call("write_file", "b", path="notes.txt", content="ok")), say("完成")])
    out = asyncio.run(build_coding_agent(model, tmp_path, rules=ALLOW_ALL, hooks=True).run("go"))
    first, second = tool_results(out)
    assert "被项目的钩子拦下" in first and "migrations 目录只能由人改" in first
    assert not (tmp_path / "migrations").exists() and (tmp_path / "notes.txt").read_text() == "ok"
    assert "拦下" not in second


def test_post_hook_output_is_appended_to_result(tmp_path):
    write_hooks(tmp_path, post_tool=[{"tool": "write_*", "command": "echo 检查发现：$HOOK_PATH 第 1 行太长"}])
    model = ScriptedModel([say("", call("write_file", path="a.py", content="x = 1\n")), say("好")])
    out = asyncio.run(build_coding_agent(model, tmp_path, rules=ALLOW_ALL, hooks=True).run("go"))
    assert "检查发现：a.py 第 1 行太长" in tool_results(out)[0] and "[钩子 echo 的输出]" in tool_results(out)[0]


def test_hooks_are_off_unless_asked_and_cannot_override_the_gate(tmp_path):
    write_hooks(tmp_path, post_tool=[{"tool": "*", "command": "echo 钩子跑了"}])
    model = ScriptedModel([say("", call("write_file", path="a.py", content="x")), say("好")])
    out = asyncio.run(build_coding_agent(model, tmp_path, rules=ALLOW_ALL).run("go"))
    assert "钩子跑了" not in tool_results(out)[0]              # 评测和线上试用不读 hooks.json
    model = ScriptedModel([say("", call("write_file", path="a.py", content="y")), say("好")])
    out = asyncio.run(build_coding_agent(model, tmp_path, headless=True, hooks=True).run("go"))
    assert "已视为拒绝" in tool_results(out)[0] and "钩子跑了" not in tool_results(out)[0]   # 闸门拒绝的，钩子不执行


def test_agent_needs_confirmation_to_touch_its_own_hooks_file(tmp_path):
    write_hooks(tmp_path)
    model = ScriptedModel([say("", call("write_file", path=".agent/hooks.json", content="{}")), say("好")])
    out = asyncio.run(build_coding_agent(model, tmp_path, headless=True).run("go"))
    assert "需要用户确认" in tool_results(out)[0]


# --- 斜杠命令 -------------------------------------------------------------
def test_slash_commands_parse_and_expand(tmp_path):
    d = tmp_path / ".agent" / "commands"; d.mkdir(parents=True)
    (d / "review.md").write_text("---\ndescription: 提交前自查\n---\n检查这些改动有没有漏掉测试：$ARGUMENTS")
    (d / "ship.md").write_text("跑全量测试，通过后总结改动。")
    cmds = discover_commands(d)
    assert cmds["review"].description == "提交前自查"
    assert cmds["review"].expand("只看 cart.py") == "检查这些改动有没有漏掉测试：只看 cart.py"
    assert cmds["ship"].expand("别动文档").endswith("总结改动。\n\n别动文档")
    assert parse("/review 只看 cart.py") == ("review", "只看 cart.py") and parse("/help") == ("help", "")
    assert parse("修好 /tmp/a.py") is None and parse("/usr/bin/python 是哪个版本") is None and parse("/") is None


# --- 计划模式 -------------------------------------------------------------
def test_plan_mode_blocks_writes_until_user_approves(tmp_path):
    (tmp_path / "a.py").write_text("x = 1\n")
    model = ScriptedModel([
        say("", call("read_file", "r", path="a.py"), call("write_file", "w", path="a.py", content="x = 2\n")),
        say("计划：把 a.py 里的 x 改成 2，然后跑测试。"),
        say("", call("write_file", "w2", path="a.py", content="x = 2\n")), say("改好了")])
    agent = build_coding_agent(model, tmp_path, rules=ALLOW_ALL)
    seen = []

    async def confirm(plan):
        seen.append((plan, (tmp_path / "a.py").read_text(), agent.gate.plan_mode))
        return "顺便加一行注释"

    asyncio.run(plan_then_run(agent, "把 x 改成 2", confirm))
    plan, content_at_confirm, mode_at_confirm = seen[0]
    assert plan.startswith("计划：") and content_at_confirm == "x = 1\n" and mode_at_confirm is False
    blocked = next(m.content for m in agent.messages if m.tool_call_id == "w")
    assert "现在是计划模式" in blocked and (tmp_path / "a.py").read_text() == "x = 2\n"
    assert "补充要求：顺便加一行注释" in agent.messages[-4].content


def test_plan_rejected_changes_nothing(tmp_path):
    (tmp_path / "a.py").write_text("x = 1\n")
    model = ScriptedModel([say("计划：改 a.py")])
    agent = build_coding_agent(model, tmp_path, rules=ALLOW_ALL)

    async def confirm(plan):
        return None

    asyncio.run(plan_then_run(agent, "改", confirm))
    assert len(model.seen) == 1 and (tmp_path / "a.py").read_text() == "x = 1\n" and agent.gate.plan_mode is False


# --- 记忆整理 -------------------------------------------------------------
def seeded(tmp_path):
    s = MemoryStore(tmp_path / "m.db", scope="/proj")
    s.save("preference", "测试命令", "跑测试用 pytest -x -q")
    s.save("lesson", "全量很慢", "这个仓库的全量用例要十分钟，改完先跑相关的那一个文件")
    s.save("fact", "上次修了购物车", "11 月把购物车的四舍五入修好了")
    s.save("preference", "注意", "提交信息用中文写")
    return s


def test_consolidate_merges_deletes_retitles_and_archives(tmp_path):
    s = seeded(tmp_path)
    plan = {"merge": [{"ids": [1, 2], "kind": "lesson", "title": "跑测试：先跑相关文件，再 pytest -x -q 全量",
                       "content": "全量要十分钟。改完先跑相关的那个文件，最后用 pytest -x -q 跑全量。"}],
            "delete": [{"id": 3, "reason": "记的是某次任务的结果"}],
            "retitle": [{"id": 4, "title": "提交信息用中文"}]}
    report = asyncio.run(consolidate(s, ScriptedModel([say("```json\n" + json.dumps(plan, ensure_ascii=False) + "\n```")])))
    assert "整理前 4 条，整理后 2 条" in report and "合并 #1、#2 → #1" in report and "删除 #3" in report
    index = s.index()
    assert "#1 [lesson] 跑测试：先跑相关文件" in index and "#4 [preference] 提交信息用中文" in index and "#3" not in index
    archived = s.db.execute("SELECT id, why FROM memory_archive ORDER BY id").fetchall()
    assert [a[0] for a in archived] == [1, 2, 3] and "合并进 #1" in archived[1][1]     # 原文都能找回


def test_consolidate_ignores_plans_that_reuse_or_invent_ids(tmp_path):
    s = seeded(tmp_path)
    plan = {"merge": [{"ids": [1, 99], "kind": "lesson", "title": "t", "content": "c"},
                      {"ids": [1], "kind": "lesson", "title": "t", "content": "c"}],
            "delete": [{"id": 2, "reason": "r"}, {"id": 2, "reason": "again"}, {"id": "3"}],
            "retitle": [{"id": 2, "title": "已经被删了"}]}
    report = asyncio.run(consolidate(s, ScriptedModel([say(json.dumps(plan))])))
    assert "整理后 3 条" in report and report.count("删除 #2") == 1 and "合并" not in report.splitlines()[1]
    assert asyncio.run(consolidate(s, ScriptedModel([say("我觉得都挺好")]))).startswith("看过了 3 条")


def test_index_is_capped_and_search_finds_the_rest(tmp_path):
    s = MemoryStore(tmp_path / "m.db", scope="/proj")
    topics = ["数据库连接池", "日志格式", "接口鉴权", "缓存失效", "部署脚本", "前端构建"]
    for i, t in enumerate(topics):
        s.db.execute("INSERT INTO memory (kind, title, content, scope, created_at, updated_at, hits) VALUES (?,?,?,?,?,?,?)",
                     ("fact", t, f"{t}的细节", "/proj", "2026-01-01", f"2026-01-0{i + 1}", 5 if t == "数据库连接池" else 0))
    s.db.commit()
    index = s.index(limit=3)
    assert "数据库连接池" in index and "前端构建" in index and "日志格式" not in index     # 常被取用的和最近的留下
    assert "另有 3 条没有列出" in index and index.index("#1 ") < index.index("#6 ")
    assert "日志格式" in s.search("日志的格式是什么") and s.search("火星") == "没有找到相关的记忆。"


# --- 中断 -----------------------------------------------------------------
def test_cancel_during_tool_leaves_no_call_without_result(tmp_path):
    """工具执行到一半被取消（Ctrl+C），已经记下的工具调用必须补上一条结果，
    否则下一次请求会带着没有结果的调用，接口会拒绝。"""
    slow = "import time; time.sleep(30)"
    model = ScriptedModel([say("", call("run_command", "c1", command=f'{sys.executable} -c "{slow}"')),
                           say("好的")])
    agent = build_coding_agent(model, tmp_path, rules=ALLOW_ALL)

    async def go():
        run = asyncio.create_task(agent.run("跑一下"))
        await asyncio.sleep(0.5)
        run.cancel()
        try:
            await run
        except asyncio.CancelledError:
            pass
        return await agent.run("接着做别的")

    outcome = asyncio.run(go())
    assert outcome.stopped == "finished"
    answered = {m.tool_call_id for m in outcome.messages if m.role == "tool"}
    asked = {c.id for m in outcome.messages if m.role == "assistant" for c in m.tool_calls}
    assert asked and asked <= answered
