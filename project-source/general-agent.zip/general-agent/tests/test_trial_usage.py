"""在线试用的用量与防刷：超时和断开也记实际用量、断开就停、票据到后端领一次、结束后上报。"""
import asyncio
import json
import sys
import socket
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent))
from test_trial import brain, start  # noqa: E402

from agent.model import OpenAICompatModel, parse_stream  # noqa: E402

meter = brain.meter


def sse(*chunks):
    return [b"data: " + json.dumps(c).encode() for c in chunks] + [b"data: [DONE]"]


class Backend(BaseHTTPRequestHandler):
    """网站后端的替身：记下收到的请求，按 answer 回。"""
    seen: list = []
    answer: dict = {"ok": True}
    status = 200

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        payload, mac = body["token"].rsplit(".", 1)
        Backend.seen.append((self.path, brain.unsign(body["token"], "s3cret")))
        data = json.dumps({"success": True, "data": Backend.answer}).encode()
        self.send_response(Backend.status)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *a):
        pass


@pytest.fixture
def service(monkeypatch):
    Backend.seen, Backend.answer, Backend.status = [], {"ok": True}, 200
    back, back_url = start(Backend)
    monkeypatch.setattr(brain, "TICKET_SECRET", "s3cret")
    br, url = start(brain.Handler)
    yield url, back_url
    br.shutdown(), back.shutdown()


def ticket(jti, cb, scenario="t"):
    return brain.sign({"jti": jti, "exp": time.time() + 60, "scenario": scenario, "cb": cb}, "s3cret")


def post(url, body):
    req = urllib.request.Request(url + "/run", data=json.dumps(body).encode())
    raw = urllib.request.urlopen(req, timeout=30).read().decode()
    return [json.loads(l[6:]) for l in raw.splitlines() if l.startswith("data: ")]


def wait_usage(n=1, timeout=15):
    end = time.time() + timeout
    while time.time() < end:
        got = [p for path, p in Backend.seen if path == "/project/trial/usage"]
        if len(got) >= n:
            return got
        time.sleep(0.05)
    raise AssertionError(f"没有收到用量上报：{Backend.seen}")


def scenario(monkeypatch, run):
    monkeypatch.setitem(brain.SCENARIOS, "t", {"title": "t", "default_task": "t", "run": run})


def fake_stream(monkeypatch, lines):
    """真模型客户端，只把网络那一层换掉。"""
    def sync(self, messages, tools, on_text, on_tool=None):
        return parse_stream(lines(), on_text, on_tool)
    monkeypatch.setattr(OpenAICompatModel, "_chat_sync", meter.metered_stream(sync))


def text(t):
    return {"choices": [{"delta": {"content": t}}]}


USAGE = {"usage": {"prompt_tokens": 100, "completion_tokens": 7}, "choices": []}


def test_usage_is_claimed_then_reported_with_real_tokens(service, monkeypatch):
    url, cb = service
    fake_stream(monkeypatch, lambda: sse(text("好"), USAGE))

    async def run(task, emit):
        for _ in range(2):
            await OpenAICompatModel().chat([], [])
        return {"stopped": "finished", "turns": 2, "input_tokens": 1, "output_tokens": 1}

    scenario(monkeypatch, run)
    events = post(url, {"ticket": ticket("u1", cb)})
    assert (events[-1]["input_tokens"], events[-1]["output_tokens"]) == (200, 14)      # 以计量为准
    assert [p for p, _ in Backend.seen] == ["/project/trial/claim", "/project/trial/usage"]
    u = wait_usage()[0]
    assert u["typ"] == "usage" and u["jti"] == "u1" and u["stopped"] == "finished"
    assert (u["input_tokens"], u["output_tokens"], u["calls"], u["estimated_calls"]) == (200, 14, 2, 0)
    assert u["seconds"] >= 0


def test_timeout_reports_what_was_really_spent(service, monkeypatch):
    """超时的运行也花了钱：已完成的调用记实数，被掐断的那次按字数估。"""
    url, cb = service

    def lines():
        yield from sse(text("第一段"))[:1]
        for _ in range(400):
            time.sleep(0.02)
            yield b"data: " + json.dumps(text("慢")).encode()

    first = [True]

    def sync(self, messages, tools, on_text, on_tool=None):
        if first[0]:
            first[0] = False
            return parse_stream(sse(text("好"), USAGE), on_text, on_tool)
        return parse_stream(lines(), on_text, on_tool)
    monkeypatch.setattr(OpenAICompatModel, "_chat_sync", meter.metered_stream(sync))

    async def run(task, emit):
        await OpenAICompatModel().chat([], [])
        try:
            await asyncio.wait_for(OpenAICompatModel().chat([], []), 0.3)
        except asyncio.TimeoutError:
            pass
        return {"stopped": "timeout", "turns": 0, "input_tokens": 0, "output_tokens": 0}

    scenario(monkeypatch, run)
    t0 = time.time()
    events = post(url, {"ticket": ticket("u2", cb)})
    assert time.time() - t0 < 5                        # 没有等那次八秒的生成写完
    u = wait_usage()[0]
    assert u["stopped"] == "timeout" and u["input_tokens"] >= 100 and u["output_tokens"] > 7
    assert u["calls"] == 2 and u["estimated_calls"] == 1 and events[-1]["input_tokens"] == u["input_tokens"]


def test_error_is_reported_too(service, monkeypatch):
    url, cb = service
    fake_stream(monkeypatch, lambda: sse(text("好"), USAGE))

    async def run(task, emit):
        await OpenAICompatModel().chat([], [])
        raise RuntimeError("boom")

    scenario(monkeypatch, run)
    assert post(url, {"ticket": ticket("u3", cb)})[-1]["type"] == "error"
    u = wait_usage()[0]
    assert u["stopped"] == "error" and u["input_tokens"] == 100


def test_closing_the_page_stops_the_run(service, monkeypatch):
    url, cb = service
    monkeypatch.setattr(brain, "KEEPALIVE_SECONDS", 0.1)
    fake_stream(monkeypatch, lambda: sse(text("好"), USAGE))
    steps = []

    async def run(task, emit):
        for i in range(100):
            await OpenAICompatModel().chat([], [])
            steps.append(i)
            await asyncio.sleep(0.1)
        return {"stopped": "finished", "turns": 100}

    scenario(monkeypatch, run)
    host, port = url[7:].split(":")
    s = socket.create_connection((host, int(port)))
    body = json.dumps({"ticket": ticket("u4", cb)}).encode()
    s.sendall(b"POST /run HTTP/1.1\r\nHost: x\r\nContent-Length: %d\r\n\r\n" % len(body) + body)
    s.recv(200)
    time.sleep(0.3)
    s.close()
    u = wait_usage()[0]
    assert u["stopped"] == "disconnected" and len(steps) < 40
    assert u["input_tokens"] == 100 * u["calls"]
    n = len(steps)
    time.sleep(0.5)
    assert len(steps) == n                             # 确实停了


@pytest.mark.parametrize("answer,status,code", [
    ({"ok": False, "reason": "used", "message": "用过了"}, 200, 401),
    ({"ok": False, "reason": "budget", "message": "今天的额度用完了"}, 200, 429),
    ({"ok": True}, 500, 503),                          # 后端不可用：不放行
])
def test_run_is_refused_unless_backend_lets_the_ticket_in(service, monkeypatch, answer, status, code):
    url, cb = service
    ran = []

    async def run(task, emit):
        ran.append(1)
        return {"stopped": "finished"}

    scenario(monkeypatch, run)
    Backend.answer, Backend.status = answer, status
    with pytest.raises(urllib.error.HTTPError) as e:
        post(url, {"ticket": ticket(f"c{code}", cb)})
    assert e.value.code == code and not ran
    assert not [p for p, _ in Backend.seen if p == "/project/trial/usage"]


def test_ticket_without_callback_still_runs(service, monkeypatch):
    """部署冒烟的票据没有回调地址：照常跑，不领取也不上报。"""
    url, _ = service

    async def run(task, emit):
        return {"stopped": "finished"}

    scenario(monkeypatch, run)
    t = brain.sign({"jti": "smoke", "exp": time.time() + 60, "scenario": "t"}, "s3cret")
    assert post(url, {"ticket": t})[-1]["type"] == "done" and Backend.seen == []


def test_a_signed_usage_report_is_not_a_ticket():
    t = brain.sign({"jti": "x", "exp": time.time() + 60, "typ": "usage"}, "s3cret")
    assert brain.verify(t, "s3cret") is None


def test_non_stream_client_is_metered_and_runs_do_not_mix():
    class Client:
        def _ask_sync(self, system, user):
            time.sleep(0.02)
            return "答", (len(user), 1)

    ask = meter.metered_ask(Client._ask_sync)

    def one(n, out):
        with meter.measure() as m:
            async def go():
                await asyncio.gather(*(asyncio.to_thread(ask, Client(), "", "x" * n) for _ in range(5)))
            asyncio.run(go())
        out.append((n, m.input_tokens, m.calls))

    out = []
    ts = [threading.Thread(target=one, args=(n, out)) for n in (3, 10)]
    [t.start() for t in ts], [t.join() for t in ts]
    assert sorted(out) == [(3, 15, 5), (10, 50, 5)]
