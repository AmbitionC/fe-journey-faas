# 从零手写通用 Agent

配套教程：Agent Journey「项目实战」里的同名项目。代码目录和教程章节一一对应，内核不依赖任何第三方库。

## 运行

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"

export OPENAI_BASE_URL=https://api.deepseek.com   # 任何 OpenAI 兼容接口
export OPENAI_API_KEY=你的密钥
export LLM_MODEL=deepseek-chat

# 在自带的示例仓库里试。fixtures/shop 最小，有两条测试是挂的；
# fixtures/store 是一个小型电商后端（金额、优惠、库存、订单），留了三处缺陷，网站上的在线试用用的就是它
cd fixtures/shop
python -m agent.cli                                   # 交互模式
python -m agent.cli -p "有测试挂了，帮我修好" --allow "python -m pytest*"   # 无界面模式
```

## 计划模式、斜杠命令、钩子、记忆整理

这四样都是在内核外面加的一层，内核的执行循环只多了两处调用钩子的代码。

```bash
> /plan 把订单金额的四舍五入改成银行家舍入     # 先只读地看代码、交出计划；你同意后才动手
> /review 只看 cart.py                        # 项目自己的命令：.agent/commands/review.md
> /dream                                      # 整理长期记忆：合并重复、清掉过时、改好标题
> /help
python -m agent.cli --dream                   # 不进交互模式，整理完就退出，适合放进定时任务
```

- **计划模式**靠权限闸门强制：计划阶段任何会改东西的工具都会被拦下，不是在提示词里写一句「先别动手」。
- **斜杠命令**一个命令一个文件，正文里的 `$ARGUMENTS` 换成命令后面跟的内容。模型不知道有哪些命令，所以不占上下文。
- **钩子**配在 `.agent/hooks.json`，在工具执行前后跑一条你自己的命令：`pre_tool` 以退出码 2 结束表示拦下这一步，
  `post_tool` 的输出会接在工具结果后面交给模型。只有终端里启动时才读这个文件，评测和线上试用不读。

  ```json
  {"pre_tool":  [{"tool": "write_file", "command": "python scripts/guard.py"}],
   "post_tool": [{"tool": "edit_file",  "command": "ruff check --quiet $HOOK_PATH"}]}
  ```
- **记忆整理**由模型出方案、代码执行：编号不存在或一条被处理两次的操作会被丢掉，被合并和删除的原文先进归档表。
  常驻上下文的记忆标题最多 30 条，其余用 `search_memory` 按关键词找。

## 本地网页工作台

不想在终端里看，可以开一个本地网页：左边是会话，中间是对话和每一步工具调用，右边是工作区的文件和改动对比。网站上的在线试用就是这个形态。

```bash
python -m agent.web                       # 用自带的 fixtures/store，浏览器打开 http://127.0.0.1:8765
python -m agent.web --repo ../my-project  # 换成你自己的项目
```

- Agent 不直接改你给的目录，而是先复制一份工作副本，在副本上干活。「新会话」会重新复制一份。
- 命令在你的电脑上执行，没有沙箱，所以这里只放行跑测试和只读的命令（见 `agent/web/server.py` 的 `ALLOW`）。别的命令会被权限闸门拦下，页面上能看到被拦下的那一步。
- 服务只监听 `127.0.0.1`，也只接受本机页面发来的请求。
- 页面是一个不需要构建的 HTML 文件（`agent/web/static/index.html`），事件格式和在线试用相同。想换成 React 之类的前端，只需要对接 `/api/state`、`/api/run`（SSE）、`/api/reset`、`/api/stop` 四个接口。

终端、本地网页、线上试用是三个外壳，装的是同一个内核：都从 `agent/build.py` 的 `build_coding_agent` 拿 Agent，区别只在事件怎么显示、权限怎么确认、命令在哪执行。

## 研究模式

```bash
export TAVILY_API_KEY=你的搜索服务密钥      # 搜索服务是可替换的接口，见 agent/tools/research/web.py
python -m agent.research.cli "对比 Milvus 和 pgvector 的索引类型和许可" --out runs/vector-db
```

## 评测

```bash
python -m agent.evals.runner evals/tasks --repeat 3 --out runs/eval.json
```

## 测试

```bash
pytest
```

测试用脚本化的假模型驱动，不联网，不花钱。

## 源码结构

一个内核，三个外壳。内核不认识具体工具，也不关心自己被装在终端、网页还是线上服务里。

| 分区 | 位置 | 规模 | 是什么 |
|---|---|---|---|
| **Agent 内核** | `agent/kernel/`、`agent/types.py`、`agent/model.py`、`agent/prompts.py`、`agent/build.py`、`agent/__init__.py` | 10 个文件，842 行代码 | 执行循环、权限闸门、上下文压缩、子任务调度。不依赖任何第三方库，是整个项目最值得逐行读的部分 |
| **工具** | `agent/tools/`、`agent/sandbox.py` | 9 个文件，582 行代码 | 工具注册表和六个编程工具（读、写、改、找、搜、跑命令），以及研究模式的搜索和抓取 |
| **状态** | `agent/state/` | 4 个文件，283 行代码 | 项目说明文件、长期记忆（SQLite）和它的离线整理、可回放的会话记录 |
| **能力扩展** | `agent/research/`、`agent/extensions/` | 9 个文件，642 行代码 | 研究模式（主管加研究员、来源库与引用）、MCP 客户端、技能的三级按需加载、钩子、斜杠命令 |
| **终端** | `agent/cli.py` | 1 个文件，175 行代码 | 交互模式和无界面模式。需要确认的操作在终端里问你，同类操作可以记住选择；计划模式和斜杠命令也在这里 |
| **本地网页工作台** | `agent/web/` | 4 个文件，519 行代码 | python -m agent.web：浏览器里下任务，看对话、每一步工具调用和文件改动对比。页面是一个不用构建的 HTML 文件 |
| **线上试用服务** | `trial/` | 2 个文件，474 行代码 | 网站在线试用背后的两个服务：入口服务跑内核，命令交给隔离的沙箱服务执行。可以照着部署自己的 |
| **评测** | `agent/evals/`、`evals/` | 3 个文件，170 行代码 | 把同一条任务重复跑多次的运行器，和一条任务样例 |
| **测试** | `tests/` | 10 个文件，1130 行代码 | 用脚本化的假模型驱动，不联网、不花钱；每个部件一份 |
| **示例仓库** | `fixtures/` | 17 个文件，309 行代码 | 给 Agent 练手的两个小项目。store 是一个留了三处缺陷的电商后端，在线试用和本地工作台用的都是它 |
| **用 AI 编程工具重做** | `build-with-ai/` | 4 个文件 | 想亲手做一遍时用的需求文档、按里程碑拆好的任务清单、项目说明文件模板和每一步的提示词 |

分区写在 `architecture.json` 里，`python ../scripts/source_map.py` 会检查每个文件都归了类。

## 文件和教程章节的对应

| 路径 | 对应章节 |
|---|---|
| `agent/kernel/loop.py` | 执行循环 |
| `agent/tools/` | 工具系统 |
| `agent/kernel/permission.py` | 权限与安全 |
| `agent/kernel/context.py` | 上下文管理 |
| `agent/state/memory.py`、`agent/state/dream.py` | 记忆（项目说明文件 `AGENT.md`、长期记忆、离线整理） |
| `agent/kernel/subagent.py` | 子任务调度 |
| `agent/research/`、`agent/tools/research/` | 研究模式 |
| `agent/extensions/` | MCP、技能、钩子、斜杠命令 |
| `agent/evals/runner.py`、`evals/tasks/` | 评测 |
| `agent/state/session.py` | 会话记录 |
| `agent/cli.py`、`agent/web/`、`trial/` | 三个外壳：终端、本地网页工作台、线上试用服务 |
