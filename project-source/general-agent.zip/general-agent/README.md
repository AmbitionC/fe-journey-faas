# 从零手写通用 Agent

配套教程：Agent Journey「项目实战」里的同名项目。代码目录和教程章节一一对应，内核不依赖任何第三方库。

## 运行

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"

export OPENAI_BASE_URL=https://api.deepseek.com   # 任何 OpenAI 兼容接口
export OPENAI_API_KEY=你的密钥
export LLM_MODEL=deepseek-chat

# 在自带的示例仓库里试。fixtures/shop 最小，有两条测试是挂的；
# fixtures/store 是一个小型电商后端（金额、优惠、库存、订单），留了三处缺陷，网站上的在线试用用的就是它
cd fixtures/shop
python -m agent.cli                                   # 交互模式
python -m agent.cli -p "有测试挂了，帮我修好" --allow "python -m pytest*"   # 无界面模式
```

## 研究模式

```bash
export TAVILY_API_KEY=你的搜索服务密钥      # 搜索服务是可替换的接口，见 agent/tools/research/web.py
python -m agent.research.cli "对比 Milvus 和 pgvector 的索引类型和许可" --out runs/vector-db
```

## 评测

```bash
python -m agent.evals.runner evals/tasks --repeat 3 --out runs/eval.json
```

## 测试

```bash
pytest
```

测试用脚本化的假模型驱动，不联网，不花钱。

## 目录

| 路径 | 对应章节 |
|---|---|
| `agent/kernel/loop.py` | 执行循环 |
| `agent/tools/` | 工具系统 |
| `agent/kernel/permission.py` | 权限与安全 |
| `agent/kernel/context.py` | 上下文管理 |
| `agent/state/memory.py` | 记忆（项目说明文件 `AGENT.md` 与长期记忆） |
| `agent/kernel/subagent.py` | 子任务调度 |
| `agent/research/`、`agent/tools/research/` | 研究模式 |
| `agent/extensions/` | MCP 与技能 |
| `agent/evals/runner.py`、`evals/tasks/` | 评测 |
| `agent/state/session.py` | 会话记录 |
