package cn.agentjourney.agent.model;

import cn.agentjourney.agent.Json;
import cn.agentjourney.agent.Message;
import cn.agentjourney.agent.ToolCall;
import cn.agentjourney.agent.Usage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * 把流式响应拼成一条完整消息。
 *
 * 工具调用的参数是一小段一小段到达的 JSON 片段，必须按调用序号拼完整再解析。
 * 写一个大文件时参数要生成十几秒：onToolDelta 把每一段原文交出去，界面可以边生成边显示。
 */
public final class StreamParser {
    private StreamParser() {}

    private static final class Slot {
        String id = "";
        String name = "";
        final StringBuilder args = new StringBuilder();
    }

    public static ModelClient.Reply parse(Iterable<String> lines, ModelClient.Listener listener) {
        StringBuilder text = new StringBuilder();
        StringBuilder reasoning = new StringBuilder();
        Map<Integer, Slot> calls = new TreeMap<>();
        Usage usage = Usage.ZERO;
        for (String raw : lines) {
            String line = raw.strip();
            if (!line.startsWith("data:")) continue;
            String payload = line.substring(5).strip();
            if (payload.equals("[DONE]")) break;
            Map<String, Object> chunk = Json.parseObject(payload);
            Map<String, Object> u = Json.obj(chunk.get("usage"));
            if (!u.isEmpty()) {
                usage = new Usage(Json.integer(u.get("prompt_tokens"), 0), Json.integer(u.get("completion_tokens"), 0));
            }
            for (Object choice : Json.list(chunk.get("choices"))) {
                Map<String, Object> delta = Json.obj(Json.obj(choice).get("delta"));
                reasoning.append(Json.str(delta.get("reasoning_content")));
                String content = Json.str(delta.get("content"));
                if (!content.isEmpty()) {
                    text.append(content);
                    listener.onText(content);
                }
                for (Object item : Json.list(delta.get("tool_calls"))) {
                    Map<String, Object> tc = Json.obj(item);
                    int index = Json.integer(tc.get("index"), 0);
                    Slot slot = calls.computeIfAbsent(index, k -> new Slot());
                    if (!Json.str(tc.get("id")).isEmpty()) slot.id = Json.str(tc.get("id"));
                    Map<String, Object> fn = Json.obj(tc.get("function"));
                    if (!Json.str(fn.get("name")).isEmpty()) slot.name = Json.str(fn.get("name"));
                    String part = Json.str(fn.get("arguments"));
                    slot.args.append(part);
                    if (!part.isEmpty() && !slot.name.isEmpty()) listener.onToolDelta(index, slot.name, part);
                }
            }
        }
        List<ToolCall> toolCalls = new ArrayList<>();
        for (Map.Entry<Integer, Slot> e : calls.entrySet()) {
            Slot slot = e.getValue();
            String id = slot.id.isEmpty() ? "call_" + e.getKey() : slot.id;
            toolCalls.add(new ToolCall(id, slot.name, Message.parseArguments(slot.args.toString())));
        }
        return new ModelClient.Reply(
                new Message("assistant", text.toString(), toolCalls, null, reasoning.toString()), usage);
    }
}
