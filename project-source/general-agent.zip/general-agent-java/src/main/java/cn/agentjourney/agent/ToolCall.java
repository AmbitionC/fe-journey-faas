package cn.agentjourney.agent;

import java.util.Map;

/** 模型要求执行的一次工具调用。参数不是合法 JSON 时，原文放在 "__raw__" 里，由注册表给出可读的报错。 */
public record ToolCall(String id, String name, Map<String, Object> arguments) {
    public static final String RAW = "__raw__";
}
