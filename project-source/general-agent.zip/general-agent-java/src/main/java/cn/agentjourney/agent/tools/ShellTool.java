package cn.agentjourney.agent.tools;

import cn.agentjourney.agent.Json;
import cn.agentjourney.agent.Tool;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

/** 执行命令：超时、输出截断、固定工作目录、不提供交互。 */
public final class ShellTool {
    private ShellTool() {}

    /** 命令在哪里执行。默认在本机；换成沙箱只需要换这一个对象，工具和内核都不用改。 */
    public interface Executor {
        Result run(Workspace ws, String command, int timeoutSeconds) throws Exception;
    }

    public record Result(String status, String output) {}

    public static Tool create(Workspace ws, int defaultTimeout, Executor executor) {
        Executor exec = executor != null ? executor : new LocalExecutor();
        return Tool.named("run_command")
                .description("""
                        在项目目录里执行一条 shell 命令，返回退出码和输出。

                        用来运行测试、查看 git 状态、安装依赖等。命令不能等待键盘输入，
                        需要确认的命令请加上免交互参数（如 -y）。读写文件请用专门的文件工具。""")
                .required("command", "string", "要执行的命令")
                .optional("timeout", "integer", "超时秒数")
                .run(args -> {
                    Result r = exec.run(ws, Json.str(args.get("command")), Json.integer(args.get("timeout"), defaultTimeout));
                    String text = r.output().strip();
                    return "[" + r.status() + "]\n" + (text.isEmpty() ? "（没有输出）" : ToolRegistry.truncate(text, 8000));
                });
    }

    /**
     * 在本机用 sh -c 执行，需要 macOS、Linux 或 WSL。
     *
     * 超时后要杀的不只是 sh，还有它起的所有进程。Java 没有“起一个新进程组”的接口，所以：
     * 系统里有 setsid（Linux、WSL）就用它起命令，命令自成一个进程组，超时时整组杀掉；
     * 没有（macOS）就退而求其次，杀掉当时还挂在这棵进程树上的子孙进程，已经脱离出去的后台进程杀不到。
     */
    public static final class LocalExecutor implements Executor {
        private static final boolean HAS_SETSID = Stream.of("/usr/bin/setsid", "/bin/setsid")
                .anyMatch(p -> Files.isExecutable(Path.of(p)));

        @Override
        public Result run(Workspace ws, String command, int timeoutSeconds) throws IOException, InterruptedException {
            List<String> argv = HAS_SETSID ? List.of("setsid", "sh", "-c", command) : List.of("sh", "-c", command);
            Process proc = new ProcessBuilder(argv)
                    .directory(ws.root.toFile())
                    .redirectErrorStream(true)
                    .redirectInput(ProcessBuilder.Redirect.from(new File("/dev/null")))   // 不给键盘，等输入的命令会立刻读到结尾
                    .start();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            // 输出单独用一个线程读：不读的话管道写满，命令会卡住；超时的时候也能拿到已经输出的部分
            Thread pump = Thread.ofVirtual().start(() -> {
                try (InputStream in = proc.getInputStream()) {
                    byte[] buf = new byte[4096];
                    for (int n; (n = in.read(buf)) >= 0; ) {
                        synchronized (out) { out.write(buf, 0, n); }
                    }
                } catch (IOException ignored) {
                    // 进程被杀掉时流会被关闭，已经读到的保留
                }
            });
            String status;
            try {
                if (proc.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                    pump.join(2000);
                    status = "退出码 " + proc.exitValue();
                } else {
                    kill(proc);
                    pump.join(500);
                    status = "超过 " + timeoutSeconds + " 秒未结束，已终止，下面是终止前的输出";
                }
            } catch (InterruptedException e) {     // 注册表那一层超时或用户中断：不能留下还在跑的子进程
                kill(proc);
                throw e;
            }
            synchronized (out) {
                return new Result(status, out.toString(StandardCharsets.UTF_8));
            }
        }

        private static void kill(Process proc) {
            if (HAS_SETSID) {
                try {      // 负的进程号表示整个进程组
                    new ProcessBuilder("kill", "-KILL", "--", "-" + proc.pid())
                            .redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start()
                            .waitFor(5, TimeUnit.SECONDS);
                } catch (IOException | InterruptedException e) {
                    // 杀不成就走下面的老办法
                }
            }
            proc.descendants().forEach(ProcessHandle::destroyForcibly);
            proc.destroyForcibly();
        }
    }
}
