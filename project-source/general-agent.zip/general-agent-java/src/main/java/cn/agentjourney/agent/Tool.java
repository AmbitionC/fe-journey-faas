package cn.agentjourney.agent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 一个工具：名字、写给模型看的用途说明、参数的 JSON Schema、执行函数。
 * readOnly 决定两件事：能不能并行执行，以及是否默认放行。
 */
public record Tool(String name, String description, Map<String, Object> parameters, Fn run, boolean readOnly) {

    @FunctionalInterface
    public interface Fn {
        /** 返回交给模型的文字。可以抛异常，注册表会把它变成一句报错交回模型。 */
        String run(Map<String, Object> args) throws Exception;
    }

    public Tool withRun(Fn newRun) {
        return new Tool(name, description, parameters, newRun, readOnly);
    }

    public static Builder named(String name) {
        return new Builder(name);
    }

    /** Java 没法像 Python 那样从函数签名推出参数表，这里用几行链式调用把它写出来。 */
    public static final class Builder {
        private final String name;
        private String description = "";
        private boolean readOnly;
        private final Map<String, Object> props = new LinkedHashMap<>();
        private final List<String> required = new ArrayList<>();

        private Builder(String name) { this.name = name; }

        public Builder description(String text) { this.description = text.strip(); return this; }

        public Builder readOnly() { this.readOnly = true; return this; }

        /** type 是 JSON Schema 的类型名：string、integer、number、boolean、array、object。 */
        public Builder required(String param, String type, String description) {
            required.add(param);
            return optional(param, type, description);
        }

        public Builder optional(String param, String type, String description) {
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("type", type);
            p.put("description", description);
            props.put(param, p);
            return this;
        }

        public Tool run(Fn fn) {
            Map<String, Object> schema = new LinkedHashMap<>();
            schema.put("type", "object");
            schema.put("properties", props);
            schema.put("required", required);
            return new Tool(name, description, schema, fn, readOnly);
        }
    }
}
