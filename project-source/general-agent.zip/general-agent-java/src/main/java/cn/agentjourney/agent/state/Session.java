package cn.agentjourney.agent.state;

import cn.agentjourney.agent.Json;
import cn.agentjourney.agent.Message;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 会话记录：每追加一条消息就写一行 JSON。崩溃恢复、调试回看、评测评分都用它。 */
public final class Session {
    private final Path path;     // null 表示不记录

    public Session(Path path) {
        this.path = path;
        if (path != null && path.getParent() != null) {
            try {
                Files.createDirectories(path.getParent());
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }
    }

    private synchronized void write(Map<String, Object> record) {
        if (path == null) return;
        record.put("ts", System.currentTimeMillis() / 1000.0);
        try {
            Files.writeString(path, Json.write(record) + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public void message(Message m) {
        Map<String, Object> record = new LinkedHashMap<>();
        record.put("type", "message");
        record.putAll(m.toApi());
        write(record);
    }

    /** 工具开始执行、被拒绝、循环结束等过程事件。执行前写一次，查卡死时才有据可依。 */
    public void note(String kind, Map<String, Object> data) {
        Map<String, Object> record = new LinkedHashMap<>();
        record.put("type", kind);
        record.putAll(data);
        write(record);
    }

    public static List<Message> loadMessages(Path path) throws IOException {
        List<Message> out = new ArrayList<>();
        for (String line : Files.readAllLines(path)) {
            if (line.isBlank()) continue;
            Map<String, Object> rec = Json.parseObject(line);
            if ("message".equals(rec.get("type"))) out.add(Message.fromApi(rec));
        }
        return out;
    }
}
