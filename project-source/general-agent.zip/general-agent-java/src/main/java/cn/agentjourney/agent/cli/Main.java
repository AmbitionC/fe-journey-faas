package cn.agentjourney.agent.cli;

import cn.agentjourney.agent.CodingAgent;
import cn.agentjourney.agent.Event;
import cn.agentjourney.agent.Json;
import cn.agentjourney.agent.ToolCall;
import cn.agentjourney.agent.kernel.Agent;
import cn.agentjourney.agent.kernel.Outcome;
import cn.agentjourney.agent.kernel.PermissionGate.Answer;
import cn.agentjourney.agent.kernel.PermissionGate.Decision;
import cn.agentjourney.agent.kernel.PermissionGate.Rule;
import cn.agentjourney.agent.model.OpenAICompatModel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * 终端入口。
 *
 * <pre>
 *   java -jar target/general-agent-0.1.0.jar                 交互模式
 *   java -jar target/general-agent-0.1.0.jar -p "修好测试"    无界面模式，执行一条任务后退出
 * </pre>
 *
 * 交互模式里 /plan &lt;任务&gt; 先出计划再动手，/help 看命令。
 */
public final class Main {
    private static final String DIM = "\033[2m", BOLD = "\033[1m", YELLOW = "\033[33m", RED = "\033[31m", RESET = "\033[0m";

    static final String PLAN_PROMPT = """
            先不要动手。用只读的工具把相关代码看清楚，然后给出一份计划：
            要改哪些文件、每处怎么改、改完怎么验证、有哪些拿不准需要我确认的地方。只输出计划。

            任务：%s""";

    private static final BufferedReader STDIN = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));

    private Main() {}

    /**
     * 计划模式：闸门先切到只读，模型交出计划；用户同意后放开闸门再执行。
     * confirm 收到计划文本，返回 null 表示放弃，返回字符串表示同意（可以带一句补充要求）。
     */
    public static Outcome planThenRun(Agent agent, String task, Function<String, String> confirm) {
        Outcome plan;
        agent.gate.planMode = true;
        try {
            plan = agent.run(PLAN_PROMPT.formatted(task));
        } finally {
            agent.gate.planMode = false;      // 无论计划阶段怎么结束，都不能把闸门留在只读状态
        }
        String note = confirm.apply(plan.text());
        if (note == null) return plan;
        return agent.run(("计划可以，按它执行。" + (note.isBlank() ? "" : "补充要求：" + note)).strip());
    }

    /** 项目规则：项目目录下的 .agent/rules.json，可以提交到仓库。 */
    public static List<Rule> loadRules(Path cwd) throws IOException {
        Path file = cwd.resolve(".agent").resolve("rules.json");
        List<Rule> rules = new ArrayList<>();
        if (!Files.isRegularFile(file)) return rules;
        for (Object item : Json.list(Json.parse(Files.readString(file)))) {
            Map<String, Object> r = Json.obj(item);
            String decision = Json.str(r.get("decision"));
            if (!decision.equals("allow") && !decision.equals("deny")) {
                // 写错的规则不能悄悄变成放行：跳过它，并且说出来
                System.err.println(YELLOW + file + " 里有一条规则的 decision 不是 allow 或 deny，已忽略：" + Json.write(r) + RESET);
                continue;
            }
            rules.add(new Rule(Json.str(r.get("tool")), Json.str(r.get("pattern")),
                    decision.equals("deny") ? Decision.DENY : Decision.ALLOW));
        }
        return rules;
    }

    static void render(Event event) {
        Map<String, Object> d = event.data();
        switch (event.kind()) {
            case "text_delta" -> {
                System.out.print(d.get("text"));
                System.out.flush();
            }
            case "tool_start" -> System.out.println("\n" + DIM + "▸ " + d.get("name") + " " + cut(Json.write(d.get("arguments")), 160) + RESET);
            case "tool_end" -> {
                String result = String.valueOf(d.get("result")).strip();
                String first = result.isEmpty() ? "" : result.lines().findFirst().orElse("");
                System.out.println((Boolean.TRUE.equals(d.get("denied")) ? RED : DIM) + "  " + cut(first, 160) + RESET);
            }
            default -> { }
        }
    }

    private static String cut(String s, int n) { return s.length() > n ? s.substring(0, n) : s; }

    private static String readLine(String prompt) {
        System.out.print(prompt);
        System.out.flush();
        try {
            return STDIN.readLine();
        } catch (IOException e) {
            return null;
        }
    }

    static Answer askInTerminal(ToolCall call, String reason) {
        System.out.println("\n" + YELLOW + BOLD + "需要确认" + RESET + " " + call.name());
        call.arguments().forEach((key, value) -> {
            String text = String.valueOf(value);
            System.out.println("  " + key + ": " + (text.length() < 600 ? text : text.substring(0, 600) + "……"));
        });
        if (!reason.isEmpty()) System.out.println("  " + DIM + reason + RESET);
        String choice = readLine("  [y] 同意这一次  [a] 本会话同类不再问  [n] 拒绝 > ");
        choice = choice == null ? "n" : choice.strip().toLowerCase();
        if (choice.equals("y")) return Answer.once();
        if (choice.equals("a")) return Answer.always();
        String note = readLine("  想对它说什么（可留空）> ");
        return Answer.deny(note == null ? "" : note.strip());
    }

    public static void main(String[] argv) throws IOException {
        String prompt = null;
        Path cwd = Path.of(".");
        int maxTurns = 40;
        List<Rule> allowed = new ArrayList<>();
        for (int i = 0; i < argv.length; i++) {
            String a = argv[i];
            boolean hasValue = i + 1 < argv.length;
            if ((a.equals("-p") || a.equals("--prompt")) && hasValue) prompt = argv[++i];
            else if ((a.equals("-C") || a.equals("--cwd")) && hasValue) cwd = Path.of(argv[++i]);
            else if (a.equals("--allow") && hasValue) allowed.add(Rule.allow("run_command", argv[++i]));
            else if (a.equals("--max-turns") && hasValue && argv[i + 1].matches("\\d{1,6}")) maxTurns = Integer.parseInt(argv[++i]);
            else {
                System.out.println("""
                        用法：java -jar general-agent-0.1.0.jar [选项]
                          -p, --prompt <任务>   无界面模式：执行这条任务后退出
                          -C, --cwd <目录>      项目目录，默认当前目录
                          --allow <通配>        放行匹配的命令，如 --allow 'mvn *'，可重复
                          --max-turns <N>       轮次上限，默认 40""");
                System.exit(a.equals("-h") || a.equals("--help") ? 0 : 2);
            }
        }
        cwd = cwd.toRealPath();
        Path sessionFile = cwd.resolve(".agent").resolve("sessions")
                .resolve(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".jsonl");
        boolean headless = prompt != null;
        List<Rule> rules = loadRules(cwd);
        rules.addAll(allowed);
        Agent agent = CodingAgent.in(cwd, new OpenAICompatModel()).rules(rules).headless(headless)
                .asker(headless ? null : Main::askInTerminal).sessionFile(sessionFile)
                .onEvent(Main::render).maxTurns(maxTurns).build();

        if (headless) {
            Outcome o = agent.run(prompt);
            System.out.println("\n" + DIM + "[" + o.stopped().label() + " · " + o.turns() + " 轮 · 输入 "
                    + o.usage().input() + " 输出 " + o.usage().output() + "]" + RESET);
            System.exit(o.stopped() == Outcome.Stopped.FINISHED ? 0 : 1);
        }

        System.out.println(BOLD + "通用 Agent（Java 版）· 编程模式" + RESET + "  项目目录 " + cwd
                + "\n输入任务开始，输入 exit 退出，/help 看命令。会话记录在 " + sessionFile);
        while (true) {
            String task = readLine("\n" + BOLD + ">" + RESET + " ");
            if (task == null || task.strip().equals("exit") || task.strip().equals("quit")) break;
            task = task.strip();
            if (task.isEmpty()) continue;
            if (task.equals("/help")) {
                System.out.println("  /plan <任务>   先出计划，你同意后再动手\n  /help          列出命令");
            } else if (task.startsWith("/plan ")) {
                planThenRun(agent, task.substring(6).strip(), plan -> {
                    String answer = readLine("\n" + YELLOW + "按这个计划执行？" + RESET + "[回车] 执行  [n] 放弃  或直接写补充要求 > ");
                    return answer == null || answer.strip().equalsIgnoreCase("n") ? null : answer.strip();
                });
            } else if (task.matches("/[^/.\\s]+(\\s.*)?")) {      // 像 /usr/bin、/tmp/a.py 这样的路径不算命令
                System.out.println(YELLOW + "没有 " + task.split("\\s")[0] + " 这个命令，/help 看有哪些。" + RESET);
            } else {
                agent.run(task);
            }
            System.out.println();
        }
        System.exit(0);
    }
}
