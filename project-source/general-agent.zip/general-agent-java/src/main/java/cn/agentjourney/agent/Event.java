package cn.agentjourney.agent;

import java.util.Map;

/** 执行过程中发给界面的事件。kind 取值：text_delta、tool_delta、tool_start、tool_end、done。 */
public record Event(String kind, Map<String, Object> data) {}
