package cn.agentjourney.agent.kernel;

import cn.agentjourney.agent.Tool;
import cn.agentjourney.agent.ToolCall;
import cn.agentjourney.agent.tools.Glob;
import cn.agentjourney.agent.tools.Workspace;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/** 权限闸门：拒绝规则优先于放行规则，规则优先于默认行为。 */
public final class PermissionGate {

    public enum Decision { ALLOW, DENY, ASK }

    /** tool 是工具名，"*" 表示任意工具；pattern 是对关键参数的通配匹配，如 "mvn *"。 */
    public record Rule(String tool, String pattern, Decision decision) {
        public static Rule allow(String tool, String pattern) { return new Rule(tool, pattern, Decision.ALLOW); }

        public static Rule deny(String tool, String pattern) { return new Rule(tool, pattern, Decision.DENY); }
    }

    public record Verdict(boolean allowed, String reason) {}

    /** 判定结果和原因。原因在拒绝时写给模型看，在需要确认时显示给用户。 */
    public record Decided(Decision decision, String reason) {}

    public enum Choice { ONCE, ALWAYS, DENY }

    /** 用户对一次确认的回答。note 是拒绝时补充的一句话。 */
    public record Answer(Choice choice, String note) {
        public static Answer once() { return new Answer(Choice.ONCE, ""); }

        public static Answer always() { return new Answer(Choice.ALWAYS, ""); }

        public static Answer deny(String note) { return new Answer(Choice.DENY, note == null ? "" : note); }
    }

    /** 怎么问用户：终端里是打印加读一行，网页里是弹一个确认框。 */
    @FunctionalInterface
    public interface Asker {
        Answer ask(ToolCall call, String reason);
    }

    private static final Map<String, String> KEY_ARG = Map.of(
            "run_command", "command", "read_file", "path", "write_file", "path", "edit_file", "path");
    private static final String NO_RETRY = "\n请不要重试同样的操作，换一种方式继续，或者向用户说明情况。";

    private final Workspace ws;
    private final List<Rule> projectRules;
    private final List<Rule> sessionRules = new CopyOnWriteArrayList<>();   // 本次会话里用户新同意的，退出即失效
    private final Asker asker;
    private final boolean headless;
    /** 计划模式：只许读，任何会改东西的工具都拦下。 */
    public volatile boolean planMode;

    public PermissionGate(Workspace ws, List<Rule> rules, Asker asker, boolean headless) {
        this.ws = ws;
        this.projectRules = rules == null ? List.of() : List.copyOf(rules);
        this.asker = asker;
        this.headless = headless;
    }

    // --- 规则匹配 -------------------------------------------------------
    private boolean match(String tool, String value, Decision decision) {
        for (List<Rule> rules : List.of(projectRules, sessionRules)) {
            for (Rule r : rules) {
                if (r.decision() == decision && (r.tool().equals(tool) || r.tool().equals("*"))
                        && Glob.matches(r.pattern(), value)) {
                    return true;
                }
            }
        }
        return false;
    }

    private Decision decideValue(String tool, String value) {
        if (match(tool, value, Decision.DENY)) return Decision.DENY;
        if (match(tool, value, Decision.ALLOW)) return Decision.ALLOW;
        return Decision.ASK;
    }

    private static String keyValue(ToolCall call) {
        Object v = call.arguments().get(KEY_ARG.getOrDefault(call.name(), ""));
        return v == null ? "" : String.valueOf(v);
    }

    public Decided decide(Tool tool, ToolCall call) {
        String value = keyValue(call);
        if (call.name().equals("run_command")) return decideCommand(value);
        if (KEY_ARG.containsKey(call.name())) {
            try {
                ws.resolve(value);
            } catch (Workspace.PathException e) {
                return new Decided(Decision.DENY, e.getMessage());
            }
            if (ws.isSensitive(value)) {
                Decision d = decideValue(call.name(), value);
                return d == Decision.ALLOW ? new Decided(d, "") : new Decided(d, "敏感文件");
            }
        }
        Decision d = decideValue(call.name(), value);
        if (d == Decision.DENY) return new Decided(d, "命中拒绝规则");
        if (d == Decision.ALLOW || tool.readOnly()) return new Decided(Decision.ALLOW, "");
        return new Decided(Decision.ASK, "");
    }

    public Decided decideCommand(String command) {
        List<String> segments = Commands.split(command);
        for (String seg : segments) {
            String why = Commands.builtinDeny(seg);
            if (why != null) return new Decided(Decision.DENY, "内置拒绝规则：" + why);
            if (match("run_command", seg, Decision.DENY)) return new Decided(Decision.DENY, "命中拒绝规则：" + seg);
            // 重定向等于写文件，和写文件工具守同一条边界
            for (String target : Commands.redirectTargets(seg)) {
                if (target.startsWith("~") || target.contains("$")) {
                    return new Decided(Decision.DENY, "重定向的目标在项目目录之外或无法静态判断：" + target);
                }
                try {
                    ws.resolve(target);
                } catch (Workspace.PathException e) {
                    return new Decided(Decision.DENY, "重定向的目标不允许：" + e.getMessage());
                }
                if (ws.isSensitive(target)) return new Decided(Decision.DENY, "重定向会改写敏感文件：" + target);
            }
        }
        if (Commands.SUBSTITUTION.matcher(command).find()) {
            return new Decided(Decision.ASK, "命令里有命令替换，无法静态判断会执行什么");
        }
        // 任何一段需要确认，则整条需要确认
        if (!segments.isEmpty() && segments.stream().allMatch(s -> match("run_command", s, Decision.ALLOW))) {
            return new Decided(Decision.ALLOW, "");
        }
        return new Decided(Decision.ASK, "");
    }

    // --- 对外入口 -------------------------------------------------------
    public Verdict check(Tool tool, ToolCall call) {
        if (planMode && !tool.readOnly()) {
            // 计划模式靠闸门强制，不靠提示词里的一句“请先不要动手”
            return new Verdict(false, "现在是计划模式，只能查看不能改动，" + call.name() + " 没有执行。"
                    + "请继续用只读的工具了解情况，然后直接用文字给出计划，等用户同意后再动手。");
        }
        Decided d = decide(tool, call);
        if (d.decision() == Decision.ALLOW) return new Verdict(true, "");
        String shown = describe(call);
        if (d.decision() == Decision.DENY) {
            return new Verdict(false, "这次操作被拒绝：" + shown + "\n原因：" + d.reason() + NO_RETRY);
        }
        if (headless || asker == null) {
            return new Verdict(false, "这次操作需要用户确认，但当前是无界面模式，已视为拒绝：" + shown
                    + "\n请换一种不需要确认的方式继续，或者说明无法完成的原因。");
        }
        Answer answer = asker.ask(call, d.reason());
        if (answer.choice() == Choice.DENY) {
            String note = answer.note().isEmpty() ? "" : "\n用户说明：" + answer.note();
            return new Verdict(false, "用户拒绝了这次操作：" + shown + note + NO_RETRY);
        }
        if (answer.choice() == Choice.ALWAYS) sessionRules.addAll(rulesFor(call));
        return new Verdict(true, "");
    }

    private static String describe(ToolCall call) {
        String value = keyValue(call);
        return value.isEmpty() ? call.name() : call.name() + "(\"" + value + "\")";
    }

    /** “以后同类不再问”：命令按每一段的命令名放行，文件按具体路径放行。 */
    private static List<Rule> rulesFor(ToolCall call) {
        List<Rule> rules = new ArrayList<>();
        if (call.name().equals("run_command")) {
            for (String seg : Commands.split(keyValue(call))) {
                String head = seg.split("\\s+")[0];
                rules.add(Rule.allow("run_command", head));
                rules.add(Rule.allow("run_command", head + " *"));
            }
            return rules;
        }
        // 有关键参数的工具只放行这一个具体的值。值是空的就得到一条什么都匹配不上的规则，而不是通配
        rules.add(Rule.allow(call.name(), KEY_ARG.containsKey(call.name()) ? keyValue(call) : "*"));
        return rules;
    }
}
