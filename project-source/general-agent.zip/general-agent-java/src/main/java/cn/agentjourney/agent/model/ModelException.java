package cn.agentjourney.agent.model;

/** 模型接口不可用。只有它会让执行循环重试或中断。 */
public class ModelException extends Exception {
    public final boolean retryable;

    public ModelException(String message) { this(message, true); }

    public ModelException(String message, boolean retryable) {
        super(message);
        this.retryable = retryable;
    }
}
