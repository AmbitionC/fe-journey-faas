package cn.agentjourney.agent.kernel;

import cn.agentjourney.agent.Message;
import cn.agentjourney.agent.ToolCall;
import cn.agentjourney.agent.Usage;
import cn.agentjourney.agent.model.ModelClient;
import cn.agentjourney.agent.model.ModelException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/** 上下文管理器：三道防线里的后两道。第一道（结果进上下文前截断）在工具注册表里。 */
public final class ContextManager {
    static final String PLACEHOLDER_HEAD = "[此处是 ";
    static final String SUMMARY_PROMPT = """
            下面是一段较早的对话记录，请把它压缩成一份交接摘要，供你自己继续工作时使用。必须保留：
            1. 用户最初的任务，以及中途追加的要求。
            2. 已经完成了什么，改了哪些文件。
            3. 试过但失败的做法，以及失败原因。
            4. 当前正在做的一步和接下来的打算。
            5. 用户表达过的偏好和明确的禁止事项，原话保留。
            只输出摘要本身，不要寒暄。""";

    private final int windowTokens;
    private final double threshold;       // 留出余量放模型的下一次回复
    private final int keepRecent;         // 最近若干条消息原样保留
    private final ModelClient summarizer;
    private int lastInputTokens;          // 模型接口返回的真实用量，最可靠
    public int cleared;
    public int compactions;

    public ContextManager(int windowTokens, ModelClient summarizer) {
        this(windowTokens, 0.8, 8, summarizer);
    }

    public ContextManager(int windowTokens, double threshold, int keepRecent, ModelClient summarizer) {
        this.windowTokens = windowTokens;
        this.threshold = threshold;
        this.keepRecent = keepRecent;
        this.summarizer = summarizer;
    }

    /** 粗略估算：只用来决定要不要提前压缩，不能用来计费。 */
    public static int estimateTokens(List<Message> messages) {
        long chars = 0;
        for (Message m : messages) {
            chars += m.content.length();
            for (ToolCall c : m.toolCalls) chars += c.arguments().toString().length() + c.name().length();
        }
        return (int) (chars / 2);    // 中英混合文本，按两个字符一个 token 偏保守地估
    }

    /** 从 target 往前找第一个可以安全切开的位置：不能拆散一对工具调用和它的结果。 */
    public static int safeSplitPoint(List<Message> messages, int target) {
        for (int i = Math.min(target, messages.size() - 1); i > 0; i--) {
            if (!messages.get(i).role.equals("tool") && messages.get(i - 1).toolCalls.isEmpty()) return i;
        }
        return 0;
    }

    public void observe(Usage usage) { lastInputTokens = usage.input(); }

    private boolean over(List<Message> messages) {
        // 上一次的真实用量覆盖不到之后新增的消息，所以两个数取大的
        return Math.max(lastInputTokens, estimateTokens(messages)) > windowTokens * threshold;
    }

    /** 调模型之前调用。超过阈值时就地改写 messages：先清理旧的工具结果，还不够再压缩成摘要。 */
    public void prepare(List<Message> messages) throws ModelException {
        if (!over(messages)) return;
        clearOldToolResults(messages);
        lastInputTokens = 0;      // 清理之后旧的真实用量已不适用，回到估算
        if (over(messages) && summarizer != null) compact(messages);
    }

    // --- 第二道：清理旧的工具结果正文，保留调用记录 ----------------------
    private void clearOldToolResults(List<Message> messages) {
        Map<String, String> names = new HashMap<>();
        for (Message m : messages) {
            for (ToolCall c : m.toolCalls) names.put(c.id(), c.name() + "(" + brief(c.arguments()) + ")");
        }
        for (Message m : messages.subList(0, Math.max(0, messages.size() - keepRecent))) {
            if (m.role.equals("tool") && m.content.length() > 200 && !m.content.startsWith(PLACEHOLDER_HEAD)) {
                m.content = PLACEHOLDER_HEAD + names.getOrDefault(m.toolCallId, "一次工具调用")
                        + " 的结果，已清理以节省空间。需要时请重新获取。]";
                cleared++;
            }
        }
    }

    // --- 第三道：把早期对话压缩成摘要 -----------------------------------
    private void compact(List<Message> messages) throws ModelException {
        int split = safeSplitPoint(messages, messages.size() - keepRecent);
        if (split <= 1) return;
        String transcript = messages.subList(1, split).stream().map(ContextManager::render).collect(Collectors.joining("\n"));
        ModelClient.Reply reply = summarizer.chat(
                List.of(Message.system(SUMMARY_PROMPT), Message.user(transcript)), List.of(), ModelClient.Listener.NONE);
        List<Message> rebuilt = new ArrayList<>();
        rebuilt.add(messages.get(0));
        rebuilt.add(Message.user("[以下是更早对话的摘要，原文已省略]\n" + reply.message().content));
        rebuilt.addAll(messages.subList(split, messages.size()));
        messages.clear();
        messages.addAll(rebuilt);
        compactions++;
    }

    private static String brief(Map<String, Object> arguments) {
        return arguments.entrySet().stream().limit(2).map(e -> {
            String v = String.valueOf(e.getValue());
            return e.getKey() + "=\"" + (v.length() > 60 ? v.substring(0, 60) : v) + "\"";
        }).collect(Collectors.joining(", "));
    }

    private static String render(Message m) {
        if (!m.toolCalls.isEmpty()) {
            String calls = m.toolCalls.stream().map(c -> c.name() + "(" + brief(c.arguments()) + ")")
                    .collect(Collectors.joining("; "));
            return "[助手] " + m.content + " 调用工具：" + calls;
        }
        String label = switch (m.role) {
            case "user" -> "用户";
            case "assistant" -> "助手";
            case "tool" -> "工具结果";
            default -> "系统";
        };
        return "[" + label + "] " + (m.content.length() > 2000 ? m.content.substring(0, 2000) : m.content);
    }
}
