package cn.agentjourney.agent.tools;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

/** 工作目录：所有文件工具共用的路径边界和“已读”状态。 */
public final class Workspace {
    static final Set<String> IGNORED_DIRS = Set.of(".git", "node_modules", "__pycache__", ".venv", "venv", "dist",
            "build", "target", "out", ".pytest_cache", ".agent");
    static final List<String> SENSITIVE_NAMES = List.of(".env", "id_rsa", "id_ed25519", ".pem", "credentials");

    /** 路径越界。它的消息是写给模型看的。 */
    public static class PathException extends Exception {
        public PathException(String message) { super(message); }
    }

    public final Path root;
    private final Map<Path, FileTime> read = new ConcurrentHashMap<>();   // 路径 -> 读取时的修改时间

    public Workspace(Path root) {
        try {
            this.root = root.toRealPath();
        } catch (IOException e) {
            throw new UncheckedIOException("项目目录不存在：" + root, e);
        }
    }

    /** 解析成绝对路径并展开符号链接，结果必须在项目目录之内。 */
    public Path resolve(String path) throws PathException {
        Path full;
        try {
            full = real(root, Path.of(path));
        } catch (InvalidPathException | IOException e) {
            throw new PathException("路径 " + path + " 不是合法的路径，或者符号链接绕成了环。");
        }
        if (!full.startsWith(root)) {
            throw new PathException("路径 " + path + " 在项目目录 " + root + " 之外，不允许访问。");
        }
        return full;
    }

    /**
     * 像操作系统那样一段一段地走：遇到符号链接就换成它指向的位置，遇到 .. 就退到“当前真实位置”的上一级。
     * 不能先把 .. 消掉再展开链接：link/../x 里的 .. 是相对链接指向的目录说的，不是相对 link 所在的目录。
     * 也不能用 toRealPath：要新建的文件还不存在，指向不存在目标的链接也得照样展开，否则一写就写到了外面。
     */
    private static Path real(Path base, Path path) throws IOException {
        Path cur = path.isAbsolute() ? path.getRoot() : base;
        Deque<Path> pending = new ArrayDeque<>();
        path.forEach(pending::addLast);
        int links = 0;
        while (!pending.isEmpty()) {
            String name = pending.pollFirst().toString();
            if (name.isEmpty() || name.equals(".")) continue;
            if (name.equals("..")) {
                if (cur.getParent() != null) cur = cur.getParent();
                continue;
            }
            Path next = cur.resolve(name);
            if (!Files.isSymbolicLink(next)) {
                cur = next;
                continue;
            }
            if (++links > 40) throw new IOException("符号链接层数太多");
            Path target = Files.readSymbolicLink(next);
            if (target.isAbsolute()) cur = target.getRoot();
            List<Path> parts = new ArrayList<>();
            target.forEach(parts::add);
            for (int k = parts.size() - 1; k >= 0; k--) pending.addFirst(parts.get(k));
        }
        return cur;
    }

    public String rel(Path full) {
        return full.equals(root) ? "." : root.relativize(full).toString();
    }

    public boolean isSensitive(String path) {
        Path p = Path.of(path);
        String name = p.getFileName() == null ? "" : p.getFileName().toString().toLowerCase();
        // Agent 自己的规则配置：改了它等于改了自己的权限，要用户点头
        for (Path part : p) {
            if (part.toString().equals(".agent") && name.equals("rules.json")) return true;
        }
        for (String s : SENSITIVE_NAMES) {
            if (name.equals(s) || name.endsWith(s) || name.startsWith(s + ".")) return true;
        }
        return false;
    }

    public void markRead(Path full) {
        try {
            read.put(full, Files.getLastModifiedTime(full));
        } catch (IOException e) {
            read.remove(full);
        }
    }

    /** 改文件之前必须读过，且读过之后文件没有被别处改动。返回 null 表示可以改。 */
    public String checkFresh(Path full) {
        FileTime seen = read.get(full);
        if (seen == null) return "修改 " + rel(full) + " 之前必须先用 read_file 读取它。";
        try {
            if (!Files.getLastModifiedTime(full).equals(seen)) {
                return rel(full) + " 在你读取之后被修改过，请重新读取再改。";
            }
        } catch (IOException e) {
            return rel(full) + " 现在读不到了，请重新确认它是否存在。";
        }
        return null;
    }

    /** 文件不存在时给模型的提示：名字最像的几个文件。 */
    public List<String> similar(String path, int n) {
        Path asked = Path.of(path).getFileName();
        String target = asked == null ? path : asked.toString();
        record Scored(String rel, double score) {}
        List<Scored> scored = new ArrayList<>();
        for (Path p : walk()) {
            double s = similarity(target, p.getFileName().toString());
            if (s >= 0.5) scored.add(new Scored(rel(p), s));
        }
        scored.sort(Comparator.comparingDouble(Scored::score).reversed());
        return scored.stream().limit(n).map(Scored::rel).toList();
    }

    /** 1 减去编辑距离占较长名字的比例。 */
    static double similarity(String a, String b) {
        int[] prev = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            int[] cur = new int[b.length() + 1];
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            prev = cur;
        }
        int longest = Math.max(a.length(), b.length());
        return longest == 0 ? 1 : 1 - (double) prev[b.length()] / longest;
    }

    /** 项目里的全部文件，按路径排序。跳过依赖目录、构建产物和指向目录的符号链接。 */
    public List<Path> walk() {
        List<Path> out = new ArrayList<>();
        walk(root, out);
        return out;
    }

    private void walk(Path dir, List<Path> out) {
        List<Path> entries;
        try (Stream<Path> s = Files.list(dir)) {
            entries = s.sorted().toList();
        } catch (IOException | UncheckedIOException e) {
            return;
        }
        for (Path e : entries) {
            if (Files.isDirectory(e, LinkOption.NOFOLLOW_LINKS)) {
                if (!IGNORED_DIRS.contains(e.getFileName().toString())) walk(e, out);
            } else if (Files.isRegularFile(e)) {
                out.add(e);
            }
        }
    }
}
