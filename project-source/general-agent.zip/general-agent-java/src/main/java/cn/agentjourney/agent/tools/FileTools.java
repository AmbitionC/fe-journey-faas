package cn.agentjourney.agent.tools;

import cn.agentjourney.agent.Json;
import cn.agentjourney.agent.Tool;

import java.io.IOException;
import java.nio.charset.CharacterCodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/** 读、写、改、按名查找、按内容搜索。 */
public final class FileTools {
    private FileTools() {}

    public static List<Tool> all(Workspace ws) {
        return List.of(readFile(ws), writeFile(ws), editFile(ws), findFiles(ws), searchText(ws));
    }

    static Tool readFile(Workspace ws) {
        return Tool.named("read_file").readOnly()
                .description("""
                        读取文本文件的内容，返回带行号的文本。

                        文件较大时用 offset 和 limit 分段读取。修改文件之前必须先读取它。""")
                .required("path", "string", "相对于工作目录的文件路径")
                .optional("offset", "integer", "从第几行开始，0 表示开头")
                .optional("limit", "integer", "最多读取多少行")
                .run(args -> {
                    String path = Json.str(args.get("path"));
                    int offset = Math.max(0, Json.integer(args.get("offset"), 0));
                    int limit = Json.integer(args.get("limit"), 2000);
                    Path full;
                    try {
                        full = ws.resolve(path);
                    } catch (Workspace.PathException e) {
                        return e.getMessage();
                    }
                    if (!Files.isRegularFile(full)) {
                        List<String> hint = ws.similar(path, 3);
                        return "文件 " + path + " 不存在。"
                                + (hint.isEmpty() ? "可以用 find_files 查找。" : "名称相近的文件有：" + String.join("、", hint));
                    }
                    List<String> lines;
                    try {
                        lines = Files.readString(full).lines().toList();
                    } catch (CharacterCodingException e) {
                        return path + " 不是 UTF-8 文本文件，无法读取。";
                    }
                    ws.markRead(full);
                    offset = Math.min(offset, lines.size());
                    int end = (int) Math.min(lines.size(), (long) offset + Math.max(0, limit));
                    StringBuilder body = new StringBuilder();
                    for (int i = offset; i < end; i++) {
                        if (i > offset) body.append('\n');
                        body.append(String.format("%5d\t%s", i + 1, lines.get(i)));
                    }
                    if (end < lines.size()) {
                        body.append("\n（还有 ").append(lines.size() - end).append(" 行，用 offset=").append(end).append(" 继续读取）");
                    }
                    return body.isEmpty() ? "（空文件）" : body.toString();
                });
    }

    static Tool writeFile(Workspace ws) {
        return Tool.named("write_file")
                .description("""
                        创建一个新文件，或整体覆盖一个已有文件。

                        覆盖已有文件之前必须先读取它。只改其中一小段时请用 edit_file。""")
                .required("path", "string", "相对于工作目录的文件路径")
                .required("content", "string", "文件的完整内容")
                .run(args -> {
                    String content = Json.str(args.get("content"));
                    Path full;
                    try {
                        full = ws.resolve(Json.str(args.get("path")));
                    } catch (Workspace.PathException e) {
                        return e.getMessage();
                    }
                    if (Files.exists(full)) {
                        String problem = ws.checkFresh(full);
                        if (problem != null) return problem;
                    }
                    Files.createDirectories(full.getParent());
                    Files.writeString(full, content);
                    ws.markRead(full);
                    return "已写入 " + ws.rel(full) + "（" + content.lines().count() + " 行）。";
                });
    }

    static Tool editFile(Workspace ws) {
        return Tool.named("edit_file")
                .description("""
                        把文件里的一段文字替换成另一段。

                        old_text 必须和文件内容逐字一致（含缩进），并且在文件里只出现一次。
                        出现多次时请多带几行上下文让它唯一。""")
                .required("path", "string", "相对于工作目录的文件路径")
                .required("old_text", "string", "要被替换的原文")
                .required("new_text", "string", "替换成的新内容")
                .run(args -> {
                    String path = Json.str(args.get("path"));
                    String oldText = Json.str(args.get("old_text")), newText = Json.str(args.get("new_text"));
                    Path full;
                    try {
                        full = ws.resolve(path);
                    } catch (Workspace.PathException e) {
                        return e.getMessage();
                    }
                    if (!Files.isRegularFile(full)) return "文件 " + path + " 不存在。新建文件请用 write_file。";
                    String problem = ws.checkFresh(full);
                    if (problem != null) return problem;
                    if (oldText.isEmpty()) return "old_text 不能为空。新建或整体重写请用 write_file。";
                    String text = Files.readString(full);
                    int count = 0;
                    for (int at = text.indexOf(oldText); at >= 0; at = text.indexOf(oldText, at + oldText.length())) count++;
                    if (count == 0) return "在 " + path + " 里没有找到 old_text。请重新读取文件，确认原文逐字一致（注意缩进和空格）。";
                    if (count > 1) return "old_text 在 " + path + " 里出现了 " + count + " 次。请多带几行上下文，让它只匹配一处。";
                    int at = text.indexOf(oldText);
                    Files.writeString(full, text.substring(0, at) + newText + text.substring(at + oldText.length()));
                    ws.markRead(full);
                    return "已修改 " + ws.rel(full) + "。";
                });
    }

    static Tool findFiles(Workspace ws) {
        return Tool.named("find_files").readOnly()
                .description("按通配符查找文件，返回相对路径列表。默认忽略依赖目录和构建产物。")
                .required("pattern", "string", "通配符，如 *.java 或 src/test/*Test.java")
                .run(args -> {
                    String pattern = Json.str(args.get("pattern"));
                    List<String> hits = new ArrayList<>();
                    for (Path p : ws.walk()) {
                        if (Glob.matches(pattern, ws.rel(p)) || Glob.matches(pattern, p.getFileName().toString())) {
                            hits.add(ws.rel(p));
                        }
                    }
                    if (hits.isEmpty()) return "没有文件匹配 " + pattern + "。";
                    String shown = String.join("\n", hits.stream().sorted().limit(200).toList());
                    return hits.size() > 200 ? shown + "\n（共 " + hits.size() + " 个，只显示前 200 个，请缩小范围）" : shown;
                });
    }

    static Tool searchText(Workspace ws) {
        return Tool.named("search_text").readOnly()
                .description("""
                        在文件内容里搜索正则表达式，返回匹配行及其文件路径和行号。

                        不知道某段代码在哪个文件时使用。已经知道文件路径时，直接用 read_file。""")
                .required("pattern", "string", "正则表达式")
                .optional("glob", "string", "只在文件名匹配该通配符的文件里搜索，如 *.java")
                .run(args -> {
                    String glob = args.containsKey("glob") ? Json.str(args.get("glob")) : "*";
                    Pattern rx;
                    try {
                        rx = Pattern.compile(Json.str(args.get("pattern")));
                    } catch (PatternSyntaxException e) {
                        return "正则表达式有误：" + e.getDescription();
                    }
                    List<String> out = new ArrayList<>();
                    for (Path p : ws.walk()) {
                        if (!Glob.matches(glob, p.getFileName().toString())) continue;
                        List<String> lines;
                        try {
                            lines = Files.readString(p).lines().toList();
                        } catch (IOException e) {      // 二进制文件、读不了的文件直接跳过
                            continue;
                        }
                        for (int n = 0; n < lines.size(); n++) {
                            if (!rx.matcher(lines.get(n)).find()) continue;
                            String line = lines.get(n).strip();
                            out.add(ws.rel(p) + ":" + (n + 1) + ": " + (line.length() > 200 ? line.substring(0, 200) : line));
                            if (out.size() >= 100) return String.join("\n", out) + "\n（结果超过 100 条，已截断，请缩小范围）";
                        }
                    }
                    return out.isEmpty() ? "没有内容匹配 " + Json.str(args.get("pattern")) + "。" : String.join("\n", out);
                });
    }
}
