package cn.agentjourney.agent.tools;

import cn.agentjourney.agent.Json;
import cn.agentjourney.agent.Tool;
import cn.agentjourney.agent.ToolCall;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/** 工具注册表：查找、校验参数、带超时执行、截断结果。永远只返回字符串，不向上抛异常。 */
public final class ToolRegistry {
    public static final int MAX_RESULT_CHARS = 12_000;

    private final Map<String, Tool> tools = new LinkedHashMap<>();
    public final int timeoutSeconds;
    // 每次执行开一个虚拟线程，这样才能给它设超时：到时间就不等了，并且中断它。
    // 空闲时不占任何线程，所以整个进程共用一个、不需要关闭
    private static final ExecutorService RUNNER = Executors.newVirtualThreadPerTaskExecutor();

    public ToolRegistry() { this(150); }

    public ToolRegistry(int timeoutSeconds) { this.timeoutSeconds = timeoutSeconds; }

    public void register(Tool t) { tools.put(t.name(), t); }

    public Tool get(String name) { return tools.get(name); }

    public List<String> names() { return tools.keySet().stream().sorted().toList(); }

    /** 发给模型的工具清单。 */
    public List<Map<String, Object>> schemas() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Tool t : tools.values()) {
            Map<String, Object> fn = new LinkedHashMap<>();
            fn.put("name", t.name());
            fn.put("description", t.description());
            fn.put("parameters", t.parameters());
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("type", "function");
            item.put("function", fn);
            out.add(item);
        }
        return out;
    }

    /** 返回 null 表示参数合格，否则返回写给模型看的错误说明。 */
    public String validate(ToolCall call) {
        Tool t = tools.get(call.name());
        if (t == null) return "没有名为 " + call.name() + " 的工具。可用的工具有：" + String.join(", ", names());
        Map<String, Object> args = call.arguments();
        if (args.containsKey(ToolCall.RAW)) {
            String raw = String.valueOf(args.get(ToolCall.RAW));
            return "工具 " + call.name() + " 的参数不是合法的 JSON：" + (raw.length() > 200 ? raw.substring(0, 200) : raw);
        }
        Map<String, Object> props = Json.obj(t.parameters().get("properties"));
        for (Object req : Json.list(t.parameters().get("required"))) {
            if (!args.containsKey((String) req)) {
                return "工具 " + call.name() + " 缺少必填参数 " + req + "（" + Json.str(Json.obj(props.get(req)).get("description")) + "）";
            }
        }
        for (Map.Entry<String, Object> e : args.entrySet()) {
            if (!props.containsKey(e.getKey())) {
                return "工具 " + call.name() + " 没有参数 " + e.getKey() + "。可用的参数有：" + String.join(", ", props.keySet());
            }
            String expected = Json.str(Json.obj(props.get(e.getKey())).get("type"));
            if (!typeMatches(expected, e.getValue())) {
                return "工具 " + call.name() + " 的参数 " + e.getKey() + " 应为 " + expected + "，收到的是 " + typeName(e.getValue());
            }
        }
        return null;
    }

    private static boolean typeMatches(String expected, Object v) {
        return switch (expected) {
            case "string" -> v instanceof String;
            case "integer" -> v instanceof Long || v instanceof Integer;
            case "number" -> v instanceof Number;
            case "boolean" -> v instanceof Boolean;
            case "array" -> v instanceof List;
            case "object" -> v instanceof Map;
            default -> true;
        };
    }

    private static String typeName(Object v) {
        if (v == null) return "null";
        if (v instanceof String) return "string";
        if (v instanceof Long || v instanceof Integer) return "integer";
        if (v instanceof Number) return "number";
        if (v instanceof Boolean) return "boolean";
        if (v instanceof List) return "array";
        return "object";
    }

    public String execute(ToolCall call) {
        String problem = validate(call);
        if (problem != null) return problem;
        Tool t = tools.get(call.name());
        Future<String> future = RUNNER.submit(() -> t.run().run(call.arguments()));
        try {
            return truncate(String.valueOf(future.get(timeoutSeconds, TimeUnit.SECONDS)), MAX_RESULT_CHARS);
        } catch (TimeoutException e) {
            future.cancel(true);
            return "工具 " + call.name() + " 执行超过 " + timeoutSeconds + " 秒，已中止。";
        } catch (ExecutionException e) {      // 工具出错不是程序出错，变成文字交回模型
            Throwable cause = e.getCause();
            return "工具 " + call.name() + " 执行出错：" + cause.getClass().getSimpleName() + ": " + cause.getMessage();
        } catch (InterruptedException e) {
            future.cancel(true);
            Thread.currentThread().interrupt();
            return "工具 " + call.name() + " 的执行被中断。";
        }
    }

    /** 保留开头和结尾，中间说明省略了多少。报错信息通常在结尾。 */
    public static String truncate(String text, int limit) {
        if (text.length() <= limit) return text;
        int head = limit * 2 / 3, tail = limit / 3;
        int omitted = text.length() - head - tail;
        return text.substring(0, head) + "\n……（中间省略 " + omitted + " 个字符，可缩小范围后重新获取）……\n"
                + text.substring(text.length() - tail);
    }
}
