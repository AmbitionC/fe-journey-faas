package cn.agentjourney.agent;

public record Usage(int input, int output) {
    public static final Usage ZERO = new Usage(0, 0);

    public Usage plus(Usage other) {
        return new Usage(input + other.input, output + other.output);
    }
}
