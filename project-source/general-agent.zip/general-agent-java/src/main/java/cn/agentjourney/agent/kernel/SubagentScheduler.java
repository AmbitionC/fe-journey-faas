package cn.agentjourney.agent.kernel;

import cn.agentjourney.agent.Json;
import cn.agentjourney.agent.Tool;
import cn.agentjourney.agent.tools.ToolRegistry;

import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

/** 子任务调度器：一个全新的执行循环，结束后只把最后一段文字交回主任务。 */
public final class SubagentScheduler {
    public static final String SUBAGENT_PROMPT = """
            你是被派来完成一项独立子任务的助手。你看不到派发者之前的任何对话，任务说明就是你知道的全部。

            要求：
            - 只做任务说明里要求的事。你只有只读工具，不能修改任何文件。
            - 最后一条回复就是交回去的全部内容：先给结论，再给依据。
            - 引用代码时带文件路径和行号。
            - 没找到就明确说没找到，并说明找过哪些地方。不要编造看似合理的答案。
            """;

    /** 造一个子任务用的 Agent：给它哪些工具、什么提示词、它在第几层。 */
    @FunctionalInterface
    public interface AgentFactory {
        Agent make(ToolRegistry registry, String prompt, int depth);
    }

    private final AgentFactory makeAgent;
    private final ToolRegistry parentRegistry;
    private final int maxDepth;
    private final Semaphore slots;
    public final AtomicInteger spawned = new AtomicInteger();

    public SubagentScheduler(AgentFactory makeAgent, ToolRegistry parentRegistry) {
        this(makeAgent, parentRegistry, 3, 1);
    }

    public SubagentScheduler(AgentFactory makeAgent, ToolRegistry parentRegistry, int maxParallel, int maxDepth) {
        this.makeAgent = makeAgent;
        this.parentRegistry = parentRegistry;
        this.maxDepth = maxDepth;
        this.slots = new Semaphore(maxParallel);
    }

    /** 探索类子任务只给只读工具：不能改文件，也就不需要弹确认。 */
    private ToolRegistry exploreRegistry() {
        ToolRegistry sub = new ToolRegistry(parentRegistry.timeoutSeconds);
        for (String name : parentRegistry.names()) {
            Tool t = parentRegistry.get(name);
            if (t.readOnly() && !t.name().equals("spawn_subagent")) sub.register(t);
        }
        return sub;
    }

    public String spawn(String task, int parentDepth) throws InterruptedException {
        if (parentDepth >= maxDepth) return "子任务不能再派发子任务。请直接完成这项工作。";
        slots.acquire();
        try {
            spawned.incrementAndGet();
            Outcome outcome;
            try {
                outcome = makeAgent.make(exploreRegistry(), SUBAGENT_PROMPT, parentDepth + 1).run(task);
            } catch (RuntimeException e) {     // 一个子任务失败不能拖垮其他的
                return "子任务执行失败：" + e.getClass().getSimpleName() + ": " + e.getMessage();
            }
            if (outcome.stopped() != Outcome.Stopped.FINISHED) {
                return "子任务没有正常结束（" + outcome.stopped().label() + "）。它最后的说明：" + outcome.text();
            }
            return outcome.text();
        } finally {
            slots.release();
        }
    }

    public Tool asTool(int depth) {
        return Tool.named("spawn_subagent").readOnly()     // 只读：模型一次发出多个派发时可以并行
                .description("""
                        派发一个只读的子任务去独立完成一项查找或调研，返回它的结论。

                        适合：在大仓库里定位一段逻辑、几个互不依赖的问题、过程冗长但结论简短的工作。
                        不适合：修改代码、两三步就能做完的小事（子任务有固定开销，小事派出去更慢更贵）。
                        子任务看不到当前对话，任务说明必须自己就能读懂：要回答什么问题、已经知道什么、
                        希望以什么形式返回。子任务给出的位置，据此修改之前要自己读一遍确认。""")
                .required("task", "string", "完整的任务说明")
                .run(args -> spawn(Json.str(args.get("task")), depth));
    }
}
