package cn.agentjourney.agent.tools;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/** shell 风格的通配匹配：* 任意一段（包括 /），? 一个字符，[abc] 字符集合，[!abc] 取反。区分大小写。 */
public final class Glob {
    private Glob() {}

    // 同一条规则会被反复拿来匹配，编译结果留着。null 值存不进去，所以写不成正则的模式用 NEVER 占位
    private static final Map<String, Pattern> CACHE = new ConcurrentHashMap<>();
    private static final Pattern NEVER = Pattern.compile("(?!)");

    public static boolean matches(String pattern, String value) {
        Pattern rx = CACHE.computeIfAbsent(pattern, Glob::compile);
        return rx == NEVER ? pattern.equals(value) : rx.matcher(value).matches();
    }

    private static Pattern compile(String glob) {
        try {
            return Pattern.compile(toRegex(glob), Pattern.DOTALL);
        } catch (PatternSyntaxException e) {      // 例如 [z-a]：当成普通文字，只有一模一样才算匹配
            return NEVER;
        }
    }

    static String toRegex(String glob) {
        StringBuilder rx = new StringBuilder();
        int n = glob.length();
        int i = 0;
        while (i < n) {
            int cp = glob.codePointAt(i);
            i += Character.charCount(cp);
            if (cp == '*') {
                rx.append(".*");
            } else if (cp == '?') {
                rx.append('.');
            } else if (cp == '[') {
                int j = i;
                if (j < n && glob.charAt(j) == '!') j++;
                if (j < n && glob.charAt(j) == ']') j++;      // 紧跟在 [ 或 [! 后面的 ] 是集合里的普通字符
                while (j < n && glob.charAt(j) != ']') j++;
                if (j >= n) {
                    rx.append("\\[");                          // 没有配对的 ]，当普通字符
                    continue;
                }
                String body = glob.substring(i, j);
                boolean negate = body.startsWith("!");
                if (negate) body = body.substring(1);
                // 集合里对正则有特殊含义的字符都转义掉，只留下表示范围的 -
                body = body.replaceAll("([\\\\\\[\\]&^])", "\\\\$1");
                rx.append(negate ? "[^" : "[").append(body).append(']');
                i = j + 1;
            } else {
                rx.append(Pattern.quote(new String(Character.toChars(cp))));
            }
        }
        return rx.toString();
    }
}
