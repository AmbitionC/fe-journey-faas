package cn.agentjourney.agent;

import cn.agentjourney.agent.kernel.Agent;
import cn.agentjourney.agent.kernel.ContextManager;
import cn.agentjourney.agent.kernel.PermissionGate;
import cn.agentjourney.agent.kernel.SubagentScheduler;
import cn.agentjourney.agent.model.ModelClient;
import cn.agentjourney.agent.state.Session;
import cn.agentjourney.agent.tools.FileTools;
import cn.agentjourney.agent.tools.ShellTool;
import cn.agentjourney.agent.tools.ToolRegistry;
import cn.agentjourney.agent.tools.Workspace;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * 把各部件装配成一个可运行的编程 Agent。终端和测试都从这里拿同一个内核。
 *
 * <pre>
 * Agent agent = CodingAgent.in(Path.of("."), model).rules(rules).asker(asker).build();
 * Outcome outcome = agent.run("有测试挂了，帮我修好");
 * </pre>
 */
public final class CodingAgent {
    public static final String INSTRUCTION_FILE = "AGENT.md";
    public static final String SYSTEM_PROMPT = """
            你是一个在终端里工作的编程助手，在用户的项目目录中完成任务。

            工作方式：
            - 先了解再动手：用 find_files、search_text、read_file 弄清相关代码，不要凭猜测修改。
            - 修改文件之前必须先读取它。小改动用 edit_file，新建或整体重写用 write_file。
            - 改完代码后运行相关测试来验证，测试通过了才算完成；没有验证过就不要说“已修复”。
            - 不要修改测试来让它通过，除非用户明确要求改测试。
            - 工具返回错误时，读懂错误信息再决定下一步，不要原样重试。
            - 操作被拒绝时，不要重试同样的操作，换一种做法或向用户说明。
            - 完成后用几句话说明：改了什么、为什么、怎么验证的。

            当前项目目录：{cwd}
            """;

    private final Path cwd;
    private final ModelClient model;
    private List<PermissionGate.Rule> rules = List.of();
    private PermissionGate.Asker asker;
    private boolean headless;
    private Path sessionFile;
    private Consumer<Event> onEvent;
    private int maxTurns = 40;
    private int commandTimeout = 120;
    private int windowTokens = 64_000;
    private boolean subagents = true;
    private ShellTool.Executor executor;
    private Path home = Path.of(System.getProperty("user.home"));

    private CodingAgent(Path cwd, ModelClient model) {
        this.cwd = cwd;
        this.model = model;
    }

    public static CodingAgent in(Path cwd, ModelClient model) { return new CodingAgent(cwd, model); }

    public CodingAgent rules(List<PermissionGate.Rule> rules) { this.rules = rules; return this; }

    public CodingAgent asker(PermissionGate.Asker asker) { this.asker = asker; return this; }

    public CodingAgent headless(boolean headless) { this.headless = headless; return this; }

    public CodingAgent sessionFile(Path file) { this.sessionFile = file; return this; }

    public CodingAgent onEvent(Consumer<Event> sink) { this.onEvent = sink; return this; }

    public CodingAgent maxTurns(int n) { this.maxTurns = n; return this; }

    public CodingAgent commandTimeout(int seconds) { this.commandTimeout = seconds; return this; }

    public CodingAgent windowTokens(int n) { this.windowTokens = n; return this; }

    public CodingAgent subagents(boolean on) { this.subagents = on; return this; }

    /** 命令换个地方执行（例如沙箱）。不设就在本机执行。 */
    public CodingAgent executor(ShellTool.Executor executor) { this.executor = executor; return this; }

    /** 个人通用习惯放在 home/.agent/AGENT.md。测试里换成临时目录。 */
    public CodingAgent home(Path home) { this.home = home; return this; }

    public Agent build() {
        Workspace ws = new Workspace(cwd);
        ToolRegistry registry = new ToolRegistry(commandTimeout + 30);
        for (Tool t : FileTools.all(ws)) registry.register(t);
        registry.register(ShellTool.create(ws, commandTimeout, executor));
        PermissionGate gate = new PermissionGate(ws, rules, asker, headless);

        // 系统提示词之后是项目说明：都是稳定内容，放在最前面
        String system = SYSTEM_PROMPT.replace("{cwd}", ws.root.toString());
        String instructions = loadInstructions(ws.root, home);
        if (!instructions.isEmpty()) system += "\n# 项目说明\n" + instructions + "\n";

        if (subagents) {
            // 子任务与主任务共用同一个闸门，没有例外
            SubagentScheduler scheduler = new SubagentScheduler((subRegistry, prompt, depth) -> {
                Agent sub = new Agent(model, subRegistry, gate, prompt, null, null,
                        new ContextManager(windowTokens, model), depth);
                sub.maxTurns = 30;
                return sub;
            }, registry);
            registry.register(scheduler.asTool(0));
        }

        Agent agent = new Agent(model, registry, gate, system, new Session(sessionFile), onEvent,
                new ContextManager(windowTokens, model), 0);
        agent.maxTurns = maxTurns;
        return agent;
    }

    /** 按从通用到具体的顺序拼接：用户主目录下的个人习惯，再到项目根目录的约定。 */
    static String loadInstructions(Path cwd, Path home) {
        List<String> parts = new ArrayList<>();
        Path[] files = {home.resolve(".agent").resolve(INSTRUCTION_FILE), cwd.resolve(INSTRUCTION_FILE)};
        String[] labels = {"个人通用习惯", "项目约定"};
        for (int i = 0; i < files.length; i++) {
            if (!Files.isRegularFile(files[i])) continue;
            try {
                parts.add("## " + labels[i] + "（" + files[i] + "）\n" + Files.readString(files[i]).strip());
            } catch (IOException e) {
                // 读不了就当没有，不影响启动
            }
        }
        return String.join("\n\n", parts);
    }
}
