package cn.agentjourney.agent.kernel;

import cn.agentjourney.agent.Event;
import cn.agentjourney.agent.Json;
import cn.agentjourney.agent.Message;
import cn.agentjourney.agent.Tool;
import cn.agentjourney.agent.ToolCall;
import cn.agentjourney.agent.Usage;
import cn.agentjourney.agent.kernel.Outcome.Stopped;
import cn.agentjourney.agent.model.ModelClient;
import cn.agentjourney.agent.model.ModelException;
import cn.agentjourney.agent.state.Session;
import cn.agentjourney.agent.tools.ToolRegistry;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/** 执行循环：拼上下文、调模型、过权限、执行工具、追加结果，直到模型不再要求调用工具。 */
public final class Agent {
    static final String WRAP_UP = "已达到本次任务的轮次上限。请不要再调用任何工具，直接用文字总结："
            + "已经完成了什么、还剩什么没做、你建议用户下一步做什么。";
    static final String REPEAT_HINT = "你已经连续多次用完全相同的参数调用同一个工具，结果不会变化。"
            + "请换一种做法，或者说明卡在了哪里。";

    public final ModelClient model;
    public final ToolRegistry registry;
    public final PermissionGate gate;
    private final Session session;
    private final Consumer<Event> emit;
    private final ContextManager context;
    public final int depth;                 // 0 是主任务，子任务是 1
    public int maxTurns = 40;
    public int maxRetries = 3;
    public long retryBaseDelayMillis = 1000;
    public int repeatLimit = 3;

    private final List<Message> messages = new ArrayList<>();
    private final List<String> recent = new ArrayList<>();
    private final AtomicBoolean interrupted = new AtomicBoolean();
    // 只读工具并行执行用。每个任务一个虚拟线程，空闲时不占任何线程，所以整个进程共用一个、不需要关闭
    private static final ExecutorService PARALLEL = Executors.newVirtualThreadPerTaskExecutor();

    public Agent(ModelClient model, ToolRegistry registry, PermissionGate gate, String systemPrompt,
                 Session session, Consumer<Event> onEvent, ContextManager context, int depth) {
        this.model = model;
        this.registry = registry;
        this.gate = gate;
        this.session = session != null ? session : new Session(null);
        this.emit = onEvent != null ? onEvent : e -> {};
        this.context = context;
        this.depth = depth;
        append(Message.system(systemPrompt));
    }

    /** 用户按了中断键。当前这一步做完后退出，会话记录保持完整。 */
    public void interrupt() { interrupted.set(true); }

    // --- 主循环 ---------------------------------------------------------
    public Outcome run(String task) {
        interrupted.set(false);
        append(Message.user(task));
        Usage usage = Usage.ZERO;
        int turns = 0;
        while (true) {
            if (interrupted.get()) return finish("（已被用户中断）", Stopped.INTERRUPTED, turns, usage);
            boolean wrappingUp = turns >= maxTurns;
            if (wrappingUp) append(Message.user(WRAP_UP));
            ModelClient.Reply reply;
            try {
                reply = callModel(!wrappingUp);
            } catch (ModelException e) {
                return finish("模型接口不可用，任务中止：" + e.getMessage(), Stopped.MODEL_ERROR, turns, usage);
            }
            usage = usage.plus(reply.usage());
            turns++;
            Message message = reply.message();
            append(message);
            if (wrappingUp) return finish(message.content, Stopped.MAX_TURNS, turns, usage);
            if (message.toolCalls.isEmpty()) return finish(message.content, Stopped.FINISHED, turns, usage);
            for (Message result : executeBatch(message.toolCalls)) append(result);
            if (stuck(message.toolCalls)) append(Message.user(REPEAT_HINT));
        }
    }

    /** 接口报错或超时按指数退避重试，超过上限才向上抛。 */
    private ModelClient.Reply callModel(boolean withTools) throws ModelException {
        if (context != null) context.prepare(messages);
        ModelClient.Listener listener = new ModelClient.Listener() {
            @Override
            public void onText(String text) { emit.accept(new Event("text_delta", Map.of("text", text))); }

            @Override
            public void onToolDelta(int index, String name, String part) {
                emit.accept(new Event("tool_delta", Map.of("index", index, "name", name, "delta", part)));
            }
        };
        for (int attempt = 1; ; attempt++) {
            try {
                ModelClient.Reply reply = model.chat(messages, withTools ? registry.schemas() : List.of(), listener);
                if (context != null) context.observe(reply.usage());
                return reply;
            } catch (ModelException e) {
                if (!e.retryable || attempt > maxRetries) throw e;
                try {
                    Thread.sleep(retryBaseDelayMillis << (attempt - 1));
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw e;
                }
            }
        }
    }

    // --- 工具执行 -------------------------------------------------------
    /** 只读的工具并行执行，会改东西的按顺序执行。结果顺序始终和调用顺序一致。 */
    private List<Message> executeBatch(List<ToolCall> calls) {
        boolean allReadOnly = calls.stream().allMatch(c -> {
            Tool t = registry.get(c.name());
            return t != null && t.readOnly();
        });
        List<String> results = new ArrayList<>();
        if (allReadOnly && calls.size() > 1) {
            List<Future<String>> futures = new ArrayList<>();
            for (ToolCall c : calls) futures.add(PARALLEL.submit(() -> guardedExecute(c)));
            for (int i = 0; i < calls.size(); i++) {
                try {
                    results.add(futures.get(i).get());      // 按提交顺序取，结果顺序就和调用顺序一致
                } catch (ExecutionException e) {
                    results.add("工具 " + calls.get(i).name() + " 执行出错：" + e.getCause());
                } catch (InterruptedException e) {
                    futures.forEach(f -> f.cancel(true));      // 不再等了，也不能让剩下的继续在后台跑
                    Thread.currentThread().interrupt();
                    results.add("工具 " + calls.get(i).name() + " 的执行被中断。");
                }
            }
        } else {
            for (ToolCall c : calls) results.add(guardedExecute(c));
        }
        List<Message> out = new ArrayList<>();
        for (int i = 0; i < calls.size(); i++) out.add(Message.tool(results.get(i), calls.get(i).id()));
        return out;
    }

    /** 校验参数、过权限闸门、执行。任何一步出问题，都变成一段文字交回模型。 */
    private String guardedExecute(ToolCall call) {
        String problem = registry.validate(call);
        if (problem != null) return problem;
        Tool tool = registry.get(call.name());
        PermissionGate.Verdict verdict = gate.check(tool, call);
        if (!verdict.allowed()) {
            session.note("tool_denied", fields("id", call.id(), "name", call.name(), "reason", verdict.reason()));
            // 被拦下的调用没有 tool_start，把参数带在这里，界面才能显示拦下的是什么
            emit.accept(new Event("tool_end", fields("id", call.id(), "name", call.name(), "denied", true,
                    "result", verdict.reason(), "arguments", call.arguments())));
            return verdict.reason();
        }
        session.note("tool_start", fields("id", call.id(), "name", call.name(), "arguments", call.arguments()));
        emit.accept(new Event("tool_start", fields("id", call.id(), "name", call.name(), "arguments", call.arguments())));
        String result = registry.execute(call);
        emit.accept(new Event("tool_end", fields("id", call.id(), "name", call.name(), "denied", false, "result", result)));
        return result;
    }

    /** 重复调用检测：连续若干轮的调用完全相同。 */
    private boolean stuck(List<ToolCall> calls) {
        List<Object> sig = new ArrayList<>();
        for (ToolCall c : calls) sig.add(List.of(c.name(), c.arguments()));
        recent.add(Json.writeSorted(sig));
        while (recent.size() > repeatLimit) recent.remove(0);
        return recent.size() == repeatLimit && recent.stream().distinct().count() == 1;
    }

    // --- 记录 -----------------------------------------------------------
    private void append(Message m) {
        messages.add(m);
        session.message(m);
    }

    private Outcome finish(String text, Stopped stopped, int turns, Usage usage) {
        session.note("done", fields("stopped", stopped.label(), "turns", turns,
                "input_tokens", usage.input(), "output_tokens", usage.output()));
        emit.accept(new Event("done", fields("stopped", stopped.label(), "turns", turns)));
        return new Outcome(text, stopped, turns, usage, List.copyOf(messages));
    }

    private static Map<String, Object> fields(Object... pairs) {
        Map<String, Object> map = new LinkedHashMap<>();
        for (int i = 0; i < pairs.length; i += 2) map.put((String) pairs[i], pairs[i + 1]);
        return map;
    }
}
