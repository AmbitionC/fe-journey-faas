package cn.agentjourney.agent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 全系统只流转这一种消息格式，和 OpenAI 兼容接口保持一致。 */
public final class Message {
    public final String role;               // system / user / assistant / tool
    public String content;                  // 可变：上下文管理器会把旧的工具结果换成占位符
    public final List<ToolCall> toolCalls;  // 仅 assistant
    public final String toolCallId;         // 仅 tool
    public final String reasoning;          // 思考内容。部分模型要求带工具调用的回复原样回传它

    public Message(String role, String content, List<ToolCall> toolCalls, String toolCallId, String reasoning) {
        this.role = role;
        this.content = content == null ? "" : content;
        this.toolCalls = toolCalls == null ? List.of() : List.copyOf(toolCalls);
        this.toolCallId = toolCallId;
        this.reasoning = reasoning == null ? "" : reasoning;
    }

    public static Message system(String content) { return new Message("system", content, null, null, null); }

    public static Message user(String content) { return new Message("user", content, null, null, null); }

    public static Message assistant(String content, ToolCall... calls) {
        return new Message("assistant", content, List.of(calls), null, null);
    }

    public static Message tool(String content, String toolCallId) {
        return new Message("tool", content, null, toolCallId, null);
    }

    public Map<String, Object> toApi() {
        Map<String, Object> d = new LinkedHashMap<>();
        d.put("role", role);
        d.put("content", content);
        if (!toolCalls.isEmpty()) {
            List<Object> calls = new ArrayList<>();
            for (ToolCall c : toolCalls) {
                Map<String, Object> fn = new LinkedHashMap<>();
                fn.put("name", c.name());
                fn.put("arguments", Json.write(c.arguments()));   // 接口要求参数是一段 JSON 文本
                Map<String, Object> call = new LinkedHashMap<>();
                call.put("id", c.id());
                call.put("type", "function");
                call.put("function", fn);
                calls.add(call);
            }
            d.put("tool_calls", calls);
        }
        if (toolCallId != null) d.put("tool_call_id", toolCallId);
        if (!reasoning.isEmpty()) d.put("reasoning_content", reasoning);
        return d;
    }

    public static Message fromApi(Map<String, Object> d) {
        List<ToolCall> calls = new ArrayList<>();
        for (Object item : Json.list(d.get("tool_calls"))) {
            Map<String, Object> c = Json.obj(item);
            Map<String, Object> fn = Json.obj(c.get("function"));
            calls.add(new ToolCall(Json.str(c.get("id")), Json.str(fn.get("name")), parseArguments(fn.get("arguments"))));
        }
        Object id = d.get("tool_call_id");
        return new Message(Json.str(d.get("role")), Json.str(d.get("content")), calls,
                id instanceof String s ? s : null, Json.str(d.get("reasoning_content")));
    }

    /** 参数可能是一段 JSON 文本，也可能已经是对象。解析不了时原样带回。 */
    public static Map<String, Object> parseArguments(Object raw) {
        if (raw instanceof Map) return Json.obj(raw);
        String text = raw instanceof String s && !s.isBlank() ? s : "{}";
        try {
            return Json.parseObject(text);
        } catch (Json.JsonException e) {
            Map<String, Object> bad = new LinkedHashMap<>();
            bad.put(ToolCall.RAW, text);
            return bad;
        }
    }
}
