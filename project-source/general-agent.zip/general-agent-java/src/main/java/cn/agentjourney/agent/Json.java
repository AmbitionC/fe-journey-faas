package cn.agentjourney.agent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Pattern;

/**
 * 一个够用的 JSON 读写器，两百多行。对象读成 LinkedHashMap，数组读成 ArrayList，
 * 整数读成 Long，小数读成 Double。内核因此不需要任何第三方库。
 */
public final class Json {
    private Json() {}

    public static class JsonException extends RuntimeException {
        public JsonException(String message) { super(message); }
    }

    // --- 读 ---------------------------------------------------------------
    public static Object parse(String text) {
        Parser p = new Parser(text);
        p.skipSpace();
        Object value = p.value();
        p.skipSpace();
        if (p.pos < text.length()) throw p.error("末尾有多余的内容");
        return value;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> parseObject(String text) {
        Object value = parse(text);
        if (!(value instanceof Map)) throw new JsonException("期望一个 JSON 对象");
        return (Map<String, Object>) value;
    }

    /** 取值的小工具：类型不对或不存在时返回空集合 / 默认值，省掉满屏的强制转换。 */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> obj(Object value) {
        return value instanceof Map ? (Map<String, Object>) value : Map.of();
    }

    @SuppressWarnings("unchecked")
    public static List<Object> list(Object value) {
        return value instanceof List ? (List<Object>) value : List.of();
    }

    public static String str(Object value) {
        return value instanceof String s ? s : "";
    }

    /** 超出 int 范围的数夹到边界上，不让它悄悄绕回一个小数字。 */
    public static int integer(Object value, int fallback) {
        if (!(value instanceof Number n)) return fallback;
        return (int) Math.max(Integer.MIN_VALUE, Math.min(Integer.MAX_VALUE, n.longValue()));
    }

    private static final class Parser {
        static final int MAX_DEPTH = 500;      // 嵌套太深直接报错，不等到栈溢出
        static final Pattern NUMBER = Pattern.compile("-?(0|[1-9]\\d*)(\\.\\d+)?([eE][+-]?\\d+)?");
        final String s;
        int pos;
        int depth;

        Parser(String s) { this.s = s; }

        JsonException error(String what) { return new JsonException(what + "（位置 " + pos + "）"); }

        void skipSpace() {
            while (pos < s.length() && " \t\n\r".indexOf(s.charAt(pos)) >= 0) pos++;
        }

        Object value() {
            if (pos >= s.length()) throw error("内容提前结束");
            char c = s.charAt(pos);
            if (c == '{' || c == '[') {
                if (++depth > MAX_DEPTH) throw error("嵌套超过 " + MAX_DEPTH + " 层");
                Object value = c == '{' ? object() : array();
                depth--;
                return value;
            }
            if (c == '"') return string();
            if (s.startsWith("true", pos)) { pos += 4; return Boolean.TRUE; }
            if (s.startsWith("false", pos)) { pos += 5; return Boolean.FALSE; }
            if (s.startsWith("null", pos)) { pos += 4; return null; }
            return number();
        }

        Map<String, Object> object() {
            Map<String, Object> map = new LinkedHashMap<>();
            pos++;
            skipSpace();
            if (peek('}')) return map;
            while (true) {
                skipSpace();
                if (pos >= s.length() || s.charAt(pos) != '"') throw error("对象的键必须是字符串");
                String key = string();
                skipSpace();
                expect(':');
                skipSpace();
                map.put(key, value());
                skipSpace();
                if (peek('}')) return map;
                expect(',');
            }
        }

        List<Object> array() {
            List<Object> list = new ArrayList<>();
            pos++;
            skipSpace();
            if (peek(']')) return list;
            while (true) {
                skipSpace();
                list.add(value());
                skipSpace();
                if (peek(']')) return list;
                expect(',');
            }
        }

        boolean peek(char c) {
            if (pos < s.length() && s.charAt(pos) == c) { pos++; return true; }
            return false;
        }

        void expect(char c) {
            if (!peek(c)) throw error("这里应该是 " + c);
        }

        String string() {
            StringBuilder out = new StringBuilder();
            pos++;
            while (true) {
                if (pos >= s.length()) throw error("字符串没有结束");
                char c = s.charAt(pos++);
                if (c == '"') return out.toString();
                if (c < 0x20) throw error("字符串里有没转义的控制字符");
                if (c != '\\') { out.append(c); continue; }
                if (pos >= s.length()) throw error("字符串没有结束");
                char e = s.charAt(pos++);
                switch (e) {
                    case 'n' -> out.append('\n');
                    case 't' -> out.append('\t');
                    case 'r' -> out.append('\r');
                    case 'b' -> out.append('\b');
                    case 'f' -> out.append('\f');
                    case 'u' -> {
                        if (pos + 4 > s.length() || !s.substring(pos, pos + 4).matches("[0-9a-fA-F]{4}")) {
                            throw error("\\u 后面要有四位十六进制数");
                        }
                        out.append((char) Integer.parseInt(s.substring(pos, pos + 4), 16));
                        pos += 4;
                    }
                    case '"', '\\', '/' -> out.append(e);
                    default -> throw error("不认识的转义 \\" + e);
                }
            }
        }

        Object number() {
            int start = pos;
            while (pos < s.length() && "+-0123456789.eE".indexOf(s.charAt(pos)) >= 0) pos++;
            String raw = s.substring(start, pos);
            if (raw.isEmpty()) throw error("不认识的内容");
            if (!NUMBER.matcher(raw).matches()) throw error("数字格式不对：" + raw);
            if (raw.contains(".") || raw.contains("e") || raw.contains("E")) return Double.parseDouble(raw);
            try {
                return Long.parseLong(raw);
            } catch (NumberFormatException e) {
                return Double.parseDouble(raw);      // 比 long 还大的整数：当成小数读，精度会丢，但不报错
            }
        }
    }

    // --- 写 ---------------------------------------------------------------
    public static String write(Object value) {
        StringBuilder out = new StringBuilder();
        write(value, out, false);
        return out.toString();
    }

    /** 键按字典序输出。两次调用的参数是否“完全相同”靠它来比，不受键的顺序影响。 */
    public static String writeSorted(Object value) {
        StringBuilder out = new StringBuilder();
        write(value, out, true);
        return out.toString();
    }

    private static void write(Object value, StringBuilder out, boolean sorted) {
        if (value == null) {
            out.append("null");
        } else if (value instanceof String s) {
            quote(s, out);
        } else if (value instanceof Double || value instanceof Float) {
            double d = ((Number) value).doubleValue();
            // 不用科学计数法：时间戳这样的大数要能直接读；JSON 里也没有 NaN 和无穷
            out.append(Double.isFinite(d) ? new java.math.BigDecimal(Double.toString(d)).toPlainString() : "null");
        } else if (value instanceof Number || value instanceof Boolean) {
            out.append(value);
        } else if (value instanceof Map<?, ?> map) {
            Map<?, ?> shown = sorted ? new TreeMap<>(map) : map;
            out.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : shown.entrySet()) {
                if (!first) out.append(',');
                first = false;
                quote(String.valueOf(e.getKey()), out);
                out.append(':');
                write(e.getValue(), out, sorted);
            }
            out.append('}');
        } else if (value instanceof Iterable<?> items) {
            out.append('[');
            boolean first = true;
            for (Object item : items) {
                if (!first) out.append(',');
                first = false;
                write(item, out, sorted);
            }
            out.append(']');
        } else {
            quote(value.toString(), out);
        }
    }

    private static void quote(String s, StringBuilder out) {
        out.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> {
                    if (c < 0x20) out.append(String.format("\\u%04x", (int) c));
                    else out.append(c);     // 中文原样输出，不转成 \\uXXXX
                }
            }
        }
        out.append('"');
    }
}
