package cn.agentjourney.agent.kernel;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 判定 shell 命令之前的静态分析：拆段、找重定向目标、识别几类一定不能做的命令。 */
public final class Commands {
    private Commands() {}

    // 单个 & 是后台执行，也能把两条命令接在一起；>& 和 &> 里的 & 属于重定向，不拆
    private static final Pattern SPLIT = Pattern.compile("&&|\\|\\||;|\\||\\n|(?<![>&])&(?![>&])");
    private static final Pattern REDIRECT = Pattern.compile("(?:\\d*|&)>>?\\s*([^\\s&|;<>]+)");
    static final Pattern SUBSTITUTION = Pattern.compile("\\$\\(|`");
    private static final Set<String> PREFIXES = Set.of("sudo", "env", "nohup", "time");
    private static final Set<String> DISK_OR_POWER = Set.of("mkfs", "fdisk", "shutdown", "reboot", "halt", "poweroff");
    private static final Set<String> WHOLE_DIRS = Set.of("/", "/*", "~", "$HOME", ".", "..", "*");

    /** 按 &&、||、;、|、单个 & 拆成若干段，每一段分别判定。 */
    public static List<String> split(String command) {
        List<String> out = new ArrayList<>();
        for (String seg : SPLIT.split(command)) {
            if (!seg.isBlank()) out.add(seg.strip());
        }
        return out;
    }

    /** 输出重定向写到哪些文件。/dev/null 这类不算。 */
    public static List<String> redirectTargets(String segment) {
        List<String> out = new ArrayList<>();
        Matcher m = REDIRECT.matcher(segment);
        while (m.find()) {
            String target = m.group(1);
            if (!target.startsWith("/dev/")) out.add(target.replaceAll("^['\"]+|['\"]+$", ""));
        }
        return out;
    }

    /** 内置拒绝：按命令名和参数集合判断，不按字符串。rm -rf 和 rm -fr 是同一件事。返回原因，不拒绝返回 null。 */
    public static String builtinDeny(String segment) {
        List<String> words = words(segment);
        if (words == null) return null;
        while (!words.isEmpty() && PREFIXES.contains(words.get(0))) words = words.subList(1, words.size());
        if (words.isEmpty()) return null;
        String cmd = words.get(0).substring(words.get(0).lastIndexOf('/') + 1);
        List<String> args = words.subList(1, words.size());
        Set<Character> flags = new HashSet<>();
        Set<String> longFlags = new HashSet<>();
        List<String> targets = new ArrayList<>();
        for (String a : args) {
            if (a.startsWith("--")) longFlags.add(a);
            else if (a.startsWith("-")) a.substring(1).chars().forEach(c -> flags.add((char) c));
            else targets.add(a);
        }
        if (cmd.equals("rm") && (flags.contains('r') || flags.contains('R') || longFlags.contains("--recursive"))) {
            for (String t : targets) {
                if (WHOLE_DIRS.contains(t) || t.startsWith("/") || t.startsWith("~/") || t.startsWith("../")
                        || t.startsWith("$HOME/")) {
                    return "递归删除项目之外或整个目录";
                }
            }
        }
        if (DISK_OR_POWER.contains(cmd) || cmd.startsWith("mkfs.")) return "改写磁盘或关机";
        if (cmd.equals("dd") && args.stream().anyMatch(a -> a.startsWith("of=/dev/"))) return "直接写磁盘设备";
        return null;
    }

    /** 像 shell 那样把一段命令切成词：认单引号、双引号和反斜杠。引号没配对返回 null。 */
    static List<String> words(String s) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inWord = false;
        char quote = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (quote == '\'') {
                if (c == '\'') quote = 0; else cur.append(c);
            } else if (quote == '"') {
                if (c == '"') quote = 0;
                else if (c == '\\' && i + 1 < s.length() && "\"\\$`".indexOf(s.charAt(i + 1)) >= 0) cur.append(s.charAt(++i));
                else cur.append(c);
            } else if (c == '\'' || c == '"') {
                quote = c;
                inWord = true;
            } else if (c == '\\' && i + 1 < s.length()) {
                cur.append(s.charAt(++i));
                inWord = true;
            } else if (Character.isWhitespace(c)) {
                if (inWord) out.add(cur.toString());
                cur.setLength(0);
                inWord = false;
            } else {
                cur.append(c);
                inWord = true;
            }
        }
        if (quote != 0) return null;
        if (inWord) out.add(cur.toString());
        return out;
    }
}
