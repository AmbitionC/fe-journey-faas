package cn.agentjourney.agent.kernel;

import cn.agentjourney.agent.Message;
import cn.agentjourney.agent.Usage;

import java.util.List;

/** 一次任务的结果。stopped 说明循环是怎么停下来的。 */
public record Outcome(String text, Stopped stopped, int turns, Usage usage, List<Message> messages) {

    public enum Stopped {
        FINISHED, MAX_TURNS, INTERRUPTED, MODEL_ERROR;

        /** 写进会话记录和事件里的名字，和 Python 版一致。 */
        public String label() { return name().toLowerCase(); }
    }
}
