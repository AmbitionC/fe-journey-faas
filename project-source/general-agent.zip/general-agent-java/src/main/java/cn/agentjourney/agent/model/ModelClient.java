package cn.agentjourney.agent.model;

import cn.agentjourney.agent.Message;
import cn.agentjourney.agent.Usage;

import java.util.List;
import java.util.Map;

/** 模型接口。内核只依赖这一个接口，换模型只改配置。 */
public interface ModelClient {

    Reply chat(List<Message> messages, List<Map<String, Object>> tools, Listener listener) throws ModelException;

    record Reply(Message message, Usage usage) {}

    /** 流式输出的进度。两个方法都有空实现，不关心的调用方传 Listener.NONE。 */
    interface Listener {
        Listener NONE = new Listener() {};

        /** 新到的一段正文。 */
        default void onText(String text) {}

        /** 工具调用的参数还在生成时的进度：第几个调用、工具名、新到的一段参数原文。 */
        default void onToolDelta(int index, String name, String part) {}
    }
}
