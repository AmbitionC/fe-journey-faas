package cn.agentjourney.agent.model;

import cn.agentjourney.agent.Json;
import cn.agentjourney.agent.Message;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * OpenAI 兼容接口的流式客户端，只用 JDK 自带的 HttpClient。
 *
 * 环境变量：OPENAI_BASE_URL、OPENAI_API_KEY、LLM_MODEL。
 * LLM_EXTRA_BODY 是可选的 JSON，会合并进请求体，用来传各家特有的参数，
 * 例如 DeepSeek 关闭思考：{"thinking": {"type": "disabled"}}。
 */
public final class OpenAICompatModel implements ModelClient {
    private final String baseUrl;
    private final String apiKey;
    private final String model;
    private final Duration timeout;
    private final Map<String, Object> extraBody;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();

    public OpenAICompatModel() {
        this(env("OPENAI_BASE_URL", "https://api.deepseek.com"), env("OPENAI_API_KEY", ""),
                env("LLM_MODEL", "deepseek-chat"), Duration.ofSeconds(120));
    }

    public OpenAICompatModel(String baseUrl, String apiKey, String model, Duration timeout) {
        this.baseUrl = baseUrl.replaceAll("/+$", "");
        this.apiKey = apiKey;
        this.model = model;
        this.timeout = timeout;
        this.extraBody = Json.parseObject(env("LLM_EXTRA_BODY", "{}"));
    }

    private static String env(String key, String fallback) {
        String v = System.getenv(key);
        return v == null || v.isBlank() ? fallback : v;
    }

    @Override
    public Reply chat(List<Message> messages, List<Map<String, Object>> tools, Listener listener) throws ModelException {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", model);
        List<Object> apiMessages = new ArrayList<>();
        for (Message m : messages) apiMessages.add(m.toApi());
        body.put("messages", apiMessages);
        body.put("stream", true);
        body.put("stream_options", Map.of("include_usage", true));
        if (!tools.isEmpty()) body.put("tools", tools);
        body.putAll(extraBody);
        HttpRequest request = HttpRequest.newBuilder(URI.create(baseUrl + "/chat/completions"))
                .timeout(timeout)      // 等到响应头的时限；之后的流式读取另有看门狗
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(Json.write(body)))
                .build();
        HttpResponse<InputStream> response;
        try {
            response = http.send(request, HttpResponse.BodyHandlers.ofInputStream());
        } catch (IOException e) {
            throw new ModelException("模型接口连接失败：" + e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ModelException("调用模型时被中断", false);
        }
        // 上面的 timeout 只管到收到响应头。流式读取阶段要自己盯着：每收到一行就记一次时间，
        // 太久没有新内容就把流关掉，卡在 readLine 上的读取随即报错，按可重试处理
        AtomicLong lastActivity = new AtomicLong(System.nanoTime());
        AtomicBoolean stalled = new AtomicBoolean();
        InputStream stream = response.body();
        Thread watchdog = Thread.ofVirtual().start(() -> {
            try {
                while (System.nanoTime() - lastActivity.get() < timeout.toNanos()) Thread.sleep(200);
                stalled.set(true);
                stream.close();
            } catch (InterruptedException | IOException ignored) {
                // 正常读完时会被打断，什么都不用做
            }
        });
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            int code = response.statusCode();
            if (code != 200) {
                String detail = reader.lines().collect(Collectors.joining("\n"));
                detail = detail.length() > 300 ? detail.substring(0, 300) : detail;
                // 4xx 里只有限流和超时值得重试，其余是请求本身有问题
                throw new ModelException("模型接口返回 " + code + "：" + detail, code == 408 || code == 429 || code >= 500);
            }
            Iterable<String> lines = () -> reader.lines().peek(line -> lastActivity.set(System.nanoTime())).iterator();
            Reply reply = StreamParser.parse(lines, listener);
            if (stalled.get()) throw new IOException("流被看门狗关闭");      // 有的实现关流后读到的是“结束”而不是报错
            return reply;
        } catch (IOException | UncheckedIOException | Json.JsonException e) {
            if (stalled.get()) throw new ModelException("模型接口超过 " + timeout.toSeconds() + " 秒没有返回新内容");
            throw new ModelException("模型接口的响应读取失败：" + e);
        } finally {
            watchdog.interrupt();
        }
    }
}
