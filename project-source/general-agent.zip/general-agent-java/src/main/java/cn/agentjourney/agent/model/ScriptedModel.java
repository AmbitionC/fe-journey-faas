package cn.agentjourney.agent.model;

import cn.agentjourney.agent.Message;
import cn.agentjourney.agent.Usage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** 按预先写好的回复依次作答，用于测试和离线演示，不联网。回复可以是 Message，也可以是 ModelException。 */
public final class ScriptedModel implements ModelClient {
    private final List<Object> replies;
    /** 每次调用时模型看到的完整消息列表，测试用它检查上下文。 */
    public final List<List<Message>> seen = new ArrayList<>();

    public ScriptedModel(Object... replies) {
        this.replies = new ArrayList<>(List.of(replies));
    }

    @Override
    public synchronized Reply chat(List<Message> messages, List<Map<String, Object>> tools, Listener listener)
            throws ModelException {
        seen.add(new ArrayList<>(messages));
        if (replies.isEmpty()) return new Reply(Message.assistant("（脚本已用完）"), Usage.ZERO);
        Object reply = replies.remove(0);
        if (reply instanceof ModelException e) throw e;
        Message m = (Message) reply;
        if (!m.content.isEmpty()) listener.onText(m.content);
        return new Reply(m, new Usage(10, 5));
    }
}
