package cn.agentjourney.agent;

import cn.agentjourney.agent.cli.Main;
import cn.agentjourney.agent.kernel.Agent;
import cn.agentjourney.agent.kernel.Commands;
import cn.agentjourney.agent.kernel.ContextManager;
import cn.agentjourney.agent.kernel.Outcome;
import cn.agentjourney.agent.kernel.Outcome.Stopped;
import cn.agentjourney.agent.kernel.PermissionGate;
import cn.agentjourney.agent.kernel.PermissionGate.Answer;
import cn.agentjourney.agent.kernel.PermissionGate.Decision;
import cn.agentjourney.agent.kernel.PermissionGate.Rule;
import cn.agentjourney.agent.model.ModelClient;
import cn.agentjourney.agent.model.ModelException;
import cn.agentjourney.agent.model.ScriptedModel;
import cn.agentjourney.agent.model.StreamParser;
import cn.agentjourney.agent.state.Session;
import cn.agentjourney.agent.tools.Glob;
import cn.agentjourney.agent.tools.Workspace;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** 用脚本化的假模型驱动，不联网、不花钱。 */
class KernelTest {
    @TempDir
    Path tmp;

    // --- 小工具 ---------------------------------------------------------
    static ToolCall call(String id, String name, Object... pairs) {
        Map<String, Object> args = new LinkedHashMap<>();
        for (int i = 0; i < pairs.length; i += 2) {
            Object v = pairs[i + 1];
            args.put((String) pairs[i], v instanceof Integer n ? Long.valueOf(n) : v);   // JSON 读出来的整数是 Long
        }
        return new ToolCall(id, name, args);
    }

    static Message say(String text, ToolCall... calls) { return Message.assistant(text, calls); }

    static List<String> toolResults(Outcome o) {
        return o.messages().stream().filter(m -> m.role.equals("tool")).map(m -> m.content).toList();
    }

    static final List<Rule> ALLOW_COMMANDS = List.of(Rule.allow("run_command", "*"));

    CodingAgent agentIn(Path dir, ScriptedModel model) {
        return CodingAgent.in(dir, model).home(tmp.resolve("no-home"));
    }

    // --- 执行循环 -------------------------------------------------------
    @Test
    void finishesWhenNoToolCalls() {
        Outcome o = agentIn(tmp, new ScriptedModel(say("你好"))).build().run("开始");
        assertEquals("你好", o.text());
        assertEquals(Stopped.FINISHED, o.stopped());
        assertEquals(1, o.turns());
    }

    @Test
    void failingCommandIsFedBackNotThrown() {
        ScriptedModel model = new ScriptedModel(say("", call("c1", "run_command", "command", "exit 3")), say("换个办法"));
        Outcome o = agentIn(tmp, model).rules(ALLOW_COMMANDS).build().run("开始");
        assertEquals(Stopped.FINISHED, o.stopped());
        assertTrue(toolResults(o).get(0).contains("退出码 3"));
    }

    @Test
    void parallelReadsKeepCallOrder() throws IOException {
        for (String n : List.of("a", "b", "c")) Files.writeString(tmp.resolve(n + ".txt"), n.repeat(3));
        ScriptedModel model = new ScriptedModel(say("", call("ca", "read_file", "path", "a.txt"),
                call("cb", "read_file", "path", "b.txt"), call("cc", "read_file", "path", "c.txt")), say("ok"));
        Outcome o = agentIn(tmp, model).build().run("开始");
        assertEquals(List.of("aaa", "bbb", "ccc"), toolResults(o).stream().map(r -> r.split("\t")[1]).toList());
    }

    @Test
    void readOnlyCallsReallyRunInParallel() {
        // 三个只读调用都要等到“三个人到齐”才能返回。并行的话马上到齐；一个一个跑的话第一个永远等不到，只能超时
        CountDownLatch allStarted = new CountDownLatch(3);
        Agent agent = agentIn(tmp, new ScriptedModel(say("", call("c1", "probe"), call("c2", "probe"), call("c3", "probe")),
                say("ok"))).build();
        agent.registry.register(Tool.named("probe").readOnly().description("测试用").run(args -> {
            allStarted.countDown();
            return allStarted.await(2, TimeUnit.SECONDS) ? "到齐" : "没等到别人";
        }));
        assertEquals(List.of("到齐", "到齐", "到齐"), toolResults(agent.run("开始")));
    }

    @Test
    void writesNeverRunInParallel() {
        AtomicInteger running = new AtomicInteger(), overlaps = new AtomicInteger();
        Agent agent = agentIn(tmp, new ScriptedModel(say("", call("c1", "slow_write"), call("c2", "slow_write"),
                call("c3", "slow_write")), say("ok"))).rules(List.of(Rule.allow("slow_write", "*"))).build();
        agent.registry.register(Tool.named("slow_write").description("测试用").run(args -> {
            if (running.incrementAndGet() > 1) overlaps.incrementAndGet();
            Thread.sleep(30);
            running.decrementAndGet();
            return "ok";
        }));
        agent.run("开始");
        assertEquals(0, overlaps.get());
    }

    @Test
    void maxTurnsEndsWithSummary() throws IOException {
        Files.writeString(tmp.resolve("a.txt"), "x");
        ScriptedModel model = new ScriptedModel(
                say("", call("c0", "read_file", "path", "a.txt", "offset", 0)),
                say("", call("c1", "read_file", "path", "a.txt", "offset", 1)),
                say("", call("c2", "read_file", "path", "a.txt", "offset", 2)),
                say("总结：没做完"));
        Outcome o = agentIn(tmp, model).maxTurns(3).build().run("开始");
        assertEquals(Stopped.MAX_TURNS, o.stopped());
        assertEquals("总结：没做完", o.text());
        List<Message> last = model.seen.get(model.seen.size() - 1);
        assertTrue(last.get(last.size() - 1).content.contains("轮次上限"));
    }

    @Test
    void modelErrorRetriesThenGivesUp() {
        Agent ok = agentIn(tmp, new ScriptedModel(new ModelException("503"), say("好了"))).build();
        ok.retryBaseDelayMillis = 0;
        assertEquals("好了", ok.run("开始").text());

        Agent bad = agentIn(tmp, new ScriptedModel(new ModelException("503"), new ModelException("503"),
                new ModelException("503"), new ModelException("503"), new ModelException("503"))).build();
        bad.retryBaseDelayMillis = 0;
        assertEquals(Stopped.MODEL_ERROR, bad.run("开始").stopped());
        assertEquals(4, ((ScriptedModel) bad.model).seen.size());      // 第一次加三次重试

        ScriptedModel fatal = new ScriptedModel(new ModelException("400 参数不合法", false), say("不该走到这里"));
        assertEquals(Stopped.MODEL_ERROR, agentIn(tmp, fatal).build().run("开始").stopped());
        assertEquals(1, fatal.seen.size());     // 不可重试的不重试
    }

    @Test
    void repeatDetectionNudgesModel() throws IOException {
        Files.writeString(tmp.resolve("a.txt"), "x");
        ScriptedModel model = new ScriptedModel(say("", call("c1", "read_file", "path", "a.txt")),
                say("", call("c2", "read_file", "path", "a.txt")), say("", call("c3", "read_file", "path", "a.txt")),
                say("换个办法"));
        agentIn(tmp, model).build().run("开始");
        List<Message> last = model.seen.get(model.seen.size() - 1);
        assertTrue(last.get(last.size() - 1).content.contains("完全相同的参数"));
    }

    @Test
    void interruptStopsBeforeNextModelCall() throws IOException {
        Files.writeString(tmp.resolve("a.txt"), "x");
        ScriptedModel model = new ScriptedModel(say("", call("c1", "read_file", "path", "a.txt")), say("不该走到这里"));
        Agent[] holder = new Agent[1];
        holder[0] = agentIn(tmp, model).onEvent(e -> {
            if (e.kind().equals("tool_end")) holder[0].interrupt();
        }).build();
        Outcome o = holder[0].run("开始");
        assertEquals(Stopped.INTERRUPTED, o.stopped());
        assertEquals(1, model.seen.size());
        assertEquals("tool", o.messages().get(o.messages().size() - 1).role);    // 这一步的结果已经记下来了
    }

    @Test
    void unknownToolAndBadArgsBecomeText() {
        ScriptedModel model = new ScriptedModel(say("", call("c1", "nope"), call("c2", "read_file", "path", 3)), say("ok"));
        List<String> r = toolResults(agentIn(tmp, model).build().run("开始"));
        assertTrue(r.get(0).contains("没有名为 nope"));
        assertTrue(r.get(1).contains("应为 string"));
    }

    @Test
    void readFileOffsetAndLimitAreClamped() throws IOException {
        Files.writeString(tmp.resolve("a.txt"), "l1\nl2\nl3\nl4\nl5\n");
        ScriptedModel model = new ScriptedModel(say("", call("c1", "read_file", "path", "a.txt", "offset", 1, "limit", 2),
                call("c2", "read_file", "path", "a.txt", "offset", 4294967298L),
                call("c3", "read_file", "path", "a.txt", "limit", 3000000000L)), say("ok"));
        List<String> r = toolResults(agentIn(tmp, model).build().run("开始"));
        assertEquals("    2\tl2\n    3\tl3\n（还有 2 行，用 offset=3 继续读取）", r.get(0));
        assertEquals("（空文件）", r.get(1));                    // 超大的 offset 不会绕回到第 3 行
        assertTrue(r.get(2).endsWith("    5\tl5"), r.get(2));   // 超大的 limit 就是读到底
    }

    // --- 文件工具 -------------------------------------------------------
    @Test
    void editRequiresReadAndUniqueMatch() throws IOException {
        Files.writeString(tmp.resolve("M.java"), "int x = 1;\nint y = 1;\n");
        ScriptedModel model = new ScriptedModel(
                say("", call("c1", "edit_file", "path", "M.java", "old_text", "x = 1", "new_text", "x = 2")),
                say("", call("c2", "read_file", "path", "M.java")),
                say("", call("c3", "edit_file", "path", "M.java", "old_text", "= 1", "new_text", "= 2")),
                say("", call("c4", "edit_file", "path", "M.java", "old_text", "x = 1", "new_text", "x = 2")),
                say("done"));
        List<String> r = toolResults(agentIn(tmp, model).rules(List.of(Rule.allow("edit_file", "*"))).build().run("开始"));
        assertTrue(r.get(0).contains("必须先用 read_file"));
        assertTrue(r.get(2).contains("出现了 2 次"));
        assertTrue(r.get(3).contains("已修改"));
        assertEquals("int x = 2;\nint y = 1;\n", Files.readString(tmp.resolve("M.java")));
    }

    @Test
    void editRefusesFileChangedSinceRead() throws Exception {
        Path f = tmp.resolve("a.txt");
        Files.writeString(f, "one\n");
        ScriptedModel model = new ScriptedModel(say("", call("c1", "read_file", "path", "a.txt")),
                say("", call("c2", "edit_file", "path", "a.txt", "old_text", "one", "new_text", "two")), say("ok"));
        Agent agent = agentIn(tmp, model).rules(List.of(Rule.allow("edit_file", "*"))).onEvent(e -> {
            if (e.kind().equals("tool_end") && "read_file".equals(e.data().get("name"))) {
                try {       // 读完之后，别处把文件改了
                    Files.writeString(f, "changed\n");
                    Files.setLastModifiedTime(f, java.nio.file.attribute.FileTime.fromMillis(System.currentTimeMillis() + 5000));
                } catch (IOException ex) {
                    throw new java.io.UncheckedIOException(ex);
                }
            }
        }).build();
        assertTrue(toolResults(agent.run("开始")).get(1).contains("在你读取之后被修改过"));
        assertEquals("changed\n", Files.readString(f));
    }

    @Test
    void pathOutsideWorkspaceDeniedEvenViaSymlink() throws IOException {
        Path outside = Files.createDirectory(tmp.resolve("outside"));
        Files.writeString(outside.resolve("secret.txt"), "s");
        Path proj = Files.createDirectory(tmp.resolve("proj"));
        Files.createSymbolicLink(proj.resolve("link"), outside);
        ScriptedModel model = new ScriptedModel(say("", call("c1", "read_file", "path", "../outside/secret.txt")),
                say("", call("c2", "read_file", "path", "link/secret.txt")),
                say("", call("c3", "write_file", "path", "link/new.txt", "content", "x")), say("ok"));
        List<String> r = toolResults(agentIn(proj, model).rules(List.of(Rule.allow("write_file", "*"))).build().run("开始"));
        assertEquals(3, r.size());
        assertTrue(r.stream().allMatch(x -> x.contains("之外")), r.toString());
        assertFalse(Files.exists(outside.resolve("new.txt")));
    }

    @Test
    void findAndSearch() throws IOException {
        Files.createDirectories(tmp.resolve("src"));
        Files.createDirectories(tmp.resolve("target"));
        Files.writeString(tmp.resolve("src/Cart.java"), "class Cart {\n  int total() { return 0; }\n}\n");
        Files.writeString(tmp.resolve("target/Cart.class"), "total");
        ScriptedModel model = new ScriptedModel(say("", call("c1", "find_files", "pattern", "*.java"),
                call("c2", "search_text", "pattern", "total\\(", "glob", "*.java"),
                call("c3", "read_file", "path", "src/Cat.java")), say("ok"));
        List<String> r = toolResults(agentIn(tmp, model).build().run("开始"));
        assertEquals("src/Cart.java", r.get(0));
        assertEquals("src/Cart.java:2: int total() { return 0; }", r.get(1));
        assertTrue(r.get(2).contains("名称相近的文件有：src/Cart.java"));      // 构建产物目录不参与
    }

    // --- 权限闸门 -------------------------------------------------------
    @Test
    void headlessDeniesWhatNeedsAsking() {
        ScriptedModel model = new ScriptedModel(say("", call("c1", "run_command", "command", "git push origin main")), say("没法推送"));
        assertTrue(toolResults(agentIn(tmp, model).headless(true).build().run("开始")).get(0).contains("无界面模式"));
    }

    @Test
    void chainedCommandNotAllowedByFirstSegment() throws IOException {
        Files.writeString(tmp.resolve("keep"), "1");
        ScriptedModel model = new ScriptedModel(say("", call("c1", "run_command", "command", "echo hi && rm keep")), say("ok"));
        Outcome o = agentIn(tmp, model).headless(true).rules(List.of(Rule.allow("run_command", "echo *"))).build().run("开始");
        assertTrue(toolResults(o).get(0).contains("视为拒绝"));
        assertTrue(Files.exists(tmp.resolve("keep")));
    }

    @Test
    void denyRuleBeatsAllowAndSessionAlways() {
        List<String> asked = new ArrayList<>();
        ScriptedModel model = new ScriptedModel(say("", call("c1", "run_command", "command", "echo 1")),
                say("", call("c2", "run_command", "command", "echo 2")),
                say("", call("c3", "run_command", "command", "echo x; git push")), say("ok"));
        Outcome o = agentIn(tmp, model).rules(List.of(Rule.deny("run_command", "git push*"))).asker((c, reason) -> {
            asked.add((String) c.arguments().get("command"));
            return Answer.always();
        }).build().run("开始");
        List<String> r = toolResults(o);
        assertEquals(List.of("echo 1"), asked);      // 第二次同类命令不再问
        assertTrue(r.get(1).contains("退出码 0"));
        assertTrue(r.get(2).contains("命中拒绝规则"));
    }

    @Test
    void userDenialNoteReachesModel() {
        ScriptedModel model = new ScriptedModel(say("", call("c1", "run_command", "command", "git push")), say("好的"));
        Outcome o = agentIn(tmp, model).asker((c, reason) -> Answer.deny("不要推送，改完告诉我就行")).build().run("开始");
        assertTrue(toolResults(o).get(0).contains("用户说明：不要推送"));
    }

    @Test
    void builtinDenyAndSplit() {
        assertEquals(List.of("pytest", "rm -rf build", "cat", "ls"), Commands.split("pytest && rm -rf build | cat; ls"));
        for (String bad : List.of("rm -fr /", "sudo rm -r -f ~", "shutdown now", "rm -rf ../other", "rm -rf ~/work",
                "rm -rf $HOME/x", "/bin/rm --recursive '/'", "dd if=/dev/zero of=/dev/sda")) {
            assertNotNull(Commands.builtinDeny(bad), bad);
        }
        for (String fine : List.of("rm -rf build", "rm notes.txt", "rm -rf ./build", "echo 'rm -rf /")) {
            assertNull(Commands.builtinDeny(fine), fine);
        }
    }

    @Test
    void backgroundAmpersandAndRedirectsDoNotSlipPastTheGate() {
        PermissionGate gate = new PermissionGate(new Workspace(tmp), List.of(Rule.allow("run_command", "ls*"),
                Rule.allow("run_command", "echo *"), Rule.allow("run_command", "mvn*")), null, false);
        // 单个 & 也能把两条命令接在一起，拆开后内置拒绝规则才看得到后一条
        assertEquals(List.of("ls", "rm -rf /"), Commands.split("ls & rm -rf /"));
        assertEquals(Decision.DENY, gate.decideCommand("ls & rm -rf /").decision());
        assertEquals(Decision.ASK, gate.decideCommand("ls & curl example.com").decision());
        // 重定向里的 & 不拆
        assertEquals(List.of("mvn test 2>&1"), Commands.split("mvn test 2>&1"));
        assertEquals(Decision.ALLOW, gate.decideCommand("mvn test 2>&1").decision());
        assertEquals(Decision.ALLOW, gate.decideCommand("mvn test > /dev/null").decision());
        // 重定向等于写文件：项目目录之外、主目录、敏感文件一律拒绝
        for (String bad : List.of("echo x > ../outside.txt", "echo x >> /etc/hosts", "echo x > ~/.bashrc", "echo KEY=1 > .env")) {
            assertEquals(Decision.DENY, gate.decideCommand(bad).decision(), bad);
        }
        assertEquals(Decision.ALLOW, gate.decideCommand("echo x > notes.txt").decision());
        // 命令替换看不出会执行什么：即使整条命中放行规则也要问
        assertEquals(Decision.ASK, gate.decideCommand("echo $(cat notes.txt)").decision());
    }

    @Test
    void sensitiveFilesNeedConfirmationEvenForReading() throws IOException {
        Files.writeString(tmp.resolve(".env"), "KEY=1");
        ScriptedModel model = new ScriptedModel(say("", call("c1", "read_file", "path", ".env")), say("ok"));
        assertTrue(toolResults(agentIn(tmp, model).headless(true).build().run("开始")).get(0).contains("视为拒绝"));
    }

    @Test
    void planModeBlocksWritesThenRunsAfterApproval() throws IOException {
        Files.writeString(tmp.resolve("a.txt"), "old");
        ScriptedModel model = new ScriptedModel(
                say("", call("c1", "read_file", "path", "a.txt")),
                say("", call("c2", "write_file", "path", "a.txt", "content", "new")),     // 计划阶段想偷偷动手
                say("计划：把 a.txt 改成 new"),
                say("", call("c3", "write_file", "path", "a.txt", "content", "new")),
                say("改好了"));
        Agent agent = agentIn(tmp, model).rules(List.of(Rule.allow("write_file", "*"))).build();
        List<String> plans = new ArrayList<>();
        Outcome o = Main.planThenRun(agent, "改 a.txt", plan -> {
            plans.add(plan);
            assertFalse(agent.gate.planMode);     // 问用户的时候闸门已经放开
            try {
                assertEquals("old", Files.readString(tmp.resolve("a.txt")));
            } catch (IOException e) {
                throw new java.io.UncheckedIOException(e);
            }
            return "";
        });
        assertEquals(List.of("计划：把 a.txt 改成 new"), plans);
        assertTrue(toolResults(o).get(1).contains("现在是计划模式"));
        assertEquals("new", Files.readString(tmp.resolve("a.txt")));
        assertEquals("改好了", o.text());
    }

    @Test
    void danglingSymlinkCannotBeUsedToWriteOutside() throws IOException {
        Path outside = Files.createDirectory(tmp.resolve("outside"));
        Path proj = Files.createDirectory(tmp.resolve("proj"));
        Files.createSymbolicLink(proj.resolve("evil"), outside.resolve("created.txt"));     // 指向一个还不存在的文件
        ScriptedModel model = new ScriptedModel(say("", call("c1", "write_file", "path", "evil", "content", "x")), say("ok"));
        String r = toolResults(agentIn(proj, model).rules(List.of(Rule.allow("write_file", "*"))).build().run("开始")).get(0);
        assertTrue(r.contains("之外"), r);
        assertFalse(Files.exists(outside.resolve("created.txt")));
    }

    @Test
    void dotDotAfterSymlinkIsResolvedLikeTheShellDoes() throws Exception {
        Path outside = Files.createDirectories(tmp.resolve("outside/sub"));
        Path proj = Files.createDirectory(tmp.resolve("proj"));
        Files.createSymbolicLink(proj.resolve("link"), outside);
        Files.createDirectory(proj.resolve("dir"));
        Workspace ws = new Workspace(proj);
        // link/../x 在 shell 里是 outside 的上一级里的 x，不是项目里的 x
        assertThrows(Workspace.PathException.class, () -> ws.resolve("link/../x"));
        assertEquals(proj.toRealPath().resolve("x"), ws.resolve("dir/../x"));
        assertEquals(proj.toRealPath().resolve("new/deep/file.txt"), ws.resolve("new/deep/file.txt"));
        PermissionGate gate = new PermissionGate(ws, List.of(Rule.allow("run_command", "echo *")), null, false);
        assertEquals(Decision.DENY, gate.decideCommand("echo hi > link/../x").decision());
        assertEquals(Decision.ALLOW, gate.decideCommand("echo hi > dir/../x").decision());
        // 链接绕成环：报路径不合法，而不是死循环
        Files.createSymbolicLink(proj.resolve("a"), Path.of("b"));
        Files.createSymbolicLink(proj.resolve("b"), Path.of("a"));
        assertThrows(Workspace.PathException.class, () -> ws.resolve("a/file"));
    }

    @Test
    void alwaysOnAnEmptyPathDoesNotBecomeAWildcard() throws IOException {
        Files.writeString(tmp.resolve(".env"), "KEY=1");
        List<String> asked = new ArrayList<>();
        ScriptedModel model = new ScriptedModel(say("", call("c1", "edit_file", "path", "", "old_text", "a", "new_text", "b")),
                say("", call("c2", "edit_file", "path", ".env", "old_text", "KEY=1", "new_text", "KEY=2")), say("ok"));
        agentIn(tmp, model).asker((c, reason) -> {
            asked.add((String) c.arguments().get("path"));
            return asked.size() == 1 ? Answer.always() : Answer.deny("");
        }).build().run("开始");
        assertEquals(List.of("", ".env"), asked);      // 第一次答了“以后不再问”，第二次照样要问
        assertEquals("KEY=1", Files.readString(tmp.resolve(".env")));
    }

    @Test
    void rulesFileOnlyAcceptsAllowAndDeny() throws IOException {
        Files.createDirectories(tmp.resolve(".agent"));
        Files.writeString(tmp.resolve(".agent/rules.json"), """
                [{"tool": "run_command", "pattern": "mvn *", "decision": "allow"},
                 {"tool": "run_command", "pattern": "git push*", "decision": "Deny"},
                 {"tool": "run_command", "pattern": "rm *", "decision": "deny"}]""");
        // 写错大小写的那条被忽略，而不是变成放行
        assertEquals(List.of(Rule.allow("run_command", "mvn *"), Rule.deny("run_command", "rm *")), Main.loadRules(tmp));
        assertEquals(List.of(), Main.loadRules(tmp.resolve("nowhere")));
    }

    @Test
    void badPatternInARuleDoesNotCrashTheGate() {
        PermissionGate gate = new PermissionGate(new Workspace(tmp), List.of(Rule.deny("run_command", "rm [z-a]*"),
                Rule.allow("run_command", "ls")), null, false);
        assertEquals(Decision.ALLOW, gate.decideCommand("ls").decision());
    }

    // --- 命令执行、会话记录 ---------------------------------------------
    @Test
    void commandTimeoutKillsTheWholeTreeAndKeepsOutput() throws Exception {
        // sh 起一个后台 sleep 并把它的进程号写下来：超时后连这个孙子进程也不能留着
        ScriptedModel model = new ScriptedModel(
                say("", call("c1", "run_command", "command", "echo start; sleep 30 & echo $! > pid; wait", "timeout", 1)), say("ok"));
        long t0 = System.currentTimeMillis();
        String r = toolResults(agentIn(tmp, model).rules(ALLOW_COMMANDS).build().run("开始")).get(0);
        assertTrue(r.contains("已终止") && r.contains("start"), r);
        assertTrue(System.currentTimeMillis() - t0 < 10_000);
        assertProcessGone(Long.parseLong(Files.readString(tmp.resolve("pid")).strip()));
    }

    @Test
    void timeoutAlsoKillsABackgroundProcessThatLeftTheTree() throws Exception {
        // 括号里起的后台进程，父进程马上退出，它就不再挂在这棵进程树上了；只有按进程组杀才杀得到
        Assumptions.assumeTrue(Files.isExecutable(Path.of("/usr/bin/setsid")) || Files.isExecutable(Path.of("/bin/setsid")),
                "没有 setsid 的系统（macOS）上做不到这一点，README 里写了");
        ScriptedModel model = new ScriptedModel(
                say("", call("c1", "run_command", "command", "(sleep 30 & echo $! > pid); sleep 30", "timeout", 1)), say("ok"));
        agentIn(tmp, model).rules(ALLOW_COMMANDS).build().run("开始");
        assertProcessGone(Long.parseLong(Files.readString(tmp.resolve("pid")).strip()));
    }

    @Test
    void registryTimeoutAlsoKillsTheCommand() throws Exception {
        // 命令自己的超时设得很长，注册表那一层先到：它中断执行线程，执行器在被中断时负责杀进程
        ScriptedModel model = new ScriptedModel(
                say("", call("c1", "run_command", "command", "sleep 30 & echo $! > pid; wait", "timeout", 60)), say("ok"));
        Agent agent = agentIn(tmp, model).rules(ALLOW_COMMANDS).commandTimeout(-29).build();      // 注册表超时 = 命令默认超时 + 30 = 1 秒
        String r = toolResults(agent.run("开始")).get(0);
        assertTrue(r.contains("执行超过 1 秒，已中止"), r);
        assertProcessGone(Long.parseLong(Files.readString(tmp.resolve("pid")).strip()));
    }

    static void assertProcessGone(long pid) throws InterruptedException {
        for (int i = 0; i < 40; i++) {
            if (ProcessHandle.of(pid).map(h -> !h.isAlive()).orElse(true)) return;
            Thread.sleep(50);
        }
        throw new AssertionError("进程 " + pid + " 还活着");
    }

    @Test
    void sessionLogWrittenBeforeAndAfter() throws IOException {
        Path log = tmp.resolve("logs/s.jsonl");
        ScriptedModel model = new ScriptedModel(say("", call("c1", "run_command", "command", "echo hi")), say("ok"));
        agentIn(tmp, model).rules(ALLOW_COMMANDS).sessionFile(log).build().run("开始");
        List<String> kinds = Files.readAllLines(log).stream().map(l -> (String) Json.parseObject(l).get("type")).toList();
        assertTrue(kinds.contains("tool_start"));
        assertEquals("done", kinds.get(kinds.size() - 1));
        List<Message> loaded = Session.loadMessages(log);
        assertEquals(List.of("system", "user", "assistant", "tool", "assistant"), loaded.stream().map(m -> m.role).toList());
        assertEquals(Map.of("command", "echo hi"), loaded.get(2).toolCalls.get(0).arguments());
    }

    @Test
    void projectInstructionsReachSystemPrompt() throws IOException {
        Files.writeString(tmp.resolve("AGENT.md"), "- 运行测试：mvn -q test");
        Outcome o = agentIn(tmp, new ScriptedModel(say("ok"))).build().run("开始");
        assertTrue(o.messages().get(0).content.contains("mvn -q test"));
        assertTrue(o.messages().get(0).content.contains(tmp.toRealPath().toString()));
    }

    // --- 流式解析、JSON --------------------------------------------------
    @Test
    void streamParserJoinsToolCallFragments() {
        List<String> lines = List.of(
                "data: {\"choices\":[{\"delta\":{\"reasoning_content\":\"想一下\"}}]}",
                "data: {\"choices\":[{\"delta\":{\"content\":\"我来\"}}]}",
                "data: {\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"id\":\"a\",\"function\":{\"name\":\"read_file\",\"arguments\":\"{\\\"pa\"}}]}}]}",
                "data: {\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"function\":{\"arguments\":\"th\\\": \\\"x.py\\\"}\"}}]}}]}",
                "data: {\"choices\":[],\"usage\":{\"prompt_tokens\":7,\"completion_tokens\":3}}",
                "data: [DONE]");
        List<String> text = new ArrayList<>(), parts = new ArrayList<>();
        ModelClient.Reply reply = StreamParser.parse(lines, new ModelClient.Listener() {
            @Override
            public void onText(String t) { text.add(t); }

            @Override
            public void onToolDelta(int index, String name, String part) { parts.add(index + ":" + name + ":" + part); }
        });
        Message m = reply.message();
        assertEquals("我来", m.content);
        assertEquals(List.of("我来"), text);
        assertEquals("想一下", m.reasoning);
        assertEquals("想一下", m.toApi().get("reasoning_content"));
        assertFalse(Message.assistant("x").toApi().containsKey("reasoning_content"));
        assertEquals(Map.of("path", "x.py"), m.toolCalls.get(0).arguments());
        assertEquals(new Usage(7, 3), reply.usage());
        // 参数还在生成时，每一段原文都交出去（界面据此边写边显示）
        assertEquals(List.of("0:read_file:{\"pa", "0:read_file:th\": \"x.py\"}"), parts);
    }

    @Test
    void brokenToolArgumentsAreKeptRawAndExplainedToModel() {
        ModelClient.Reply reply = StreamParser.parse(List.of(
                "data: {\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"id\":\"a\",\"function\":{\"name\":\"read_file\",\"arguments\":\"{\\\"path\\\": \"}}]}}]}"),
                ModelClient.Listener.NONE);
        ScriptedModel model = new ScriptedModel(reply.message(), say("ok"));
        assertTrue(toolResults(agentIn(tmp, model).build().run("开始")).get(0).contains("不是合法的 JSON"));
    }

    @Test
    void jsonRoundTrip() {
        String text = "{\"a\":[1,2.5,true,null,\"中文\\n\\\"引号\\\" \\u4e2d\"],\"b\":{\"c\":-3}}";
        Map<String, Object> parsed = Json.parseObject(text);
        assertEquals(List.of(1L, 2.5, true, "中文\n\"引号\" 中"), Json.list(parsed.get("a")).stream().filter(x -> x != null).toList());
        assertEquals(parsed, Json.parse(Json.write(parsed)));
        assertEquals("{\"a\":1,\"b\":2}", Json.writeSorted(Map.of("b", 2, "a", 1)));
        assertEquals("[1795500849.063,0.5]", Json.write(List.of(1795500849.063, 0.5)));     // 大数不写成科学计数法
        // 比 long 大的整数不报错；夹到 int 范围时不绕回
        assertEquals(1.2345678901234567E19, Json.parse("12345678901234567890"));
        assertEquals(Integer.MAX_VALUE, Json.integer(Json.parse("4294967301"), 0));
        assertEquals("\uD83D\uDE00", Json.parse("\"\\ud83d\\ude00\""));
        assertThrows(Json.JsonException.class, () -> Json.parse("[".repeat(100_000)));      // 报错，而不是栈溢出
        for (String bad : List.of("{\"a\":}", "[1,", "{\"a\":1} x", "\"没结束", "{a:1}", "007", "+1", "\"\\u+041\"",
                "\"a\tb\"", "\u20281")) {
            assertThrows(Json.JsonException.class, () -> Json.parse(bad), bad);
        }
    }

    @Test
    void globMatchesLikeTheShell() {
        assertTrue(Glob.matches("mvn *", "mvn -q test"));
        assertTrue(Glob.matches("*.java", "src/main/Cart.java"));
        assertTrue(Glob.matches("git push*", "git push"));
        assertTrue(Glob.matches("file[0-9].txt", "file7.txt"));
        assertFalse(Glob.matches("file[!0-9].txt", "file7.txt"));
        assertFalse(Glob.matches("mvn *", "mvnw test"));
        assertFalse(Glob.matches("a.b", "axb"));
        // 集合里的特殊字符按字面算；写不成正则的模式只匹配它自己
        assertTrue(Glob.matches("[[]x", "[x"));
        assertTrue(Glob.matches("[!]]x", "ax"));
        assertFalse(Glob.matches("[!]]x", "]x"));
        assertTrue(Glob.matches("[a&&b]", "&"));
        assertTrue(Glob.matches("[\\^]", "^"));
        assertFalse(Glob.matches("[z-a]", "m"));
        assertTrue(Glob.matches("😀*", "😀.txt"));
        assertTrue(Glob.matches("?.txt", "😀.txt") || Glob.matches("??.txt", "😀.txt"));
    }

    // --- 上下文管理 -----------------------------------------------------
    static List<Message> history(int rounds) {
        List<Message> msgs = new ArrayList<>(List.of(Message.system("sys"), Message.user("修好测试，不要动测试文件")));
        for (int i = 0; i < rounds; i++) {
            msgs.add(say("", call("c" + i, "read_file", "path", "f" + i + ".java")));
            msgs.add(Message.tool("x".repeat(4000), "c" + i));
        }
        return msgs;
    }

    @Test
    void safeSplitNeverSeparatesCallAndResult() {
        List<Message> msgs = history(4);
        for (int target = 0; target < msgs.size(); target++) {
            int i = ContextManager.safeSplitPoint(msgs, target);
            if (i > 0) {
                assertFalse(msgs.get(i).role.equals("tool"));
                assertTrue(msgs.get(i - 1).toolCalls.isEmpty());
            }
        }
    }

    @Test
    void clearsOldToolResultsButKeepsCallRecordAndRecent() throws ModelException {
        List<Message> msgs = history(10);
        ContextManager cm = new ContextManager(10_000, 0.8, 4, null);
        cm.prepare(msgs);
        List<Message> tools = msgs.stream().filter(m -> m.role.equals("tool")).toList();
        assertTrue(tools.get(0).content.startsWith("[此处是 read_file(path=\"f0.java\")"));
        assertEquals("x".repeat(4000), tools.get(tools.size() - 1).content);
        assertEquals(10, msgs.stream().filter(m -> !m.toolCalls.isEmpty()).count());     // 调用记录都在
    }

    @Test
    void underThresholdUntouched() throws ModelException {
        List<Message> msgs = history(2);
        new ContextManager(100_000, null).prepare(msgs);
        assertTrue(msgs.stream().filter(m -> m.role.equals("tool")).allMatch(m -> m.content.length() == 4000));
    }

    @Test
    void compactionKeepsSystemRecentAndValidPairs() throws ModelException {
        List<Message> msgs = history(10);
        ContextManager cm = new ContextManager(4_000, 0.8, 4, new ScriptedModel(say("摘要：用户要求不要动测试文件")));
        cm.prepare(msgs);
        assertEquals("system", msgs.get(0).role);
        assertTrue(msgs.get(1).content.contains("不要动测试文件"));
        assertEquals(1, cm.compactions);
        Set<String> ids = new java.util.HashSet<>();
        msgs.forEach(m -> m.toolCalls.forEach(c -> ids.add(c.id())));
        assertTrue(msgs.stream().filter(m -> m.role.equals("tool")).allMatch(m -> ids.contains(m.toolCallId)));   // 没有落单的工具结果
        assertEquals("x".repeat(4000), msgs.get(msgs.size() - 1).content);
    }

    // --- 子任务 ---------------------------------------------------------
    @Test
    void subagentIsIsolatedReadOnlyAndReturnsOnlyConclusion() throws IOException {
        Files.writeString(tmp.resolve("A.java"), "class A { void calculateDiscount() {} }\n");
        ScriptedModel model = new ScriptedModel(
                say("", call("c1", "spawn_subagent", "task", "找到 calculateDiscount 定义在哪")),
                // 以下三条是子任务自己的对话
                say("", call("s1", "search_text", "pattern", "calculateDiscount")),
                say("", call("s2", "write_file", "path", "hack.txt", "content", "x")),
                say("结论：定义在 A.java:1"),
                say("好的，在 A.java"));
        Outcome o = agentIn(tmp, model).rules(List.of(Rule.allow("write_file", "*"))).build().run("主任务：别告诉子任务这句话");
        assertEquals("结论：定义在 A.java:1", toolResults(o).get(0));         // 主任务只拿到结论
        List<Message> subFirst = model.seen.get(1);
        assertEquals(2, subFirst.size());                                      // 子任务只看到自己的提示词和任务说明
        assertTrue(subFirst.stream().noneMatch(m -> m.content.contains("别告诉子任务")));
        List<Message> subThird = model.seen.get(3);
        assertTrue(subThird.get(subThird.size() - 1).content.contains("没有名为 write_file"));   // 子任务没有写工具
        assertFalse(Files.exists(tmp.resolve("hack.txt")));
    }
}
