package cn.agentjourney.agent;

import cn.agentjourney.agent.model.ModelClient;
import cn.agentjourney.agent.model.ModelException;
import cn.agentjourney.agent.model.OpenAICompatModel;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** 对着本机起的一个假接口测客户端：请求体长什么样、流式响应怎么读、各种状态码怎么分类。不联网。 */
class OpenAICompatModelTest {
    HttpServer server;
    final AtomicReference<String> requestBody = new AtomicReference<>();
    final AtomicReference<String> authorization = new AtomicReference<>();
    volatile int status = 200;
    volatile String response = "";

    @BeforeEach
    void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.setExecutor(java.util.concurrent.Executors.newVirtualThreadPerTaskExecutor());
        server.createContext("/chat/completions", exchange -> {
            requestBody.set(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            authorization.set(exchange.getRequestHeaders().getFirst("Authorization"));
            byte[] body = response.getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(status, body.length);
            exchange.getResponseBody().write(body);
            exchange.close();
        });
        server.start();
    }

    @AfterEach
    void stop() { server.stop(0); }

    OpenAICompatModel model() {
        return new OpenAICompatModel("http://127.0.0.1:" + server.getAddress().getPort() + "/", "test-key", "test-model",
                Duration.ofSeconds(5));
    }

    @Test
    void sendsMessagesAndToolsAndReadsTheStream() throws ModelException {
        response = """
                data: {"choices":[{"delta":{"content":"先看"}}]}

                data: {"choices":[{"delta":{"content":"文件"}}]}

                data: {"choices":[{"delta":{"tool_calls":[{"index":0,"id":"call_9","function":{"name":"read_file","arguments":"{\\"path\\":"}}]}}]}

                data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\\"Cart.java\\"}"}}]}}]}

                data: {"choices":[],"usage":{"prompt_tokens":12,"completion_tokens":4}}

                data: [DONE]
                """;
        StringBuilder streamed = new StringBuilder();
        List<Map<String, Object>> tools = List.of(Map.of("type", "function", "function", Map.of("name", "read_file")));
        ModelClient.Reply reply = model().chat(
                List.of(Message.system("你是助手"), Message.user("看看 Cart.java"),
                        Message.assistant("", new ToolCall("call_1", "find_files", Map.of("pattern", "*.java"))),
                        Message.tool("Cart.java", "call_1")),
                tools, new ModelClient.Listener() {
                    @Override
                    public void onText(String text) { streamed.append(text); }
                });

        assertEquals("先看文件", reply.message().content);
        assertEquals("先看文件", streamed.toString());
        assertEquals(new ToolCall("call_9", "read_file", Map.of("path", "Cart.java")), reply.message().toolCalls.get(0));
        assertEquals(new Usage(12, 4), reply.usage());

        assertEquals("Bearer test-key", authorization.get());
        Map<String, Object> sent = Json.parseObject(requestBody.get());
        assertEquals("test-model", sent.get("model"));
        assertEquals(true, sent.get("stream"));
        List<Object> messages = Json.list(sent.get("messages"));
        assertEquals(4, messages.size());
        Map<String, Object> call = Json.obj(Json.list(Json.obj(messages.get(2)).get("tool_calls")).get(0));
        assertEquals("{\"pattern\":\"*.java\"}", Json.obj(call.get("function")).get("arguments"));   // 参数按接口要求是一段 JSON 文本
        assertEquals("call_1", Json.obj(messages.get(3)).get("tool_call_id"));
        assertEquals(1, Json.list(sent.get("tools")).size());
    }

    @Test
    void onlyRateLimitAndServerErrorsAreRetryable() {
        response = "{\"error\":{\"message\":\"余额不足\"}}";
        status = 402;
        ModelException e = assertThrows(ModelException.class, () -> model().chat(List.of(Message.user("hi")), List.of(), ModelClient.Listener.NONE));
        assertFalse(e.retryable);
        assertTrue(e.getMessage().contains("402") && e.getMessage().contains("余额不足"));
        for (int code : new int[]{429, 500, 503}) {
            status = code;
            assertTrue(assertThrows(ModelException.class,
                    () -> model().chat(List.of(Message.user("hi")), List.of(), ModelClient.Listener.NONE)).retryable, "" + code);
        }
    }

    @Test
    void streamThatGoesQuietTimesOutInsteadOfHangingForever() {
        // 发完响应头和第一段就不再说话：客户端应该在时限附近放弃，并且算可重试
        server.createContext("/stall/chat/completions", exchange -> {
            exchange.getRequestBody().readAllBytes();
            exchange.sendResponseHeaders(200, 0);
            exchange.getResponseBody().write("data: {\"choices\":[{\"delta\":{\"content\":\"先\"}}]}\n\n".getBytes(StandardCharsets.UTF_8));
            exchange.getResponseBody().flush();
            try {
                Thread.sleep(6000);
            } catch (InterruptedException ignored) {
                // 测试结束
            }
            exchange.close();
        });
        OpenAICompatModel slow = new OpenAICompatModel("http://127.0.0.1:" + server.getAddress().getPort() + "/stall", "k", "m",
                Duration.ofSeconds(1));
        long t0 = System.currentTimeMillis();
        ModelException e = assertThrows(ModelException.class,
                () -> slow.chat(List.of(Message.user("hi")), List.of(), ModelClient.Listener.NONE));
        assertTrue(e.retryable);
        assertTrue(e.getMessage().contains("没有返回新内容"), e.getMessage());
        assertTrue(System.currentTimeMillis() - t0 < 4000);
    }

    @Test
    void connectionFailureIsRetryable() {
        int port = server.getAddress().getPort();
        server.stop(0);
        OpenAICompatModel dead = new OpenAICompatModel("http://127.0.0.1:" + port, "k", "m", Duration.ofSeconds(2));
        assertTrue(assertThrows(ModelException.class,
                () -> dead.chat(List.of(Message.user("hi")), List.of(), ModelClient.Listener.NONE)).retryable);
    }
}
