import java.util.List;

/** 不依赖测试框架的小测试：javac -d out *.java && java -cp out CartTest */
public final class CartTest {
    static int failed = 0;

    static void check(String name, long expected, long actual) {
        if (expected == actual) {
            System.out.println("PASS " + name);
        } else {
            failed++;
            System.out.println("FAIL " + name + "：期望 " + expected + "，实际 " + actual);
        }
    }

    public static void main(String[] args) {
        List<Cart.Item> items = List.of(new Cart.Item("键盘", 19900, 2), new Cart.Item("鼠标垫", 2500, 1));
        check("一行商品的小计", 39800, Cart.lineTotal(items.get(0)));
        check("不打折的总价要乘上数量", 42300, Cart.total(items, 0));
        check("打九折", 38070, Cart.total(items, 10));
        System.out.println(failed == 0 ? "全部通过" : failed + " 条没通过");
        System.exit(failed == 0 ? 0 : 1);
    }
}
