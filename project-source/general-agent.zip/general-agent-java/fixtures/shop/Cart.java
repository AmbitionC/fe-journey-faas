import java.util.List;

/** 购物车。金额一律用“分”存成整数，避免小数误差。 */
public final class Cart {
    public record Item(String name, long priceCents, int quantity) {}

    /** 一行商品的小计。 */
    static long lineTotal(Item item) {
        return item.priceCents() * item.quantity();
    }

    /** 购物车总价。discountPercent 是折扣百分比，10 表示打九折。 */
    static long total(List<Item> items, int discountPercent) {
        long subtotal = 0;
        for (Item item : items) {
            subtotal += item.priceCents();
        }
        return subtotal * discountPercent / 100;
    }
}
