# 从零手写通用 Agent（Java 版）

`general-agent/` 是 Python 写的。这个目录用 Java 21 把其中的**编程模式**重写了一遍：同样的执行循环、权限闸门、上下文管理、子任务调度、六个编程工具和终端，行为和 Python 版对齐，写给模型看的报错文案也基本一致。运行时不依赖任何第三方库，JSON 读写、HTTP、并发都只用 JDK 自带的；JUnit 只在测试时用。

没有移植的部分：研究模式、长期记忆和它的离线整理、技能、MCP 客户端、钩子、自定义斜杠命令、本地网页工作台、评测运行器、线上试用服务。这些在 Python 版里都是内核外面加的一层，想练手可以照着 Python 版自己接。

## 运行

需要 JDK 21 和 Maven，系统要有 `sh`（macOS、Linux 或 WSL）。

```bash
mvn -q package            # 编译并跑完全部测试，产物在 target/general-agent-0.1.0.jar

export OPENAI_BASE_URL=https://api.deepseek.com   # 任何 OpenAI 兼容接口
export OPENAI_API_KEY=你的密钥
export LLM_MODEL=deepseek-chat

# 在自带的示例仓库里试：一个购物车，两条测试是挂的
cd fixtures/shop
java -jar ../../target/general-agent-0.1.0.jar                             # 交互模式
java -jar ../../target/general-agent-0.1.0.jar -p "有测试挂了，帮我修好"      # 无界面模式
```

交互模式里：

```
> 有测试挂了，帮我修好
> /plan 把金额改成用 BigDecimal 表示      # 先只读地看代码、交出计划；你同意后才动手
> /help
```

- 需要确认的操作会在终端里问你：`y` 同意这一次，`a` 本会话同类不再问，`n` 拒绝并可以补一句话告诉模型为什么。
- 无界面模式没法问，需要确认的操作一律视为拒绝。示例仓库的 `.agent/rules.json` 已经放行了改 `Cart.java` 和跑 `javac`、`java`，所以上面那条命令能直接跑完。自己的项目里用 `--allow 'mvn *'` 放行命令，或者写一份 `.agent/rules.json`。
- 项目根目录的 `AGENT.md` 会拼进系统提示词，适合写「测试怎么跑」「哪些文件不要动」。
- 每次运行的完整记录在项目目录的 `.agent/sessions/*.jsonl`，一行一条消息或过程事件。

## 测试

```bash
mvn test
```

46 条测试，用脚本化的假模型驱动，不联网、不花钱。模型客户端对着测试里起的一个本机假接口测。

## 源码结构

包名 `cn.agentjourney.agent`，源码在 `src/main/java/cn/agentjourney/agent/`，约 2500 行。

| 文件 | 是什么 | Python 版对应 |
|---|---|---|
| `kernel/Agent.java` | 执行循环：调模型、过权限、执行工具、追加结果；重试、轮次上限、重复调用检测、中断 | `agent/kernel/loop.py` |
| `kernel/PermissionGate.java`、`kernel/Commands.java` | 权限闸门和命令的静态分析：拆段、重定向目标、内置拒绝、计划模式 | `agent/kernel/permission.py` |
| `kernel/ContextManager.java` | 清理旧的工具结果、把早期对话压缩成摘要 | `agent/kernel/context.py` |
| `kernel/SubagentScheduler.java` | 只读子任务：独立上下文、限并发、限深度 | `agent/kernel/subagent.py` |
| `tools/ToolRegistry.java` | 工具注册表：校验参数、带超时执行、截断结果 | `agent/tools/registry.py` |
| `tools/Workspace.java`、`tools/FileTools.java`、`tools/ShellTool.java`、`tools/Glob.java` | 路径边界和「先读后改」，读、写、改、找、搜、跑命令 | `agent/tools/coding/` |
| `model/` | 模型接口、OpenAI 兼容的流式客户端、流式响应解析、测试用的脚本模型 | `agent/model.py` |
| `Message.java`、`ToolCall.java`、`Tool.java`、`Usage.java`、`Event.java` | 全系统流转的几种数据 | `agent/types.py` |
| `state/Session.java` | 会话记录 | `agent/state/session.py` |
| `CodingAgent.java` | 把各部件装配成一个可运行的 Agent | `agent/build.py`、`agent/prompts.py` |
| `cli/Main.java` | 终端：交互模式、无界面模式、计划模式 | `agent/cli.py` |
| `Json.java` | JSON 读写 | Python 标准库的 `json` |

## 和 Python 版不一样的地方

前六条是语言不同带来的设计差别，面试里被问到「为什么这么写」时可以直接讲。后面是行为上的小出入。

- **并发用虚拟线程，不用 async。** Python 版整条链路是 `async`，并行靠 `asyncio.gather`。Java 版的代码全是普通的阻塞调用：只读工具并行时，每个调用提交到 `newVirtualThreadPerTaskExecutor`，再按提交顺序取结果，所以结果顺序和调用顺序一致。虚拟线程便宜，一次并行十几个调用不用考虑线程池开多大；等模型响应这类网络阻塞会让出底下的平台线程。要知道的限制：在 JDK 21 上，读写文件和 `synchronized` 块里的阻塞仍然会占住平台线程（JEP 444），这里量很小，可以接受。
- **工具超时靠 `Future.get(timeout)` 加中断。** 超时后取消任务会中断执行它的线程。命令执行器在被中断时负责杀掉子进程；纯计算的工具不响应中断，模型会立刻收到「已中止」，但那段计算要自己跑完。
- **杀进程树要绕一下。** Python 版用 `start_new_session` 让命令自成一个进程组，超时整组杀掉。Java 没有这个接口：系统里有 `setsid`（Linux、WSL）时用它起命令，再按进程组杀；没有（macOS）时只能杀当时还挂在进程树上的子孙进程，已经脱离出去的后台进程杀不到。
- **流式读取的超时要自己做。** `HttpRequest.timeout` 只管到收到响应头。之后每收到一行记一次时间，一个看门狗线程发现太久没有新内容就把流关掉，读取随即报错并按可重试处理。
- **工具的参数表是手写的。** Python 版用装饰器从函数签名和文档字符串生成 JSON Schema；Java 版用 `Tool.named(...).required(...).optional(...).run(...)` 几行链式调用写出来，少了反射，多了几行声明。
- **JSON 自己写，路径自己解析。** JDK 没有自带的 JSON 库，`Json.java` 是一个递归下降解析器加输出器，整数读成 `Long`。`Path.toRealPath()` 遇到不存在的路径会抛异常，而新建文件时路径本来就不存在，所以 `Workspace.resolve` 自己一段一段地走：遇到符号链接换成它指向的位置（指向不存在的目标也照样展开），遇到 `..` 退到真实位置的上一级，最后才判断是否在项目目录之内。

行为上的小出入：

- 交互模式里 Ctrl+C 直接退出进程。`Agent.interrupt()` 这个能力在（当前这一步做完后停下，记录保持完整），但终端没有把 Ctrl+C 接到它上面。
- `search_text` 用的是 Java 的正则语法，Python 特有的写法（如 `(?P<name>…)`）不认。
- 文件不存在时提示的「名称相近的文件」按编辑距离算，和 Python 版 difflib 给出的可能不同。
- 遍历文件时多忽略 `target` 和 `out` 两个目录。
- 被信号杀掉的命令，退出码显示成 137 这样的正数，Python 版显示 -9。
- 模型返回的流里有一段不是合法 JSON 时，Java 版按可重试的接口错误处理。
- `.agent/rules.json` 里 `decision` 不是 `allow` 或 `deny` 的规则会被忽略并打印一行提示。
- 终端的输出编码跟随系统。中文显示成问号时，启动时加 `-Dstdout.encoding=UTF-8`。
