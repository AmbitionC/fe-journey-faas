import asyncio
import json
from pathlib import Path

import pytest

from growth.lead import ROOT, Campaign, Config
from growth.llm import Ledger, Models
from growth.offline import POINTS, OfflineModel
from growth.sim.check import fixture
from growth.store import Store
from growth.types import Product


def run(coro):
    return asyncio.run(coro)


@pytest.fixture
def product() -> Product:
    data = json.loads((ROOT / "data" / "products" / "sunscreen.json").read_text())
    data.pop("note")
    return Product(**data)


@pytest.fixture
def sim() -> dict:
    return json.loads((ROOT / "data" / "sim" / "sim-v1.json").read_text())


@pytest.fixture
def points_segments():
    return fixture()


def offline_models(**ledger) -> Models:
    return Models(OfflineModel(), ledger=Ledger(**ledger), rpm=600000, max_concurrency=64)


def make_campaign(product, sim, path=":memory:", models=None, **cfg) -> Campaign:
    store = Store(path)
    if store.product() is None:
        store.save_product(product)
    defaults = dict(budget=1200, round_budget=400, max_rounds=3, per_segment=3, sim={**sim, "users": 400})
    return Campaign(store, models or offline_models(), Config(**{**defaults, **cfg}))
