"""对照实验：一个上下文 + Skill 的跑法。离线替身不看上下文，所以这里只验证接线和计量。"""
from conftest import offline_models, run

from growth.lead import Config
from growth.llm import Ledger, Models
from growth.offline import OfflineModel
from growth.single import SingleModels, Thread, render, run_one


def test_thread_loads_each_skill_once_and_folds_oldest_steps():
    t = Thread(max_chars=400)
    first = t.render("review", "审核细则" * 10, "审第一版")
    assert first.count("审核细则" * 10) == 1 and "用 Skill「review-1」完成" in first
    for i in range(12):
        t.steps.append(("review", f"审第 {i} 版", "通过" * 20))
    text = t.render("review", "审核细则" * 10, "审最后一版")
    assert list(t.skills) == ["review-1"]                     # 同一段提示词不会重复加载
    assert t.folded > 0 and f"更早的 {t.folded} 步已折叠" in text and len(text) <= 400
    assert "审第 11 版" in text and "审第 0 版" not in text    # 折叠的是最早的步骤
    t.render("review", "另一段提示词", "x")
    assert list(t.skills) == ["review-1", "review-2"]


def test_both_modes_finish_and_single_context_reads_far_more(product, sim):
    def make(cls, on_call):
        return cls(OfflineModel(), ledger=Ledger(), rpm=600000, max_concurrency=64, on_call=on_call)

    cfg = lambda: Config(budget=800, round_budget=400, max_rounds=2, per_segment=2, sim={**sim, "users": 300})  # noqa: E731
    multi = run(run_one("multi", product, cfg(), make, offline_models))
    single = run(run_one("single", product, cfg(), make, offline_models))
    assert multi["rounds"] == single["rounds"] == 2
    assert multi["calls"] == single["calls"] > 20             # 离线替身两边做的事一样
    assert single["chars_in"] > 10 * multi["chars_in"]        # 一条对话每次都要重读前面的内容
    assert single["peak"] > multi["peak"]
    assert multi["approved"] > 0 and multi["recheck_blocked"] == 0
    table = render([multi, single])
    assert "独立复查拦下的版数" in table and "输入 token" not in table      # 离线没有 token 数，不显示这一行


def test_simulated_users_stay_outside_the_thread():
    models = SingleModels(OfflineModel(), ledger=Ledger())
    assert type(models.stage("sim")).__name__ == "StageModel"
    assert models.stage("review").thread is models.stage("creative").thread
    assert isinstance(models, Models)
