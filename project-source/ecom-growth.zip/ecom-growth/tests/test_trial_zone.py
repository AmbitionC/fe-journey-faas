"""试投区：模拟用户池、试投环境、预算分配、归因、进化。"""
import json
import random

from growth.lead import ROOT
from growth.llm import ScriptedModel
from growth.offline import OfflineModel
from growth.sim.check import run_checks
from growth.sim.trial import SimEnv, click_prob, order_prob, pick_users
from growth.sim.users import behavior_features, build_pool, kmeans, scoring_view
from growth.stages import allocate, attribute, evolve
from growth.stats import interval
from growth.store import Store
from growth.types import Creative, Finding, Impression, Relevance, SimUser

from conftest import offline_models, run

FEATS = behavior_features(ROOT / "data" / "behavior_sample.csv")


def pool(points_segments, sim):
    points, segments = points_segments
    return build_pool(segments, points, FEATS, sim)


def test_behavior_features_and_clusters():
    f = next(iter(FEATS.values()))
    assert {"pv", "buy_per_pv", "hesitation", "focus", "night_share", "buy_per_pv_scaled"} <= set(f)
    assert abs(sum(x["buy_per_pv"] for x in FEATS.values()) / len(FEATS)) > 0
    labels, score = kmeans(FEATS, 4)
    assert len(set(labels.values())) == 4 and score > 0.2


def test_pool_is_reproducible_and_keeps_real_and_synthetic_fields_apart(points_segments, sim):
    a, b = pool(points_segments, sim), pool(points_segments, sim)
    assert [u.__dict__ for u in a] == [u.__dict__ for u in b]
    assert all(u.behavior in FEATS.values() for u in a)                 # 行为特征整组取自行为数据里的某个用户
    bystanders = [u for u in a if u.segment_id is None]
    assert 0.08 < len(bystanders) / len(a) < 0.25 and all(not u.hidden for u in bystanders)
    assert 0.1 < sum(u.holdout for u in a) / len(a) < 0.3


def test_hidden_attributes_reach_the_scorer_but_not_the_segment_definition(points_segments, sim):
    _, segments = points_segments
    users = pool(points_segments, sim)
    u = next(u for u in users if "担心假白" in u.hidden)
    assert "假白" in scoring_view(u) and "购物习惯" not in scoring_view(u) and "购物习惯" in u.persona
    assert not any("假白" in json.dumps(s.__dict__, ensure_ascii=False) for s in segments)


def test_click_model_follows_the_stated_formula(sim):
    user = SimUser(1, 1, {"buy_per_pv_scaled": 1.0}, 0.0, 0.0, [])
    p = lambda m, c, a: click_prob(Relevance(m, c, a), user, sim["base_ctr"], sim["coef"])  # noqa: E731
    assert abs(p(0, 0, 0) - sim["base_ctr"]) < 1e-9                      # 完全不相关时就是基准点击率
    assert p(2, 0, 0) > p(1, 0, 0) > p(0, 0, 0) > p(0, 0, 1) and p(2, 0, 0) > p(0, 2, 0)
    frugal = SimUser(2, 1, {"buy_per_pv_scaled": 0.2}, 1.0, 0.0, [])
    assert order_prob(Relevance(2, 2, 0), user, sim["base_cvr"]) > order_prob(Relevance(2, 2, 0), frugal, sim["base_cvr"])


def test_scores_are_cached_by_content_and_results_are_deterministic(points_segments, sim):
    users = [u for u in pool(points_segments, sim) if u.segment_id == 2][:60]
    store, models = Store(), offline_models()
    env = SimEnv(models.stage("sim"), sim, cache=store, ledger=models.ledger)
    c = Creative(7, 2, [2], "成分", "理性", "不含酒精、不含香精，翻成分表就能确认。")
    first = run(env.expose(1, c, users))
    calls = len(models.ledger.calls)
    assert 0 < calls < len(users) / 4                                    # 描述相同的用户共用一次打分，并且按批问
    again = run(SimEnv(models.stage("sim"), sim, cache=store, ledger=models.ledger).expose(1, c, users))
    assert again == first and len(models.ledger.calls) == calls          # 换一个进程（新的环境对象）也不重打
    twin = Creative(99, 2, [2], "成分", "理性", c.body)                  # 内容相同的另一版：打分命中缓存，抽样各自独立
    run(env.expose(1, twin, users))
    assert len(models.ledger.calls) == calls


def test_adding_a_creative_does_not_change_other_creatives_results(points_segments, sim):
    users = [u for u in pool(points_segments, sim) if u.segment_id == 1][:80]
    env = SimEnv(OfflineModel(), sim)
    a = Creative(1, 1, [1], "场景", "理性", "上班路上十分钟，推开就成膜。")
    before = run(env.expose(2, a, users))
    run(env.expose(2, Creative(2, 1, [7], "场景", "理性", "50ml 便携装，放包里刚好。"), users))
    assert run(env.expose(2, a, users)) == before


def test_pick_users_never_touches_holdout_and_skips_seen(points_segments, sim):
    users = pool(points_segments, sim)
    picked = pick_users(users, 1, 5, 1, 50, set(), sim["seed"], sim["bystander_share"])
    assert len(picked) == 50 and not any(u.holdout for u in picked)
    assert {u.segment_id for u in picked} == {1, None}                   # 定向不完美：混入少量路人
    assert picked == pick_users(users, 1, 5, 1, 50, set(), sim["seed"], sim["bystander_share"])
    more = pick_users(users, 1, 5, 1, 50, {u.id for u in picked}, sim["seed"], sim["bystander_share"])
    assert not {u.id for u in more} & {u.id for u in picked}


def test_environment_passes_its_own_sanity_checks(sim):
    rows = run(run_checks(offline_models(), sim))
    assert [r["name"] for r in rows] == ["无关素材", "违背顾虑的素材", "对症素材", "重复运行"] and all(r["ok"] for r in rows)


# ---- 预算分配 ----
def test_floor_gives_every_arm_a_chance_and_caps_bound_each_segment():
    arms = [allocate.Arm(i, 1 if i < 3 else 2) for i in range(6)]
    alloc = allocate.ThompsonAllocator(arms)
    alloc.update(0, 60, 200)                                             # 一个明显领先的选项
    plan = alloc.allocate(1000, random.Random(0), caps={1: 400, 2: 1000})
    assert all(plan[a.key] >= 30 for a in arms)                          # 保底 3%
    assert sum(plan[k] for k in (0, 1, 2)) == 400                        # 人群 1 的上限用完，预算流向人群 2
    assert sum(plan.values()) == 1000
    assert alloc.allocate(100, random.Random(0), arm_caps={k: 5 for k in range(6)}).total() == 30


def test_thompson_concentrates_on_the_true_best_over_rounds():
    rates, rng = [0.03, 0.05, 0.12], random.Random(1)
    alloc = allocate.ThompsonAllocator([allocate.Arm(i, 0) for i in range(3)])
    for _ in range(8):
        for k, n in alloc.allocate(300, rng).items():
            alloc.update(k, sum(rng.random() < rates[k] for _ in range(n)), n)
    last = alloc.allocate(300, rng)
    assert last[2] > 200 and alloc.prob_best_by_segment(rng)[0][2] > 0.9


def test_child_inherits_a_discounted_prior_from_its_parent():
    alloc = allocate.ThompsonAllocator([allocate.Arm(1, 0), allocate.Arm(2, 0)], inherited={2: (30 * 0.3, 170 * 0.3)})
    assert alloc.stats[1] == [1.0, 19.0] and alloc.stats[2] == [10.0, 70.0]


def test_bench_shows_uniform_wastes_the_most():
    out = allocate.bench([0.03, 0.04, 0.05, 0.06, 0.08, 0.05, 0.04, 0.07], repeats=15)
    assert out["平均分配"]["regret"] > out["汤普森采样"]["regret"] * 1.4
    assert out["汤普森采样"]["correct"] >= out["平均分配"]["correct"]


# ---- 归因 ----
def imps(creative_id, segment_id, n, clicks, orders=0, round=1, feedback=""):
    return [Impression(round, creative_id, segment_id, creative_id * 10000 + i, i < clicks, i < orders, feedback) for i in range(n)]


class Quiet:
    async def ask(self, system, user, *, data=None):
        return '{"click_reasons": [], "skip_reasons": [], "unaddressed": []}' if data["task"] == "attribute.feedback" else "否"


def test_summary_carries_intervals(points_segments):
    s = attribute.summarize(imps(1, 1, 30, 3) + imps(2, 1, 600, 48))
    assert s[1]["ctr"] > s[2]["ctr"] and s[1]["ctr_hi"] - s[1]["ctr_lo"] > 3 * (s[2]["ctr_hi"] - s[2]["ctr_lo"])
    assert s[1]["ctr_lo"] < s[2]["ctr"] < s[1]["ctr_hi"]        # 30 次曝光点了 3 次，不足以说它比另一版好


def test_attribution_is_done_per_segment_not_on_pooled_totals():
    """合起来看场景角度最好，分人群看每一类里它都不是最好的：因为场景素材更多地投给了本来就爱点的人群。"""
    cs = [Creative(1, 1, [1], "场景", "理性", "a"), Creative(2, 1, [1], "成分", "理性", "b"),
          Creative(3, 2, [1], "场景", "理性", "c"), Creative(4, 2, [1], "成分", "理性", "d")]
    log = imps(1, 1, 900, 180) + imps(2, 1, 100, 25) + imps(3, 2, 100, 3) + imps(4, 2, 900, 45)
    pooled = {"场景": (180 + 3) / 1000, "成分": (25 + 45) / 1000}
    assert pooled["场景"] > pooled["成分"]
    for seg in (1, 2):
        rows = attribute.attribute_effect(log, cs, "angle", seg)
        assert rows[0]["value"] == "成分"


def test_confidence_follows_explicit_rules(points_segments):
    points, segments = points_segments
    seg = [segments[0]]
    cs = [Creative(1, 1, [1], "成分", "理性", "a"), Creative(2, 1, [7], "成分", "亲切", "b"),
          Creative(3, 1, [1], "场景", "亲切", "c"), Creative(4, 1, [7], "场景", "理性", "d")]
    log = imps(1, 1, 300, 60) + imps(2, 1, 300, 57) + imps(3, 1, 300, 12) + imps(4, 1, 300, 15)
    out = run(attribute.attribute(Quiet(), 1, seg, cs, points, log))
    by = {f.statement: f for f in out["findings"]}
    angle = by["角度「成分」优于「场景」"]
    assert angle.kind == "works" and angle.confidence == "medium" and angle.support["creatives"] == 4   # 没有反馈佐证，到不了高
    assert by["语气的影响：区间重叠"].kind == "inconclusive" and by["卖点的影响：区间重叠"].kind == "inconclusive"


def test_bound_attributes_are_flagged_and_capped_at_low(points_segments):
    points, segments = points_segments
    cs = [Creative(1, 1, [1], "成分", "理性", "a"), Creative(2, 1, [1], "成分", "亲切", "b"),
          Creative(3, 1, [7], "场景", "理性", "c"), Creative(4, 1, [7], "场景", "亲切", "d")]
    log = imps(1, 1, 300, 60) + imps(2, 1, 300, 57) + imps(3, 1, 300, 12) + imps(4, 1, 300, 15)
    out = run(attribute.attribute(Quiet(), 1, [segments[0]], cs, points, log))
    angle = next(f for f in out["findings"] if f.statement.startswith("角度"))
    assert "无法区分" in angle.statement and "卖点「成膜快不黏腻」" in angle.statement and angle.confidence == "low"


def test_dead_segment_and_unaddressed_concern_become_findings(points_segments):
    points, segments = points_segments
    cs = [Creative(i, 3, [1], a, "理性", "x") for i, a in ((1, "成分"), (2, "场景"))]
    log = imps(1, 3, 200, 9, feedback="不知道会不会假白") + imps(2, 3, 200, 11, feedback="没说到我关心的点")
    out = run(attribute.attribute(OfflineModel(), 1, [segments[2]], cs, points, log))
    kinds = {f.kind: f for f in out["findings"]}
    assert "接近基准" in kinds["fails"].statement and kinds["fails"].confidence == "high"
    assert kinds["unaddressed"].statement == "担心涂了会假白" and kinds["unaddressed"].support["count"] == 200
    assert kinds["unaddressed"].quotes == ["不知道会不会假白"]
    text = attribute.render(1, [segments[2]], out, "sim-v1")
    assert "模拟环境 sim-v1" in text and "未回应" in text and "无效" in text


def test_feedback_counts_come_from_the_log_not_from_the_model(points_segments):
    _, segments = points_segments
    model = ScriptedModel(['{"click_reasons": [{"reason": "成分干净", "count": 999, "quotes": ["看到不含酒精才点的", "这句是编的"]}]}'])
    log = imps(1, 2, 12, 12, feedback="看到不含酒精才点的")
    out = run(attribute.summarize_feedback(model, segments[1], log))
    assert out["click_reasons"] == [{"reason": "成分干净", "count": 12, "quotes": ["看到不含酒精才点的"]}]


def test_clickbait_needs_high_ctr_and_low_conversion_after_click():
    cs = [Creative(i, 1, [1], "成分", "理性", "x") for i in (1, 2, 3, 4)]
    s = attribute.summarize(imps(1, 1, 400, 40, 8) + imps(2, 1, 400, 36, 7) + imps(3, 1, 400, 44, 9) + imps(4, 1, 400, 90, 3))
    assert attribute.clickbait(s, cs, 1) == [4]
    thin = attribute.summarize(imps(1, 1, 40, 4, 1) + imps(2, 1, 40, 4, 1) + imps(3, 1, 40, 4, 1) + imps(4, 1, 40, 10, 0))
    assert attribute.clickbait(thin, cs, 1) == []                        # 点击数太少的不判


# ---- 进化 ----
def test_retire_needs_both_enough_impressions_and_hopeless_odds():
    cs = [Creative(i, 1, [1], a, "理性", "x", status="approved") for i, a in ((1, "成分"), (2, "场景"), (3, "痛点"), (4, "口碑"))]
    summary = {1: {"n": 500}, 2: {"n": 300}, 3: {"n": 40}, 4: {"n": 300}}
    probs = {1: {1: 0.97, 2: 0.01, 3: 0.0, 4: 0.02}}
    assert evolve.to_retire(summary, probs, cs) == [2]                   # 3 曝光不足，可能只是运气不好；4 没到门槛


def test_retire_keeps_two_per_segment_and_drops_confirmed_clickbait():
    cs = [Creative(i, 1, [1], a, "理性", "x", status="approved") for i, a in ((1, "成分"), (2, "场景"), (3, "痛点"))]
    summary = {i: {"n": 500} for i in (1, 2, 3)}
    assert evolve.to_retire(summary, {1: {1: 1.0, 2: 0.0, 3: 0.0}}, cs) == [2]
    assert evolve.to_retire(summary, {1: {1: 0.5, 2: 0.3, 3: 0.2}}, cs, confirmed_bait={1}) == [1]


def rewrite_with(reply, points_segments, findings=()):
    points, segments = points_segments
    parent = Creative(4, 1, [1], "场景", "亲切", "上班路上十分钟，推开就成膜，放心用。", status="approved")
    perf = {"ctr": 0.08, "ctr_lo": 0.05, "ctr_hi": 0.12}
    model = ScriptedModel(reply if callable(reply) else [reply] * 2)
    out = run(evolve.rewrite(model, segments[0], parent, perf, list(findings), {}, ["改语气：亲切 → 俏皮"], points, 2))
    return out, model


def test_rewrite_changes_exactly_one_tag_and_records_lineage(points_segments):
    reply = json.dumps({"diagnosis": "没提便携", "changed": "selling_points", "selling_point_ids": [1, 7], "angle": "场景",
                        "tone": "亲切", "body": "上班路上十分钟，推开成膜，50ml 放包里。"}, ensure_ascii=False)
    (child, diagnosis), model = rewrite_with(reply, points_segments)
    assert child.parent_id == 4 and child.round == 2 and child.selling_point_ids == [1, 7] and child.status == "draft"
    assert child.note.startswith("改卖点：成膜快不黏腻 → 成膜快不黏腻、50ml 便携装") and diagnosis == "没提便携"
    assert "改语气：亲切 → 俏皮" in model.calls[0][1]                     # 失败过的改法带给模型


def test_rewrite_that_changes_two_things_is_sent_back_then_dropped(points_segments):
    reply = json.dumps({"diagnosis": "", "selling_point_ids": [7], "angle": "成分", "tone": "亲切", "body": "50ml 便携"}, ensure_ascii=False)
    (child, why), model = rewrite_with(reply, points_segments)
    assert child is None and "放弃" in why and len(model.calls) == 2 and "只能改一项" in model.calls[1][1]


def test_rewrite_only_sees_confident_findings_and_cannot_use_points_off_the_list(points_segments):
    findings = [Finding(1, "works", "角度「成分」优于「场景」", {}, "high"), Finding(1, "works", "语气猜测", {}, "low"),
                Finding(1, "inconclusive", "卖点的影响：区间重叠", {}, "low")]
    reply = json.dumps({"diagnosis": "", "selling_point_ids": [1, 99], "angle": "成分", "tone": "亲切", "body": "成分表可查，推开成膜"}, ensure_ascii=False)
    (child, _), model = rewrite_with(reply, points_segments, findings)
    assert "角度「成分」优于「场景」" in model.calls[0][1] and "语气猜测" not in model.calls[0][1] and "区间重叠" not in model.calls[0][1]
    assert child.selling_point_ids == [1] and child.angle == "成分"       # 清单外的编号被去掉后，只剩角度这一处改动


def test_gap_without_a_matching_point_returns_none(points_segments):
    points, _ = points_segments
    assert run(evolve.find_answer(OfflineModel(), Finding(1, "unaddressed", "担心涂了会假白"), points)) is None
    assert run(evolve.find_answer(OfflineModel(), Finding(1, "unaddressed", "嫌还要专门卸妆麻烦"), points)).text == "洗面奶可卸"
    assert run(evolve.find_answer(ScriptedModel(['{"selling_point_id": 99}']), Finding(1, "unaddressed", "x"), points)) is None
