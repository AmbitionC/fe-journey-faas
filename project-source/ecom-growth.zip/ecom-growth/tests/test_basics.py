import asyncio
import random

import pytest

from growth.llm import (BudgetExceeded, Call, GiveUp, Ledger, Models, RateLimitedPool, RateLimitError, ScriptedModel,
                        TransientError, extract_json)
from growth.stats import beta_cdf, beta_ppf, interval, lift_interval, prob_best, prob_greater, similarity
from growth.store import Store
from growth.types import Creative, Impression

from conftest import run


def test_beta_quantiles_match_known_values():
    assert beta_cdf(0.5, 2, 2) == pytest.approx(0.5)
    assert beta_ppf(0.5, 1, 1) == pytest.approx(0.5, abs=1e-6)
    assert beta_cdf(beta_ppf(0.05, 4, 28), 4, 28) == pytest.approx(0.05, abs=1e-6)


def test_interval_is_wide_with_few_samples_and_narrow_with_many():
    few, many = interval(3, 30), interval(300, 3000)
    assert few[1] - few[0] > 3 * (many[1] - many[0])
    assert few[0] < 0.1 < few[1] and many[0] < 0.1 < many[1]


def test_prob_best_and_prob_greater():
    rng = random.Random(0)
    probs = prob_best({"a": (50, 50), "b": (10, 90), "c": (1, 1)}, rng)
    assert probs["a"] > 0.4 and probs["b"] < 0.01 and sum(probs.values()) == pytest.approx(1)
    assert prob_greater((80, 20), (20, 80), rng) > 0.99


def test_lift_interval_crosses_zero_when_data_is_thin():
    rng = random.Random(0)
    mid, lo, hi = lift_interval((6, 40), (5, 40), rng)
    assert lo < 0 < hi
    mid, lo, hi = lift_interval((300, 1000), (100, 1000), rng)
    assert lo > 1


def test_similarity():
    assert similarity("不含酒精，敏感肌也敢用", "不含酒精，敏感肌也敢用。") > 0.9
    assert similarity("不含酒精", "跑步出汗也不流白汤") < 0.1


def test_extract_json_handles_fences_and_arrays():
    assert extract_json('好的：```json\n[{"a": 1}]\n```') == [{"a": 1}]
    assert extract_json('结论 {"x": {"y": 2}} 以上') == {"x": {"y": 2}}
    assert extract_json("没有 JSON") is None


def test_pool_retries_with_backoff_then_gives_up():
    waits = []

    async def fake_sleep(s):
        waits.append(s)

    calls = {"n": 0}

    async def flaky():
        calls["n"] += 1
        if calls["n"] < 3:
            raise RateLimitError("429", retry_after=0.5) if calls["n"] == 1 else TransientError("timeout")
        return "ok"

    async def always():
        raise TransientError("down")

    pool = RateLimitedPool(4, 6000, sleep=fake_sleep)
    assert run(pool.call(flaky)) == "ok"
    assert waits[0] == 0.5 and 2 <= waits[1] < 3 and pool.retried == 2      # 第二次是 2**1 加随机量
    with pytest.raises(GiveUp):
        run(pool.call(always, retries=2))


def test_pool_limits_concurrency():
    live = {"now": 0, "max": 0}

    async def work():
        live["now"] += 1
        live["max"] = max(live["max"], live["now"])
        await asyncio.sleep(0.01)
        live["now"] -= 1

    async def main():
        pool = RateLimitedPool(3, 60000)
        await asyncio.gather(*(pool.call(work) for _ in range(12)))

    run(main())
    assert live["max"] == 3


def test_run_budget_is_a_hard_gate_and_ledger_groups_by_stage():
    models = Models(ScriptedModel(lambda s, u, d: "ok"), ledger=Ledger(max_calls=2), rpm=60000)
    run(models.stage("review").ask("s", "u"))
    run(models.stage("sim").ask("s", "u"))
    with pytest.raises(BudgetExceeded):
        run(models.stage("sim").ask("s", "u"))
    assert {r["stage"]: r["calls"] for r in models.ledger.by_stage()} == {"review": 1, "sim": 1}


def test_stage_tiers_route_to_configured_models():
    cheap, strong, default = ScriptedModel(lambda *a: "cheap"), ScriptedModel(lambda *a: "strong"), ScriptedModel(lambda *a: "d")
    models = Models(default, {"cheap": cheap, "strong": strong}, rpm=60000)
    assert run(models.stage("sim").ask("", "")) == "cheap"
    assert run(models.stage("lead").ask("", "")) == "strong"
    assert run(models.stage("creative").ask("", "")) == "d"       # 没配置的档位退回默认模型
    assert models.stage("sim").pool is not models.stage("review").pool      # 量大的环节各用各的池


def test_impressions_are_idempotent_on_round_creative_user():
    store = Store()
    imps = [Impression(1, 7, 1, u, u % 2 == 0, False, "x") for u in range(10)]
    assert store.add_impressions(imps) == 10
    assert store.add_impressions(imps) == 0          # 重复写入不会产生第二条记录
    assert len(store.impressions(1)) == 10 and store.used_budget() == 10
    store.add_impressions([Impression(0, 7, 1, 1, True, False)], holdout=True)
    assert store.used_budget() == 10                 # 留出验收不占投放预算


def test_store_roundtrips_creative_and_lineage():
    store = Store()
    a = store.add_creative(Creative(0, 1, [3], "成分", "理性", "不含酒精", status="approved"))
    b = store.add_creative(Creative(0, 1, [3, 5], "成分", "亲切", "不含酒精不黏", parent_id=a.id, round=2, note="改语气"))
    got = store.creative(b.id)
    assert got.parent_id == a.id and got.selling_point_ids == [3, 5] and got.note == "改语气"
    assert [c.id for c in store.creatives(status="approved")] == [a.id]
