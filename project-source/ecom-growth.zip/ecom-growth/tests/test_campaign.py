"""整条闭环：主管的调度、代码强制的闸口、续跑。全部用离线替身，不接模型。"""
import pytest

from growth.lead import AutoApprover, Campaign, Config
from growth.llm import Ledger, Models, ScriptedModel
from growth.offline import OfflineModel
from growth.report import lineage
from growth.store import Store

from conftest import make_campaign, offline_models, run


@pytest.fixture(scope="module")
def finished(tmp_path_factory):
    import json
    from growth.lead import ROOT
    from growth.types import Product
    data = json.loads((ROOT / "data" / "products" / "sunscreen.json").read_text())
    data.pop("note")
    sim = json.loads((ROOT / "data" / "sim" / "sim-v1.json").read_text())
    c = make_campaign(Product(**data), sim, tmp_path_factory.mktemp("run") / "c.db")
    report = run(c.run())
    return c, report


def test_full_loop_finishes_with_a_report(finished):
    c, report = finished
    assert c.state["stage"] == "done" and c.state["round"] == 3
    assert "活动报告" in report and "各人群最终推荐" in report and "不代表真实投放效果" in report
    actions = [row["action"] for row in c.store.lead_log()]
    assert actions[:6] == ["understand_product", "segment_audience", "generate_creatives", "review_creatives", "run_trial", "attribute"]
    assert actions.count("run_trial") == 3 and actions[-1] == "finish"


def test_only_approved_creatives_ever_get_impressions(finished):
    c, _ = finished
    shown = {i.creative_id for i in c.store.impressions()}
    by_id = {x.id: x for x in c.store.creatives()}
    assert shown and all(by_id[i].status in ("approved", "retired") for i in shown)
    for cid in shown:      # 每一版投放过的素材都能查到一条通过的审核记录，且在首次曝光之前
        logs = [r for r in c.store.review_logs() if r["creative_id"] == cid]
        assert logs and logs[-1]["verdict"] == "approved"
        assert logs[-1]["round"] <= min(i.round for i in c.store.impressions() if i.creative_id == cid)


def test_budget_and_round_caps_hold(finished):
    c, _ = finished
    assert c.store.used_budget() <= c.config.budget
    assert all(len(c.store.impressions(r)) <= c.config.round_budget for r in (1, 2, 3))


def test_holdout_users_never_take_part_in_trials(finished):
    c, _ = finished
    holdout = {u.id for u in c.users if u.holdout}
    assert not holdout & {i.user_id for i in c.store.impressions()}
    assert {i.user_id for i in c.store.impressions(holdout=True)} <= holdout


def test_intercept_rewrite_reaudit_leaves_a_trail(finished):
    c, _ = finished
    logs = c.store.review_logs()
    fixed = [cid for cid in {r["creative_id"] for r in logs}
             if [r["verdict"] for r in logs if r["creative_id"] == cid][:1] == ["rejected"]
             and [r["verdict"] for r in logs if r["creative_id"] == cid][-1] == "approved"]
    assert fixed                                                    # 离线替身故意让个别文案第一次写出违规内容
    first = next(r for r in logs if r["creative_id"] == fixed[0])
    assert first["hits"] or any(x["verdict"] != "合规" for x in first["checks"])
    assert first["versions"]["rules"] == "rules-v1" and first["versions"]["judge"]
    assert any(r["human"] and r["human"]["by"] == "auto" for r in logs)     # 拿不准的走了人工这一层


def test_evolution_builds_a_lineage_and_children_change_one_tag(finished):
    c, _ = finished
    by_id = {x.id: x for x in c.store.creatives()}
    children = [x for x in by_id.values() if x.parent_id]
    assert children
    for child in children:
        parent = by_id[child.parent_id]
        diff = (set(child.selling_point_ids) != set(parent.selling_point_ids)) + (child.angle != parent.angle) + (child.tone != parent.tone)
        assert diff == 1 and child.round > parent.round and child.note.startswith("改")
    assert "└─" in lineage(c.store)
    assert set(c.store.priors()) >= {x.id for x in children if x.status == "approved" and x.id in c.store.priors()}


def test_unanswerable_concern_becomes_a_question_for_a_human_not_a_made_up_claim(finished):
    c, _ = finished
    assert any("假白" in q and "是否补充" in q for q in c.store.questions())
    assert not any("假白" in x.body for x in c.store.creatives())
    assert any("洗面奶" in x.body and x.note.startswith("补缺") for x in c.store.creatives())      # 有卖点能回应的顾虑则补写


def test_rerun_on_a_finished_campaign_changes_nothing(finished, product, sim):
    c, report = finished
    n = c.store.used_budget()
    again = Campaign(c.store, offline_models())
    assert run(again.run()) == report and c.store.used_budget() == n


def test_crash_mid_trial_resumes_without_duplicate_impressions(product, sim, tmp_path):
    reference = make_campaign(product, sim, max_rounds=1)
    run(reference.run())

    class Crash(Exception):
        pass

    c = make_campaign(product, sim, tmp_path / "x.db", max_rounds=1)
    served = {"n": 0}
    real = c.env.expose

    async def flaky(round, creative, users):
        served["n"] += 1
        if served["n"] == 7:
            raise Crash()
        return await real(round, creative, users)

    c.env.expose = flaky
    with pytest.raises(Crash):
        run(c.run())
    partial = c.store.used_budget()
    assert 0 < partial < 400 and c.store.round_status(1) == "running"
    c.store.close()

    resumed = Campaign(Store(tmp_path / "x.db"), offline_models())       # 新进程：只凭数据层里的状态接着跑
    asked = []
    resumed.approver.confirm_trial = lambda r, s: asked.append(r) or True
    run(resumed.run())
    assert resumed.state["stage"] == "done" and asked == []              # 这一轮已经确认过，不再问第二次
    imps = resumed.store.impressions(1)
    assert len(imps) == 400 == len({(i.creative_id, i.user_id) for i in imps})
    assert [row["action"] for row in resumed.store.lead_log()].count("understand_product") == 1


def test_run_budget_stops_the_campaign_and_keeps_state(product, sim, tmp_path):
    c = make_campaign(product, sim, tmp_path / "b.db", models=offline_models(max_calls=60))
    run(c.run())
    assert c.state["stage"] != "done" and "运行预算" in c.state["stop"]
    stage = c.state["stage"]
    c.store.close()
    resumed = Campaign(Store(tmp_path / "b.db"), offline_models())
    assert resumed.state["stage"] == stage
    run(resumed.run())
    assert resumed.state["stage"] == "done"


def test_trial_needs_human_confirmation(product, sim):
    c = make_campaign(product, sim)

    class No(AutoApprover):
        def confirm_trial(self, round, summary):
            return False

    c.approver = No()
    run(c.run())
    assert c.store.used_budget() == 0 and c.state["stop"] == "试投未获确认"


def test_needs_proof_points_stay_unusable_unless_confirmed(product, sim):
    c = make_campaign(product, sim)

    class Nothing(AutoApprover):
        def confirm_points(self, product, pending):
            return []

    c.approver = Nothing()
    run(c.understand_product())
    usable = {p.text for p in c.store.points(usable_only=True)}
    assert "SPF50+ PA++++" not in usable and "防水防汗" not in usable and "不含酒精" in usable


def test_lead_can_only_pick_allowed_actions(product, sim):
    def reply(system, user, data):
        if data["task"] == "lead.decide":
            return '{"action": "run_trial", "reason": "我想直接再投一轮"}'      # 归因之后不允许跳过进化和审核直接试投
        return getattr(OfflineModel(), data["task"].replace(".", "_"))(data)

    models = Models(ScriptedModel(reply), ledger=Ledger(), rpm=600000, max_concurrency=64)
    c = make_campaign(product, sim, models=models, max_rounds=2)
    run(c.run())
    log = c.store.lead_log()
    after_attr = [row for prev, row in zip(log, log[1:]) if prev["action"] == "attribute"]
    assert after_attr[0]["action"] == "evolve_creatives" and "不在可选范围" in after_attr[0]["reason"]


def test_gates_hard_stop_at_max_rounds_and_when_budget_is_gone(product, sim):
    c = make_campaign(product, sim, max_rounds=1)
    run(c.run())
    assert c.state["round"] == 1 and "最大轮数" in c.state["stop"]
    c = make_campaign(product, sim, budget=450, round_budget=400, max_rounds=5)
    run(c.run())
    assert c.store.used_budget() <= 450 and c.state["round"] <= 2 and "预算" in c.state["stop"]


def test_convergence_and_rising_block_rate_rules(product, sim):
    c = make_campaign(product, sim)
    run(c.understand_product())
    run(c.segment_audience())
    segs = [str(s.id) for s in c.store.segments()]
    c.state["leaders"] = {"1": {s: [5, 0.95] for s in segs}, "2": {s: [5, 0.93] for s in segs}}
    assert c.converged()
    c.state["leaders"]["2"][segs[0]] = [6, 0.99]                   # 第一名换人了：不算稳定
    assert not c.converged()
    c.state["leaders"]["2"][segs[0]] = [5, 0.7]                    # 概率没过阈值
    assert not c.converged()
    c.state["block_rates"] = {"1": 0.1, "2": 0.2, "3": 0.4}
    assert c.blocks_rising()
    c.state.update(stage="attributed", round=2)
    assert c.allowed_actions()[0] == ["finish"] and "拦截比例连续上升" in c.allowed_actions()[1]["finish"]
