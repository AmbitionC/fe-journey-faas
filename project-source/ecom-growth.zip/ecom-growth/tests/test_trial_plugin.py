"""在线试用的场景：用离线替身跑一遍，检查推给页面的事件。"""
import importlib.util
from pathlib import Path

from growth.offline import OfflineModel

from conftest import run

spec = importlib.util.spec_from_file_location("growth_trial_plugin", Path(__file__).resolve().parent.parent / "trial" / "plugin.py")
plugin = importlib.util.module_from_spec(spec)
spec.loader.exec_module(plugin)


def play():
    events = []
    result = run(plugin.run_campaign(plugin.SCENARIOS["campaign"], events.append, model=OfflineModel()))
    return events, result


def test_trial_runs_the_whole_loop_and_pairs_every_step():
    events, result = play()
    assert result["stopped"] == "finished" and result["changed_files"] == [] and result["turns"] > 0
    starts = [e for e in events if e["type"] == "tool_start"]
    ends = {e["id"] for e in events if e["type"] == "tool_end"}
    assert {e["id"] for e in starts} == ends
    names = [e["name"] for e in starts]
    assert names[:6] == ["understand_product", "segment_audience", "generate_creatives", "review_creatives", "run_trial", "attribute"]
    assert names.count("run_trial") == 3 and "evolve_creatives" in names and names[-1] == "finish"
    text = "".join(e["text"] for e in events if e["type"] == "text")
    assert "活动报告" in text and "不代表真实投放效果" in text and "素材谱系" in text and "自动" in text


def test_trial_registers_one_fixed_scenario():
    scenarios = {}
    plugin.register(scenarios)
    assert list(scenarios) == ["campaign"] and scenarios["campaign"]["fixed_task"] and callable(scenarios["campaign"]["run"])


def test_trial_stops_cleanly_on_timeout(monkeypatch):
    monkeypatch.setattr(plugin, "MAX_SECONDS", 0.05)

    class Slow(OfflineModel):
        async def ask(self, system, user, *, data=None):
            import asyncio
            await asyncio.sleep(0.02)
            return await super().ask(system, user, data=data)

    events = []
    result = run(plugin.run_campaign(plugin.SCENARIOS["campaign"], events.append, model=Slow()))
    assert result["stopped"] == "timeout"
    assert {e["id"] for e in events if e["type"] == "tool_start"} == {e["id"] for e in events if e["type"] == "tool_end"}
