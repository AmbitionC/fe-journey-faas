# 任务清单

一次只做一个里程碑。验收命令全部通过、你自己读过代码之后，再开始下一个。
「容易出错的地方」先不要告诉工具，等它做完再对照，看它有没有踩到。

验收命令用 `-k` 挑出了和这个里程碑相关的用例。个别被挑中的用例可能还依赖后面才实现的部件：遇到这种情况不要让工具提前去做后面的事，把这条用例记下来，到对应的里程碑再回头验收。最后一个里程碑要求全部测试通过，前面漏掉的都会在那里暴露。

## 里程碑 0：骨架

- 范围：按项目说明文件里的目录建好所有模块。每个文件只写开头的职责说明，以及测试文件里 import 到的名字（类和函数先留空，函数体直接抛 `NotImplementedError`）。
- 有两处不能留空，因为测试文件在导入时就调用了它们：`growth/types.py` 里的数据结构要把字段写全；`growth/stages/review.py` 的 `load_rules` 和 `growth/sim/users.py` 的 `behavior_features` 要能返回真实结果（读规则文件、读行为数据样例）。
- 验收：`python -m pytest --collect-only -q`，所有测试文件都能被导入，不要求通过。
- 为什么要有这一步：测试文件在开头就把要用的模块全部导入了。没有骨架，后面每个里程碑的验收命令都会卡在导入错误上，看不出这个里程碑做得对不对。
- [ ] 验收通过

## 里程碑 1：数据结构、数据层和模型调用底座

- 范围：`growth/types.py`、`store.py`、`llm.py`、`stats.py`
- 验收：`python -m pytest -q tests/test_basics.py`
- 容易出错的地方：并发数和速率是两个限制，分别用信号量和令牌桶；运行预算在每次调用之前检查。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 2：生产素材：商品理解、人群、素材生成

- 范围：`growth/stages/product.py`、`segment.py`、`creative.py`，以及 `growth/offline.py` 里对应的部分
- 验收：`python -m pytest -q tests/test_production.py -k "evidence or claim or level or mentions or instruction or segments or plan or self_check or generation or reference"`
- 容易出错的地方：依据要在原文里做包含判断，不能相信模型说「有依据」。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 3：审核

- 范围：`growth/stages/review.py`
- 验收：`python -m pytest -q tests/test_production.py`
- 容易出错的地方：规则匹配之前要归一化：去掉空格和标点、数字统一，否则「第 一」能绕过。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 4：模拟环境、分配、归因

- 范围：`growth/sim/`、`growth/stages/allocate.py`、`attribute.py`
- 验收：`python -m pytest -q tests/test_trial_zone.py -k "not retire and not rewrite and not gap and not inherits"`
- 容易出错的地方：同一对「素材内容和用户」只打一次分，键用内容哈希。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 5：进化

- 范围：`growth/stages/evolve.py`
- 验收：`python -m pytest -q tests/test_trial_zone.py tests/test_production.py`
- 容易出错的地方：新素材继承父素材打过折的统计作为先验。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 6：主管、报告和命令行

- 范围：`growth/lead.py`、`report.py`、`cli.py`
- 验收：`python -m pytest -q tests/test_campaign.py && python -m growth.cli run --offline --yes`
- 容易出错的地方：续跑：一轮试投只执行一次，中断后只补没投完的部分。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过

## 里程碑 7：对照实验

- 范围：`growth/single.py`、`cli.py` 的 `compare`
- 验收：`python -m pytest -q && python -m growth.cli compare --offline`
- 容易出错的地方：只换上下文的组织方式，其余保持一致。
- [ ] 计划看过了
- [ ] 验收通过
- [ ] 自己读过代码，和源码对照过
