"""生成一份合成的行为数据样例，格式与淘宝用户行为数据集（阿里天池）相同：
user_id,item_id,category_id,behavior,timestamp；behavior 取 pv / cart / fav / buy。

仓库里附的 data/behavior_sample.csv 就是它生成的，目的只是让代码拿到手就能跑。
它是合成数据，不是真实用户行为。想让模拟用户的行为分布有真实依据，请自行下载真实数据集
（下载前确认使用许可），抽样后替换这个文件，格式不用改。
"""
import csv
import random
import sys

TYPES = [  # 浏览次数范围、每次浏览后购买/加购收藏的概率、类目数、夜间活跃比例
    ("果断型", (4, 12), 0.22, 0.03, (1, 2), 0.3),
    ("比较型", (25, 60), 0.04, 0.22, (1, 3), 0.5),
    ("闲逛型", (20, 50), 0.004, 0.04, (6, 12), 0.6),
    ("囤货型", (10, 25), 0.30, 0.08, (1, 2), 0.2),
]
START = 1511539200  # 2017-11-25 00:00 +08:00


def main(path: str, users: int = 300, seed: int = 7) -> None:
    rng = random.Random(seed)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        for uid in range(1, users + 1):
            _, pv_range, p_buy, p_cart, cat_range, night = rng.choices(TYPES, weights=[2, 4, 3, 1])[0]
            cats = [rng.randint(1000, 9999) for _ in range(rng.randint(*cat_range))]
            for _ in range(rng.randint(*pv_range)):
                day = rng.randint(0, 8)
                hour = rng.randint(21, 23) if rng.random() < night else rng.randint(8, 20)
                ts = START + day * 86400 + hour * 3600 + rng.randint(0, 3599)
                cat, item = rng.choice(cats), rng.randint(100000, 999999)
                w.writerow([uid, item, cat, "pv", ts])
                r = rng.random()
                if r < p_buy:
                    w.writerow([uid, item, cat, "buy", ts + 60])
                elif r < p_buy + p_cart:
                    w.writerow([uid, item, cat, rng.choice(["cart", "fav"]), ts + 30])


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "data/behavior_sample.csv")
